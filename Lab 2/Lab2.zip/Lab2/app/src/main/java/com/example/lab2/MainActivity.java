package com.example.lab2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "LifecycleDemo";
    private static final String KEY_COUNT = "count";
    private static final String ACTIVITY_NAME = "Activity A";

    private TextView countTextView;
    private int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLogAndToast("onCreate");
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            count = savedInstanceState.getInt(KEY_COUNT, 0);
        }

        countTextView = findViewById(R.id.countTextView);
        Button incrementButton = findViewById(R.id.incrementButton);
        Button secondActivityButton = findViewById(R.id.secondActivityButton);

        updateCountText();

        incrementButton.setOnClickListener(v -> {
            count++;
            updateCountText();
        });

        secondActivityButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void updateCountText() {
        countTextView.setText("Count: " + count);
    }

    private void showLogAndToast(String methodName) {
        String message = ACTIVITY_NAME + ": " + methodName + "() called";
        Log.d(TAG, message);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStart() {
        super.onStart();
        showLogAndToast("onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        showLogAndToast("onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        showLogAndToast("onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        showLogAndToast("onStop");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        showLogAndToast("onRestart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        showLogAndToast("onDestroy");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_COUNT, count);
        Log.d(TAG, ACTIVITY_NAME + ": onSaveInstanceState() called. Saving count: " + count);
    }
}