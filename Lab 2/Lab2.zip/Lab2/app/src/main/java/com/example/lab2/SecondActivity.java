package com.example.lab2;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity {

    private static final String TAG = "LifecycleDemo";
    private static final String ACTIVITY_NAME = "Activity B";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLogAndToast("onCreate");
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void showLogAndToast(String methodName) {
        String message = ACTIVITY_NAME + ": " + methodName + "() called";
        Log.d(TAG, message);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onStart() {
        super.onStart();
        showLogAndToast("onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        showLogAndToast("onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        showLogAndToast("onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        showLogAndToast("onStop");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        showLogAndToast("onRestart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        showLogAndToast("onDestroy");
    }
}