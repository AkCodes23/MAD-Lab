package com.example.lab2Q2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText etNum1, etNum2;
    private String lastResultString = "None";
    private char currentOperator = '+';
    
    private Button[] operatorButtons;
    private Map<Character, Button> operatorButtonMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNum1 = findViewById(R.id.etNum1);
        etNum2 = findViewById(R.id.etNum2);
        Button btnEquals = findViewById(R.id.btnEquals);
        Button btnClear = findViewById(R.id.btnClear);
        Button btnViewLastResult = findViewById(R.id.btnViewLastResult);
        
        // Initialize operator mapping and button array for styling
        operatorButtonMap = new HashMap<>();
        operatorButtonMap.put('+', findViewById(R.id.btnAdd));
        operatorButtonMap.put('-', findViewById(R.id.btnSub));
        operatorButtonMap.put('*', findViewById(R.id.btnMul));
        operatorButtonMap.put('/', findViewById(R.id.btnDiv));
        operatorButtonMap.put('^', findViewById(R.id.btnPow));
        operatorButtonMap.put('%', findViewById(R.id.btnMod));
        
        operatorButtons = new Button[]{
            findViewById(R.id.btnAdd), findViewById(R.id.btnSub), 
            findViewById(R.id.btnMul), findViewById(R.id.btnDiv),
            findViewById(R.id.btnPow), findViewById(R.id.btnMod)
        };

        // Set click listeners for operators to SET the operator
        for (Map.Entry<Character, Button> entry : operatorButtonMap.entrySet()) {
            entry.getValue().setOnClickListener(v -> setOperator(entry.getKey()));
        }

        // Equals button triggers calculation
        btnEquals.setOnClickListener(v -> calculate());

        // Clear button
        btnClear.setOnClickListener(v -> {
            etNum1.setText("");
            etNum2.setText("");
            etNum1.requestFocus();
            setOperator('+'); // Reset operator to default '+'
        });
        
        // New button to view last result
        btnViewLastResult.setOnClickListener(v -> {
            if (!lastResultString.equals("None")) {
                Intent intent = new Intent(this, ResultActivity.class);
                intent.putExtra("result_string", lastResultString);
                startActivity(intent);
            } else {
                Toast.makeText(this, "No previous result to display.", Toast.LENGTH_SHORT).show();
            }
        });
        
        // Set initial state
        setOperator('+');
    }

    private void setOperator(char operator) {
        currentOperator = operator;
        // Update button appearance to show selection
        for (Button btn : operatorButtons) {
            // Reset all operator buttons to a default color (Using null resets to theme's default)
            btn.setBackgroundTintList(null); 
        }
        
        // Highlight the selected operator button with Amber
        Button selectedButton = operatorButtonMap.get(operator);
        if (selectedButton != null) {
            selectedButton.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(Color.parseColor("#FFC107")) 
            );
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // lastResultString is preserved across activity restarts unless the app is killed.
    }

    private void calculate() {
        String s1 = etNum1.getText().toString();
        String s2 = etNum2.getText().toString();

        if (s1.isEmpty() || s2.isEmpty()) {
            Toast.makeText(this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double n1 = Double.parseDouble(s1);
            double n2 = Double.parseDouble(s2);
            double result = 0;
            boolean valid = true;

            switch (currentOperator) {
                case '+': result = n1 + n2; break;
                case '-': result = n1 - n2; break;
                case '*': result = n1 * n2; break;
                case '/':
                    if (n2 == 0) {
                        Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                        valid = false;
                    } else {
                        result = n1 / n2;
                    }
                    break;
                case '^':
                    result = Math.pow(n1, n2);
                    break;
                case '%':
                    if (n2 == 0) {
                        Toast.makeText(this, "Cannot calculate modulo by zero", Toast.LENGTH_SHORT).show();
                        valid = false;
                    } else {
                        result = n1 % n2;
                    }
                    break;
            }

            if (valid) {
                lastResultString = n1 + " " + currentOperator + " " + n2 + " = " + result;
                Intent intent = new Intent(this, ResultActivity.class);
                intent.putExtra("result_string", lastResultString);
                startActivity(intent);
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid number format", Toast.LENGTH_SHORT).show();
        }
    }
}