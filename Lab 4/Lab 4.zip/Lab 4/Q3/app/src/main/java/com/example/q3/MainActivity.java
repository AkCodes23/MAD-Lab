package com.example.q3;

import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView tvStatus, tvDetails;
    private MaterialButtonToggleGroup toggleGroup;
    private MaterialButton btnSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imageView = findViewById(R.id.imageView);
        tvStatus = findViewById(R.id.tvStatus);
        tvDetails = findViewById(R.id.tvDetails);
        toggleGroup = findViewById(R.id.toggleGroup);
        btnSwitch = findViewById(R.id.btnSwitch);

        // Initial setup
        updateModeUI(true, false);

        toggleGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (isChecked) {
                boolean isWifi = (checkedId == R.id.btnWifi);
                updateModeUI(isWifi, true);
            }
        });

        btnSwitch.setOnClickListener(v -> {
            int currentCheckedId = toggleGroup.getCheckedButtonId();
            int nextId = (currentCheckedId == R.id.btnWifi) ? R.id.btnMobile : R.id.btnWifi;
            toggleGroup.check(nextId);
        });
    }

    private void updateModeUI(boolean isWifi, boolean showToast) {
        String modeName = isWifi ? "Wi-Fi" : "Mobile Data";
        int iconRes = isWifi ? R.drawable.ic_wifi : R.drawable.ic_mobile_data;
        String details = isWifi ? "Connected to 'Home_Network_5G'" : "LTE Connected (High Speed)";

        // Creative touch: Fade animation for the icon change
        Animation fadeOut = new AlphaAnimation(1, 0);
        fadeOut.setDuration(200);
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView.setImageResource(iconRes);
                Animation fadeIn = new AlphaAnimation(0, 1);
                fadeIn.setDuration(200);
                imageView.startAnimation(fadeIn);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}
        });
        imageView.startAnimation(fadeOut);

        tvStatus.setText(modeName + " Mode");
        tvDetails.setText(details);

        if (showToast) {
            Toast.makeText(this, modeName + " activated", Toast.LENGTH_SHORT).show();
        }
    }
}