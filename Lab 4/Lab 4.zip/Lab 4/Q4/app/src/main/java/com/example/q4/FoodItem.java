package com.example.q4;

import java.io.Serializable;

public class FoodItem implements Serializable {
    private String name;
    private int price;
    private String category;
    private int quantity = 0;
    private boolean isChecked = false;

    public FoodItem(String name, int price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }

    public String getName() { return name; }
    public int getPrice() { return price; }
    public String getCategory() { return category; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public boolean isChecked() { return isChecked; }
    public void setChecked(boolean checked) { isChecked = checked; }
}