package com.example.q4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvFoodItems;
    private FoodAdapter adapter;
    private MaterialButton btnSubmit;
    private TextInputEditText etInstructions;
    private View overlay;
    private List<FoodItem> foodList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvFoodItems = findViewById(R.id.rvFoodItems);
        btnSubmit = findViewById(R.id.btnSubmit);
        etInstructions = findViewById(R.id.etInstructions);
        overlay = findViewById(R.id.overlay);

        initFoodList();

        adapter = new FoodAdapter(foodList);
        rvFoodItems.setLayoutManager(new LinearLayoutManager(this));
        rvFoodItems.setAdapter(adapter);

        btnSubmit.setOnClickListener(v -> {
            ArrayList<FoodItem> selectedItems = new ArrayList<>();
            int totalCost = 0;

            for (FoodItem item : foodList) {
                if (item.isChecked()) {
                    selectedItems.add(item);
                    totalCost += item.getPrice() * item.getQuantity();
                }
            }

            if (selectedItems.isEmpty()) {
                Toast.makeText(this, "Please select at least one item", Toast.LENGTH_SHORT).show();
                return;
            }

            String instructions = etInstructions.getText().toString();

            // Disable interaction as per requirement
            adapter.setInteractionEnabled(false);
            btnSubmit.setEnabled(false);
            etInstructions.setEnabled(false);
            overlay.setVisibility(View.VISIBLE); // Visual cue that order is placed

            Intent intent = new Intent(MainActivity.this, OrderSummaryActivity.class);
            intent.putExtra("selectedItems", selectedItems);
            intent.putExtra("totalCost", totalCost);
            intent.putExtra("instructions", instructions);
            startActivity(intent);
        });
    }

    private void initFoodList() {
        foodList = new ArrayList<>();
        foodList.add(new FoodItem("Classic Margherita", 12, "Italian • Pizza"));
        foodList.add(new FoodItem("Double Truffle Burger", 15, "Gourmet • Burger"));
        foodList.add(new FoodItem("Creamy Alfredo Pasta", 14, "Italian • Pasta"));
        foodList.add(new FoodItem("Avocado Quinoa Salad", 10, "Healthy • Salad"));
        foodList.add(new FoodItem("Garlic Herbs Bread", 6, "Sides"));
        foodList.add(new FoodItem("Fresh Lime Soda", 4, "Beverages"));
        foodList.add(new FoodItem("Chocolate Lava Cake", 8, "Desserts"));
    }
}