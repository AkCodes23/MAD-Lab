package com.example.q4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.List;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.FoodViewHolder> {

    private List<FoodItem> foodList;
    private boolean isInteractionEnabled = true;

    public FoodAdapter(List<FoodItem> foodList) {
        this.foodList = foodList;
    }

    public void setInteractionEnabled(boolean enabled) {
        this.isInteractionEnabled = enabled;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_food, parent, false);
        return new FoodViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodViewHolder holder, int position) {
        FoodItem item = foodList.get(position);
        holder.tvName.setText(item.getName());
        holder.tvPrice.setText("$" + item.getPrice() + ".00");
        holder.tvCategory.setText(item.getCategory());
        
        holder.checkBox.setOnCheckedChangeListener(null); // Clear listener before setting state
        holder.checkBox.setChecked(item.isChecked());
        holder.tvQuantity.setText(String.valueOf(item.getQuantity()));
        
        holder.layoutQuantity.setVisibility(item.isChecked() ? View.VISIBLE : View.GONE);

        holder.checkBox.setEnabled(isInteractionEnabled);
        holder.btnPlus.setEnabled(isInteractionEnabled);
        holder.btnMinus.setEnabled(isInteractionEnabled);

        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            item.setChecked(isChecked);
            if (isChecked && item.getQuantity() == 0) {
                item.setQuantity(1);
                holder.tvQuantity.setText("1");
            }
            holder.layoutQuantity.setVisibility(isChecked ? View.VISIBLE : View.GONE);
        });

        holder.btnPlus.setOnClickListener(v -> {
            item.setQuantity(item.getQuantity() + 1);
            holder.tvQuantity.setText(String.valueOf(item.getQuantity()));
        });

        holder.btnMinus.setOnClickListener(v -> {
            if (item.getQuantity() > 1) {
                item.setQuantity(item.getQuantity() - 1);
                holder.tvQuantity.setText(String.valueOf(item.getQuantity()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    static class FoodViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
        TextView tvName, tvPrice, tvQuantity, tvCategory;
        View layoutQuantity;
        MaterialButton btnPlus, btnMinus;

        public FoodViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.checkBox);
            tvName = itemView.findViewById(R.id.tvFoodName);
            tvPrice = itemView.findViewById(R.id.tvFoodPrice);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            layoutQuantity = itemView.findViewById(R.id.layoutQuantity);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnMinus = itemView.findViewById(R.id.btnMinus);
        }
    }
}