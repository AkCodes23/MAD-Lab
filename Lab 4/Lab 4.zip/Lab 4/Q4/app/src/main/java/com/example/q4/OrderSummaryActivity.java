package com.example.q4;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import java.util.ArrayList;

public class OrderSummaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_summary);

        TextView tvOrderDetails = findViewById(R.id.tvOrderDetails);
        TextView tvTotalCost = findViewById(R.id.tvTotalCost);
        TextView tvInstructions = findViewById(R.id.tvInstructions);
        MaterialButton btnBack = findViewById(R.id.btnBack);

        ArrayList<FoodItem> selectedItems = (ArrayList<FoodItem>) getIntent().getSerializableExtra("selectedItems");
        int totalCost = getIntent().getIntExtra("totalCost", 0);
        String instructions = getIntent().getStringExtra("instructions");

        if (selectedItems != null) {
            StringBuilder sb = new StringBuilder();
            for (FoodItem item : selectedItems) {
                sb.append("• ")
                        .append(item.getName())
                        .append(" x")
                        .append(item.getQuantity())
                        .append(" ($")
                        .append(item.getPrice() * item.getQuantity())
                        .append(")\n");
            }
            tvOrderDetails.setText(sb.toString().trim());
        }

        if (instructions != null && !instructions.isEmpty()) {
            tvInstructions.setText("Notes: " + instructions);
            tvInstructions.setVisibility(View.VISIBLE);
        } else {
            tvInstructions.setVisibility(View.GONE);
        }

        tvTotalCost.setText("$" + totalCost + ".00");

        btnBack.setOnClickListener(v -> finish());
    }
}