package com.example.q2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnOreo = findViewById(R.id.btnOreo);
        Button btnPie = findViewById(R.id.btnPie);
        Button btnAndroid10 = findViewById(R.id.btnAndroid10);
        Button btnAndroid11 = findViewById(R.id.btnAndroid11);

        btnOreo.setOnClickListener(v -> showCustomToast("Android Oreo", R.drawable.ic_launcher_foreground));
        btnPie.setOnClickListener(v -> showCustomToast("Android Pie", R.drawable.ic_launcher_foreground));
        btnAndroid10.setOnClickListener(v -> showCustomToast("Android 10", R.drawable.ic_launcher_foreground));
        btnAndroid11.setOnClickListener(v -> showCustomToast("Android 11", R.drawable.ic_launcher_foreground));
    }

    private void showCustomToast(String versionName, int iconResId) {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast, findViewById(R.id.custom_toast_container));

        ImageView icon = layout.findViewById(R.id.toast_icon);
        TextView text = layout.findViewById(R.id.toast_text);

        icon.setImageResource(iconResId);
        text.setText(versionName);

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.show();
    }
}
