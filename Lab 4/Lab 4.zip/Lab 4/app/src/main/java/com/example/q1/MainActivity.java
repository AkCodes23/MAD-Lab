package com.example.q1;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialButton button = findViewById(R.id.button);
        MaterialButton toggleButton = findViewById(R.id.toggleButton);

        button.setOnClickListener(v -> 
            showCustomToast("Standard Action Triggered", R.drawable.ic_launcher_foreground)
        );

        toggleButton.addOnCheckedChangeListener((buttonView, isChecked) -> {
            String message = isChecked ? "Status: ACTIVE" : "Status: INACTIVE";
            int icon = isChecked ? R.drawable.ic_launcher_foreground : R.drawable.ic_launcher_background;
            showCustomToast(message, icon);
        });
    }

    private void showCustomToast(String message, int imageResId) {
        View layout = LayoutInflater.from(this).inflate(R.layout.custom_toast, null);

        ImageView image = layout.findViewById(R.id.toast_image);
        image.setImageResource(imageResId);

        TextView text = layout.findViewById(R.id.toast_text);
        text.setText(message);

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        // Position it slightly higher for a more modern feel
        toast.setGravity(android.view.Gravity.BOTTOM | android.view.Gravity.CENTER_HORIZONTAL, 0, 200);
        toast.show();
    }
}
