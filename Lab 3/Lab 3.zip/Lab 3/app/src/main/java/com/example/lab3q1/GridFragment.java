package com.example.lab3q1;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

public class GridFragment extends Fragment {

    public GridFragment() {
        // Required empty public constructor
    }

    public static GridFragment newInstance() {
        return new GridFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.layout_grid_view, container, false);
        
        GridView gridView = root.findViewById(R.id.grid_view);

        // Placeholder: We can't easily load actual images without adding them to resources,
        // so we'll use simple placeholder items (like small colored squares or nothing) 
        // or just use a simple adapter if that fails.
        // For simplicity, let's use a list of numbers to demonstrate grid layout setup.
        List<String> items = new ArrayList<>();
        for (int i = 1; i <= 12; i++) {
            items.add("Image " + i);
        }

        // A simple array adapter to show the grid is working
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            requireContext(),
            android.R.layout.simple_list_item_1, // Using a simple text layout as a placeholder for image
            items
        );
        
        gridView.setAdapter(adapter);
        
        return root;
    }
}