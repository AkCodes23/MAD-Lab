package com.example.lab3q1;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.Arrays;
import java.util.List;

public class ListFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";

    public ListFragment() {
        // Required empty public constructor
    }

    public static ListFragment newInstance() {
        ListFragment fragment = new ListFragment();
        Bundle args = new Bundle();
        // args.putInt(ARG_SECTION_NUMBER, sectionNumber); // Not strictly needed here
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.layout_list_view, container, false);
        
        ListView listView = root.findViewById(R.id.list_view);

        // Placeholder Data based on image example
        List<String> countries = Arrays.asList(
            "American Samoa", "El Salvador", "Saint Helena", "Saint Kitts and Nevis", 
            "Saint Lucia", "Saint Pierre and Miquelon", "Saint Vincent and the Grenadines", 
            "Samoa", "San Marino", "Saudi Arabia"
        );

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            requireContext(),
            android.R.layout.simple_list_item_1,
            countries
        );
        
        listView.setAdapter(adapter);
        
        return root;
    }
}