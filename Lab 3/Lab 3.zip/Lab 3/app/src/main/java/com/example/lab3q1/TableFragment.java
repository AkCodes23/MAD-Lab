package com.example.lab3q1;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class TableFragment extends Fragment {

    public TableFragment() {
        // Required empty public constructor
    }

    public static TableFragment newInstance() {
        return new TableFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.layout_table_layout, container, false);
        
        // Since layout_table_layout.xml is fully defined in XML for demonstration,
        // we don't need to programmatically manipulate the TableLayout here unless we 
        // were generating rows dynamically. We just return the inflated view.
        
        return root;
    }
}