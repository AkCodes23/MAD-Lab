package com.example.lab3q1;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class SectionsPagerAdapter extends FragmentStateAdapter {

    public SectionsPagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        // Return a NEW fragment instance for the given page.
        switch (position) {
            case 0:
                // Artists Tab -> List View
                return ListFragment.newInstance();
            case 1:
                // Albums Tab -> Grid View
                return GridFragment.newInstance();
            case 2:
                // Songs Tab -> Table Layout
                return TableFragment.newInstance();
            default:
                // Should not happen in this setup
                return new Fragment();
        }
    }

    @Override
    public int getItemCount() {
        // Show 3 tabs: List, Grid, Table
        return 3;
    }
}