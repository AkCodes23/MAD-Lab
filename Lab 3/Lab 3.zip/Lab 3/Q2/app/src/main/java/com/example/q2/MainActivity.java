package com.example.q2;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Define the list of sports
    private String[] sports = {"Football", "Basketball", "Tennis", "Cricket", "Baseball", "Swimming", "Running"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Standard EdgeToEdge setup (keep this)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 1. Get the ListView
        ListView sportsListView = findViewById(R.id.sports_list_view);

        // 2. Create an ArrayAdapter to bind the sports array to the ListView
        // We use android.R.layout.simple_list_item_1 for a simple text view for each item
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                sports);

        // 3. Set the adapter on the ListView
        sportsListView.setAdapter(adapter);

        // 4. Set an OnItemClickListener to handle selection
        sportsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected sport name
                String selectedSport = sports[position];

                // Display a Toast message
                Toast.makeText(MainActivity.this, "Selected Sport: " + selectedSport, Toast.LENGTH_SHORT).show();
            }
        });
    }
}