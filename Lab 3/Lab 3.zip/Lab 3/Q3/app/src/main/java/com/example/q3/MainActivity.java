package com.example.q3;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager2 viewPager;
    private NewsPagerAdapter newsPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Removed EdgeToEdge boilerplate code
        setContentView(R.layout.activity_main);

        // Find views
        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(R.id.view_pager);

        // 1. Setup Adapter for ViewPager2
        newsPagerAdapter = new NewsPagerAdapter(this);
        viewPager.setAdapter(newsPagerAdapter);

        // 2. Define Tab Titles
        String[] tabTitles = new String[]{"Top Stories", "Sports", "Entertainment"};

        // 3. Link TabLayout and ViewPager2
        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> tab.setText(tabTitles[position])
        ).attach();
    }
}