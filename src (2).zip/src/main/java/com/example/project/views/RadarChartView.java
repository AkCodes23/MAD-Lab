package com.example.project.views;

import com.example.project.models.*;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class RadarChartView extends View {

    // ── Paints ────────────────────────────────────────────────────────────────

    // Grid ring lines (faint gray circles)
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Axis spoke lines from center to edge
    private final Paint spokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Student polygon fill (translucent green)
    private final Paint studentFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Student polygon stroke (solid green)
    private final Paint studentStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Project polygon fill (translucent indigo)
    private final Paint projectFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Project polygon stroke (dashed indigo)
    private final Paint projectStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Vertex dots on student polygon
    private final Paint studentDotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Vertex dots on project polygon
    private final Paint projectDotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Axis labels (category names)
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ── Data ─────────────────────────────────────────────────────────────────
    private static final String[] FIXED_CATEGORIES = {
            "Web Dev", "Blockchain", "Cybersec", "Android", "AI/ML", "Embedded Systems"
    };
    private List<CategoryScore> categories = new ArrayList<>();

    // Grid rings at 20%, 40%, 60%, 80%, 100% of radius
    private static final float[] GRID_RINGS = {0.2f, 0.4f, 0.6f, 0.8f, 1.0f};

    public RadarChartView(Context context) {
        super(context);
        init();
    }

    public RadarChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RadarChartView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        // Grid
        gridPaint.setColor(Color.parseColor("#E5E7EB"));  // gray-200
        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(1f);

        // Spokes
        spokePaint.setColor(Color.parseColor("#E5E7EB"));
        spokePaint.setStyle(Paint.Style.STROKE);
        spokePaint.setStrokeWidth(1f);

        // Student fill — translucent emerald
        studentFillPaint.setColor(Color.argb(46, 16, 185, 129)); // emerald-500 at 18%
        studentFillPaint.setStyle(Paint.Style.FILL);

        // Student stroke — solid emerald
        studentStrokePaint.setColor(Color.parseColor("#10b981")); // emerald-500
        studentStrokePaint.setStyle(Paint.Style.STROKE);
        studentStrokePaint.setStrokeWidth(4f);
        studentStrokePaint.setStrokeJoin(Paint.Join.ROUND);

        // Project fill — translucent indigo
        projectFillPaint.setColor(Color.argb(31, 99, 102, 241)); // indigo-500 at 12%
        projectFillPaint.setStyle(Paint.Style.FILL);

        // Project stroke — indigo (we simulate dashes by drawing as solid;
        // true PathEffect dashes require DashPathEffect which we set below)
        projectStrokePaint.setColor(Color.parseColor("#6366f1")); // indigo-500
        projectStrokePaint.setStyle(Paint.Style.STROKE);
        projectStrokePaint.setStrokeWidth(3f);
        projectStrokePaint.setStrokeJoin(Paint.Join.ROUND);
        // Dashed line to match the SVG strokeDasharray="4 2"
        projectStrokePaint.setPathEffect(
                new android.graphics.DashPathEffect(new float[]{12f, 6f}, 0f)
        );

        // Dots
        studentDotPaint.setColor(Color.parseColor("#10b981"));
        studentDotPaint.setStyle(Paint.Style.FILL);

        projectDotPaint.setColor(Color.parseColor("#6366f1"));
        projectDotPaint.setStyle(Paint.Style.FILL);

        // Labels — small, gray, centered on each axis tip
        labelPaint.setColor(Color.parseColor("#6B7280")); // gray-500
        labelPaint.setTextSize(spToPx(11f));
        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Sets the category data and triggers a redraw.
     * Maps the provided scores to the fixed 6-axis layout.
     */
    public void setData(List<CategoryScore> incoming) {
        List<CategoryScore> mapped = new ArrayList<>();
        for (String fixedCat : FIXED_CATEGORIES) {
            CategoryScore found = null;
            if (incoming != null) {
                for (CategoryScore s : incoming) {
                    if (s.label.equalsIgnoreCase(fixedCat)) {
                        found = s;
                        break;
                    }
                }
            }
            if (found != null) {
                mapped.add(found);
            } else {
                // Default zeroed score for missing category
                mapped.add(new CategoryScore(fixedCat, 0, 0, 0));
            }
        }
        this.categories = mapped;
        invalidate();
    }

    // ── Drawing ───────────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int n = categories.size();

        // Always render if we have categories (should be 6)
        if (n == 0) return;

        float cx     = getWidth()  / 2f;
        float cy     = getHeight() / 2f;
        float radius = Math.min(cx, cy) * 0.58f; // 58% of half-dimension → leaves room for labels
        float labelR = radius + dpToPx(28f);      // labels sit 28dp outside the polygon edge

        // ── Draw grid rings ────────────────────────────────────────────────
        for (float ring : GRID_RINGS) {
            Path ringPath = buildPolygon(cx, cy, radius * ring, n, 0);
            canvas.drawPath(ringPath, gridPaint);
        }

        // ── Draw axis spokes ──────────────────────────────────────────────
        for (int i = 0; i < n; i++) {
            double angle = axisAngle(i, n);
            float x = cx + radius * (float) Math.cos(angle);
            float y = cy + radius * (float) Math.sin(angle);
            canvas.drawLine(cx, cy, x, y, spokePaint);
        }

        // ── Draw project polygon (behind student) ─────────────────────────
        Path projectPath = buildDataPolygon(cx, cy, radius, n, true);
        canvas.drawPath(projectPath, projectFillPaint);
        canvas.drawPath(projectPath, projectStrokePaint);

        // ── Draw student polygon (in front) ───────────────────────────────
        Path studentPath = buildDataPolygon(cx, cy, radius, n, false);
        canvas.drawPath(studentPath, studentFillPaint);
        canvas.drawPath(studentPath, studentStrokePaint);

        // ── Draw vertex dots ──────────────────────────────────────────────
        float dotRadius = dpToPx(4f);
        for (int i = 0; i < n; i++) {
            double angle      = axisAngle(i, n);
            float studentFrac = Math.min(categories.get(i).studentScore / 10f, 1f);
            float projectFrac = Math.min(categories.get(i).projectScore / 10f, 1f);

            float sx = cx + radius * studentFrac * (float) Math.cos(angle);
            float sy = cy + radius * studentFrac * (float) Math.sin(angle);
            canvas.drawCircle(sx, sy, dotRadius, studentDotPaint);

            float px = cx + radius * projectFrac * (float) Math.cos(angle);
            float py = cy + radius * projectFrac * (float) Math.sin(angle);
            canvas.drawCircle(px, py, dpToPx(3f), projectDotPaint);
        }

        // ── Draw axis labels ──────────────────────────────────────────────
        for (int i = 0; i < n; i++) {
            double angle = axisAngle(i, n);
            float lx = cx + labelR * (float) Math.cos(angle);
            float ly = cy + labelR * (float) Math.sin(angle);

            String label = categories.get(i).label;

            // Split on "/" or space and draw as two lines if needed
            String[] words = label.split("[/\\s]+");
            if (words.length == 1 || label.length() <= 10) {
                // Single line
                canvas.drawText(label, lx, ly + labelPaint.getTextSize() / 3f, labelPaint);
            } else {
                // Two lines — centre them vertically around ly
                float lineH = labelPaint.getTextSize() * 1.2f;
                canvas.drawText(words[0], lx, ly - lineH / 2f + labelPaint.getTextSize() / 3f, labelPaint);
                String rest = join(words, 1);
                canvas.drawText(rest, lx, ly + lineH / 2f + labelPaint.getTextSize() / 3f, labelPaint);
            }
        }
    }

    // ── Helper: build a regular polygon path ──────────────────────────────────

    private Path buildPolygon(float cx, float cy, float r, int n, float angleOffset) {
        Path path = new Path();
        for (int i = 0; i < n; i++) {
            double angle = axisAngle(i, n) + angleOffset;
            float x = cx + r * (float) Math.cos(angle);
            float y = cy + r * (float) Math.sin(angle);
            if (i == 0) path.moveTo(x, y);
            else        path.lineTo(x, y);
        }
        path.close();
        return path;
    }

    // ── Helper: build a data polygon from category scores ────────────────────

    private Path buildDataPolygon(float cx, float cy, float radius, int n, boolean useProject) {
        Path path = new Path();
        for (int i = 0; i < n; i++) {
            CategoryScore cat = categories.get(i);
            float score = useProject ? cat.projectScore : cat.studentScore;
            float frac  = Math.min(score / 10f, 1f);
            double angle = axisAngle(i, n);
            float x = cx + radius * frac * (float) Math.cos(angle);
            float y = cy + radius * frac * (float) Math.sin(angle);
            if (i == 0) path.moveTo(x, y);
            else        path.lineTo(x, y);
        }
        path.close();
        return path;
    }

    // ── Helper: angle for axis i of n total axes ─────────────────────────────
    // Starts at -π/2 (top) so the first axis points straight up,
    // matching the SVG radar chart orientation.

    private double axisAngle(int i, int n) {
        return (2 * Math.PI * i / n) - (Math.PI / 2);
    }

    // ── Helper: draw "not enough data" message ────────────────────────────────

    private void drawInsufficientDataMessage(Canvas canvas) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#9CA3AF")); // gray-400
        p.setTextSize(spToPx(13f));
        p.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(
                "Not enough skill categories for radar chart",
                getWidth() / 2f, getHeight() / 2f, p
        );
    }

    // ── Unit conversion helpers ───────────────────────────────────────────────

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    private float spToPx(float sp) {
        return sp * getResources().getDisplayMetrics().scaledDensity;
    }

    private String join(String[] arr, int fromIndex) {
        StringBuilder sb = new StringBuilder();
        for (int i = fromIndex; i < arr.length; i++) {
            if (i > fromIndex) sb.append(" ");
            sb.append(arr[i]);
        }
        return sb.toString();
    }
}
