package com.example.project.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.adapters.ChatAdapter;
import com.example.project.ApplicationStatusManager;
import com.example.project.DatabaseHelper;
import com.example.project.SessionManager;
import com.example.project.models.ProjectApplication;
import com.example.project.models.ChatMessage;
import com.example.project.Config;
import com.example.project.models.Event;
import com.example.project.models.Project;
import com.example.project.ProjectManager;
import com.example.project.models.ScheduleItem;
import com.example.project.ScheduleManager;
import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.ai.client.generativeai.type.RequestOptions;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ChatFragment extends Fragment {

    private final List<ChatMessage> messages = new ArrayList<>();
    private ChatAdapter adapter;
    private GenerativeModelFutures model;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean isListening = false;
    private static final int PERMISSION_RECORD_AUDIO = 1;
    private Bitmap selectedImage = null;

    private final ActivityResultLauncher<Intent> pickImageLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Uri imageUri = result.getData().getData();
                    try {
                        InputStream imageStream = getContext().getContentResolver().openInputStream(imageUri);
                        selectedImage = BitmapFactory.decodeStream(imageStream);
                        Toast.makeText(getContext(), "Image attached", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Log.e("ChatFragment", "Error loading image", e);
                    }
                }
            }
    );

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chat, container, false);

        // This is the absolute fix for the 'String cannot be converted to Long' error
        // We pass 60000L (a Long literal) and "v1" (the stable API version)
        RequestOptions requestOptions = new RequestOptions(60000L, "v1");

        GenerativeModel gm = new GenerativeModel(
                Config.MODEL_NAME, 
                Config.GEMINI_API_KEY,
                null, // generationConfig
                null, // safetySettings
                requestOptions
        );
        model = GenerativeModelFutures.from(gm);

        RecyclerView recyclerView = view.findViewById(R.id.rv_chat);
        EditText inputField = view.findViewById(R.id.et_chat_input);
        View sendButton = view.findViewById(R.id.btn_send);
        View voiceButton = view.findViewById(R.id.btn_voice);
        View attachButton = view.findViewById(R.id.btn_attach);

        adapter = new ChatAdapter(messages);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        sendButton.setOnClickListener(v -> {
            String text = inputField.getText().toString().trim();
            if (!text.isEmpty() || selectedImage != null) {
                sendMessage(text, selectedImage);
                inputField.setText("");
                selectedImage = null;
            }
        });

        initSpeech();

        voiceButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_RECORD_AUDIO);
            } else {
                toggleSpeechRecognition();
            }
        });

        attachButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            pickImageLauncher.launch(intent);
        });

        return view;
    }

    private void initSpeech() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { stopListeningFeedback(); }
            @Override public void onError(int error) { stopListeningFeedback(); }
            @Override public void onResults(Bundle results) {
                stopListeningFeedback();
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    sendMessage(matches.get(0), null);
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        textToSpeech = new TextToSpeech(getContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(Locale.US);
            }
        });
    }

    private void toggleSpeechRecognition() {
        if (isListening) {
            speechRecognizer.stopListening();
            isListening = false;
        } else {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            speechRecognizer.startListening(intent);
            isListening = true;
            Toast.makeText(getContext(), "Listening...", Toast.LENGTH_SHORT).show();
            
            // Visual feedback for the button
            View voiceButton = getView().findViewById(R.id.btn_voice);
            if (voiceButton instanceof com.google.android.material.button.MaterialButton) {
                ((com.google.android.material.button.MaterialButton) voiceButton).setIconTintResource(android.R.color.holo_red_light);
            }
        }
    }

    private void stopListeningFeedback() {
        isListening = false;
        if (getView() != null) {
            View voiceButton = getView().findViewById(R.id.btn_voice);
            if (voiceButton instanceof com.google.android.material.button.MaterialButton) {
                ((com.google.android.material.button.MaterialButton) voiceButton).setIconTintResource(android.R.color.white);
            }
        }
    }

    private void speak(String text) {
        if (textToSpeech != null) {
            // Split long text into smaller chunks for better TTS performance
            String[] sentences = text.split("(?<=[.!?])\\s+");
            for (String sentence : sentences) {
                textToSpeech.speak(sentence, TextToSpeech.QUEUE_ADD, null, "msgId_" + System.currentTimeMillis());
            }
        }
    }

    @Override
    public void onDestroy() {
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (textToSpeech != null) textToSpeech.shutdown();
        super.onDestroy();
    }

    private void sendMessage(String userText, Bitmap image) {
        messages.add(new ChatMessage(userText, true, image));
        adapter.notifyItemInserted(messages.size() - 1);

        StringBuilder context = new StringBuilder("You are a University Career Assistant with access to the user's university ecosystem and profile.\n\n");
        // ... (rest of the context building)
        
        // Let's use simplified context for the prompt if there's an image
        if (image != null) {
            context.append("\n[The user has attached an image for analysis. Please provide insights based on the image and the context provided.]");
        }

        context.append("\n--- EVENTS ---\n");
        for (Event e : Event.getMockEvents()) {
            context.append("- ").append(e.getName())
                   .append(" on ").append(e.getDate()).append(" at ").append(e.getTime())
                   .append(" (Location: ").append(e.getLocation()).append("). ")
                   .append(e.getDescription()).append("\n");
        }

        context.append("\n--- RESEARCH PROJECTS ---\n");
        for (Project p : ProjectManager.getInstance(getContext()).getProjects()) {
            context.append("- Title: ").append(p.getTitle())
                   .append(" (").append(p.getStatus()).append(")")
                   .append(", under ").append(p.getProfessor())
                   .append(". Tech Stack: ").append(p.getStack()).append("\n");
        }

        context.append("\n--- USER'S SCHEDULE ---\n");
        for (ScheduleItem s : ScheduleManager.getInstance(getContext()).getScheduledItems()) {
            context.append("- ").append(s.getTitle())
                   .append(" (").append(s.getType()).append(")")
                   .append(" at ").append(s.getDateTime());
            if (s.getProfessorName() != null) {
                context.append(" with ").append(s.getProfessorName());
            }
            context.append("\n");
        }

        context.append("\n--- USER'S APPLICATIONS ---\n");
        String uid = SessionManager.getInstance(getContext()).getUid();
        for (ProjectApplication a : ApplicationStatusManager.getInstance(getContext()).getApplications(uid)) {
            Project p = DatabaseHelper.getInstance(getContext()).getProjectById(a.projectId);
            context.append("- Project: ").append(p != null ? p.getTitle() : a.projectId)
                   .append(" (Status: ").append(a.status).append(")\n");
        }

        context.append("\nAnswer the following request using the above context if relevant: ").append(userText);

        Content.Builder contentBuilder = new Content.Builder();
        contentBuilder.addText(context.toString());
        if (image != null) {
            contentBuilder.addImage(image);
        }
        Content content = contentBuilder.build();

        ListenableFuture<GenerateContentResponse> response = model.generateContent(content);

        Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
            @Override
            public void onSuccess(GenerateContentResponse result) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        String resultText = result.getText();
                        messages.add(new ChatMessage(resultText != null ? resultText : "No response.", false));
                        adapter.notifyItemInserted(messages.size() - 1);
                        if (resultText != null) {
                            speak(resultText);
                        }
                    });
                }
            }

            @Override
            public void onFailure(Throwable t) {
                // If it fails with an image, we try fallback WITHOUT image because OpenRouter implementation here only supports text for now
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        com.example.project.AIFallbackManager.callWithFallback(null, context.toString(), new com.example.project.AIFallbackManager.AICallback() {
                            @Override
                            public void onSuccess(String result) {
                                if (getActivity() != null) {
                                    getActivity().runOnUiThread(() -> {
                                        messages.add(new ChatMessage(result, false));
                                        adapter.notifyItemInserted(messages.size() - 1);
                                        speak(result);
                                    });
                                }
                            }

                            @Override
                            public void onFailure(Throwable t2) {
                                if (getActivity() != null) {
                                    getActivity().runOnUiThread(() -> {
                                        messages.add(new ChatMessage("AI Error: " + t2.getMessage(), false));
                                        adapter.notifyItemInserted(messages.size() - 1);
                                    });
                                }
                            }
                        });
                    });
                }
            }
        }, Executors.newSingleThreadExecutor());
    }
}
