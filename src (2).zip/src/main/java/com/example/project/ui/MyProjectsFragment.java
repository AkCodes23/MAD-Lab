package com.example.project.ui;

import com.example.project.adapters.*;
import com.example.project.ml.*;
import com.example.project.models.*;
import com.example.project.ProjectManager;
import com.example.project.DatabaseHelper;
import com.example.project.R;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyProjectsFragment extends Fragment implements ProjectAdapter.OnProjectClickListener {

    private RecyclerView recyclerView;
    private ProjectAdapter adapter;
    private SwipeRefreshLayout swipeRefresh;
    private TextView emptyState;
    private UserProfile currentProfile;
    private ExecutorService executor = Executors.newSingleThreadExecutor();

    public static MyProjectsFragment newInstance(UserProfile profile) {
        MyProjectsFragment fragment = new MyProjectsFragment();
        fragment.currentProfile = profile;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_projects, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.rv_my_projects);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        emptyState = view.findViewById(R.id.tv_empty_state);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new ProjectAdapter(this);
        adapter.setFacultyMode(true);
        recyclerView.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(this::fetchMyProjects);
        fetchMyProjects();

        view.findViewById(R.id.fab_add_project).setOnClickListener(v -> {
            // Navigate to add project fragment (omitted for brevity)
        });
    }

    private void fetchMyProjects() {
        if (currentProfile == null) return;
        swipeRefresh.setRefreshing(true);
        List<Project> projects = ProjectManager.getInstance(getContext()).getProjectsByFaculty(currentProfile.getUid());
        adapter.updateData(projects);
        emptyState.setVisibility(projects.isEmpty() ? View.VISIBLE : View.GONE);
        swipeRefresh.setRefreshing(false);
    }

    @Override
    public void onProjectClick(Project project) {
        showInterestedStudentsSheet(project);
    }

    private void showInterestedStudentsSheet(Project project) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext());
        View sheetView = getLayoutInflater().inflate(R.layout.bottom_sheet_interests, null);
        dialog.setContentView(sheetView);

        LinearLayout container = sheetView.findViewById(R.id.container_interests);
        TextView emptyInterests = sheetView.findViewById(R.id.tv_empty_interests);

        List<ProjectInterest> interests = DatabaseHelper.getInstance(getContext()).getInterestsForProject(project.getId());
        if (interests.isEmpty()) {
            emptyInterests.setVisibility(View.VISIBLE);
        } else {
            for (ProjectInterest interest : interests) {
                addStudentRow(container, interest, project);
            }
        }

        dialog.show();
    }

    private void addStudentRow(LinearLayout container, ProjectInterest interest, Project project) {
        View row = getLayoutInflater().inflate(R.layout.item_student_interest_row, container, false);
        TextView name = row.findViewById(R.id.student_name);
        TextView email = row.findViewById(R.id.student_email);
        Button btnAnalyze = row.findViewById(R.id.btn_analyze_fit);
        FrameLayout panelContainer = row.findViewById(R.id.container_alignment_panel);

        name.setText(interest.getStudentName());
        email.setText(interest.getStudentEmail());

        final boolean[] panelVisible = {false};
        final AlignmentResult[] cachedResult = {null};

        btnAnalyze.setOnClickListener(v -> {
            if (panelVisible[0]) {
                panelContainer.setVisibility(View.GONE);
                panelVisible[0] = false;
                btnAnalyze.setText(R.string.btn_analyze_fit);
            } else {
                if (cachedResult[0] != null) {
                    panelContainer.setVisibility(View.VISIBLE);
                    panelVisible[0] = true;
                    btnAnalyze.setText(R.string.btn_hide_analysis);
                } else {
                    btnAnalyze.setText(R.string.btn_analyzing);
                    btnAnalyze.setEnabled(false);
                    
                    UserProfile studentProfile = DatabaseHelper.getInstance(getContext()).getUserProfile(interest.getStudentId());
                    if (studentProfile != null && studentProfile.hasBio()) {
                        executor.submit(() -> {
                            AlignmentResult result = SkillAnalysisEngine.getInstance()
                                    .analyzeAlignment(studentProfile.getBio(), project.getFullText());
                            
                            if (getActivity() != null) {
                                getActivity().runOnUiThread(() -> {
                                    cachedResult[0] = result;
                                    getChildFragmentManager().beginTransaction()
                                            .replace(panelContainer.getId(), SkillAlignmentFragment.forFaculty(result, studentProfile.getName()))
                                            .commitNow();
                                    panelContainer.setVisibility(View.VISIBLE);
                                    panelVisible[0] = true;
                                    btnAnalyze.setText(R.string.btn_hide_analysis);
                                    btnAnalyze.setEnabled(true);
                                });
                            }
                        });
                    } else {
                        btnAnalyze.setText(R.string.btn_no_bio);
                        btnAnalyze.setEnabled(false);
                    }
                }
            }
        });

        container.addView(row);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
