package com.example.project.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.project.R;
import com.example.project.DatabaseHelper;
import com.example.project.SessionManager;
import com.example.project.ml.SkillAnalysisEngine;
import com.example.project.ml.SkillTaxonomy;
import com.example.project.ApplicationStatusManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.project.adapters.ApplicationAdapter;
import com.example.project.models.ProjectApplication;
import com.example.project.models.UserProfile;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.InputStream;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ProfileFragment extends Fragment {

    private UserProfile currentProfile;
    private EditText etName, etBio, etOfficeLocation, etOfficeHours;
    private TextView tvBioHint, tvResumeStatus;
    private View facultySection, studentResumeSection;
    private Button btnUploadResume;
    private ProgressBar pbResumeLoading;
    private RecyclerView rvApplications;
    private ApplicationAdapter appAdapter;
    private final Executor executor = Executors.newSingleThreadExecutor();

    private final ActivityResultLauncher<Intent> resumePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) {
                        parseResume(uri);
                    }
                }
            }
    );

    public static ProfileFragment newInstance(UserProfile profile) {
        ProfileFragment fragment = new ProfileFragment();
        fragment.currentProfile = profile;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        
        etName = view.findViewById(R.id.et_profile_name);
        etBio = view.findViewById(R.id.et_profile_bio);
        etOfficeLocation = view.findViewById(R.id.et_office_location);
        etOfficeHours = view.findViewById(R.id.et_office_hours);
        tvBioHint = view.findViewById(R.id.tv_bio_hint);
        tvResumeStatus = view.findViewById(R.id.tv_resume_status);
        facultySection = view.findViewById(R.id.faculty_profile_section);
        studentResumeSection = view.findViewById(R.id.student_resume_section);
        btnUploadResume = view.findViewById(R.id.btn_upload_resume);
        pbResumeLoading = view.findViewById(R.id.pb_resume_loading);
        rvApplications = view.findViewById(R.id.rv_student_applications);

        TextView tvAppsTitle = view.findViewById(R.id.tv_my_applications_title);

        if (currentProfile != null && !currentProfile.isFaculty()) {
            tvAppsTitle.setVisibility(View.VISIBLE);
            rvApplications.setVisibility(View.VISIBLE);
            appAdapter = new ApplicationAdapter(new java.util.ArrayList<>());
            rvApplications.setAdapter(appAdapter);
            fetchApplications();
        }

        Button btnAddSkill = view.findViewById(R.id.btn_add_manual_skill);
        if (currentProfile != null && !currentProfile.isFaculty()) {
            btnAddSkill.setVisibility(View.VISIBLE);
            btnAddSkill.setOnClickListener(v -> showAddSkillDialog());
        } else {
            btnAddSkill.setVisibility(View.GONE);
        }

        PDFBoxResourceLoader.init(getContext());

        if (currentProfile != null) {
            etName.setText(currentProfile.getName());
            etBio.setText(currentProfile.getBio());
            
            if (currentProfile.isFaculty()) {
                facultySection.setVisibility(View.VISIBLE);
                studentResumeSection.setVisibility(View.GONE);
                etOfficeLocation.setText(currentProfile.getOfficeLocation());
                etOfficeHours.setText(currentProfile.getOfficeHours());
                tvBioHint.setVisibility(View.GONE);
            } else {
                facultySection.setVisibility(View.GONE);
                studentResumeSection.setVisibility(View.VISIBLE);
                if (!currentProfile.hasBio()) {
                    tvBioHint.setVisibility(View.VISIBLE);
                } else {
                    tvBioHint.setVisibility(View.GONE);
                }
            }
        }

        btnUploadResume.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("application/pdf");
            resumePickerLauncher.launch(intent);
        });

        view.findViewById(R.id.btn_save_profile).setOnClickListener(v -> saveProfile());

        view.findViewById(R.id.btn_logout).setOnClickListener(v -> {
            SessionManager.getInstance(getActivity()).logout();
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            getActivity().finish();
        });

        return view;
    }

    private void parseResume(Uri uri) {
        pbResumeLoading.setVisibility(View.VISIBLE);
        tvResumeStatus.setText(R.string.msg_parsing_pdf);

        executor.execute(() -> {
            try (InputStream inputStream = getContext().getContentResolver().openInputStream(uri)) {
                PDDocument document = PDDocument.load(inputStream);
                PDFTextStripper stripper = new PDFTextStripper();
                String text = stripper.getText(document);
                document.close();

                // Skill extraction and scoring
                SkillAnalysisEngine engine = SkillAnalysisEngine.getInstance();
                java.util.Map<String, Integer> skills = engine.extractSkillVector(text);
                
                StringBuilder skillsBio = new StringBuilder();
                for (java.util.Map.Entry<String, Integer> entry : skills.entrySet()) {
                    skillsBio.append(entry.getKey()).append(" (").append(entry.getValue()).append("/10), ");
                }
                
                String finalBio = skillsBio.length() > 2 ? skillsBio.substring(0, skillsBio.length() - 2) : text;
                
                // Calculate resume score (simple heuristic: average of top 5 skills)
                List<Integer> weights = new java.util.ArrayList<>(skills.values());
                java.util.Collections.sort(weights, java.util.Collections.reverseOrder());
                float score = 0;
                int count = Math.min(weights.size(), 5);
                for (int i = 0; i < count; i++) score += weights.get(i);
                float finalScore = count > 0 ? score / count : 0;

                getActivity().runOnUiThread(() -> {
                    pbResumeLoading.setVisibility(View.GONE);
                    if (text != null && !text.isEmpty()) {
                        etBio.setText(finalBio);
                        tvResumeStatus.setText(getString(R.string.msg_resume_parsed) + " Score: " + String.format("%.1f", finalScore) + "/10");
                        ApplicationStatusManager.getInstance(getContext()).setResumeAnalyzed(true);
                        Toast.makeText(getContext(), "Skills extracted and scored", Toast.LENGTH_SHORT).show();
                    } else {
                        tvResumeStatus.setText(R.string.msg_resume_failed);
                    }
                });
            } catch (Exception e) {
                getActivity().runOnUiThread(() -> {
                    pbResumeLoading.setVisibility(View.GONE);
                    tvResumeStatus.setText(getString(R.string.msg_resume_error, e.getMessage()));
                });
            }
        });
    }

    private void showAddSkillDialog() {
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_skill, null);
        Spinner spinner = dialogView.findViewById(R.id.spinner_skills);
        Spinner levelSpinner = dialogView.findViewById(R.id.spinner_proficiency);

        List<String> skillNames = new java.util.ArrayList<>();
        for (SkillTaxonomy.SkillEntry entry : SkillTaxonomy.getAll()) {
            skillNames.add(entry.name);
        }
        java.util.Collections.sort(skillNames);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, skillNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        String[] levels = {"Familiar (3/10)", "Proficient (6/10)", "Expert (9/10)"};
        ArrayAdapter<String> levelAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, levels);
        levelAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        levelSpinner.setAdapter(levelAdapter);

        new AlertDialog.Builder(getContext(), R.style.DarkDialogTheme)
                .setTitle("Add Skill to Profile")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String selectedSkill = (String) spinner.getSelectedItem();
                    int level = (levelSpinner.getSelectedItemPosition() + 1) * 3;
                    appendSkillToBio(selectedSkill, level);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void appendSkillToBio(String skill, int weight) {
        String currentBio = etBio.getText().toString();
        String skillEntry = skill + " (" + weight + "/10)";
        
        if (currentBio.contains(skill)) {
            // Replace existing entry if present
            currentBio = currentBio.replaceAll(skill + " \\(\\d+/10\\)", skillEntry);
        } else {
            if (!currentBio.isEmpty() && !currentBio.endsWith(" ")) {
                currentBio += ", ";
            }
            currentBio += skillEntry;
        }
        
        etBio.setText(currentBio);
        saveProfile();
        Toast.makeText(getContext(), "Skill added to analysis engine", Toast.LENGTH_SHORT).show();
    }

    private void fetchApplications() {
        if (currentProfile == null || currentProfile.isFaculty()) return;
        List<ProjectApplication> apps = DatabaseHelper.getInstance(getContext()).getStudentApplications(currentProfile.getUid());
        appAdapter.updateData(apps);
    }

    private void saveProfile() {
        if (currentProfile == null) return;

        currentProfile.setBio(etBio.getText().toString());
        if (currentProfile.isFaculty()) {
            currentProfile.setOfficeLocation(etOfficeLocation.getText().toString());
            currentProfile.setOfficeHours(etOfficeHours.getText().toString());
        }

        DatabaseHelper.getInstance(getContext()).insertOrUpdateUser(currentProfile);
        Toast.makeText(getContext(), "Profile updated", Toast.LENGTH_SHORT).show();
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).onProfileUpdated(currentProfile);
        }
    }
}
