package com.example.project.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.project.Config;
import com.example.project.R;
import com.example.project.ProjectManager;
import com.example.project.SessionManager;
import com.example.project.models.Project;
import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONObject;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class FacultyUploadFragment extends Fragment {

    private GenerativeModelFutures model;
    private final Executor executor = Executors.newSingleThreadExecutor();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_faculty_upload, container, false);

        GenerativeModel gm = new GenerativeModel(Config.MODEL_NAME, Config.GEMINI_API_KEY);
        model = GenerativeModelFutures.from(gm);

        EditText etTitle = view.findViewById(R.id.et_fac_title);
        EditText etDesc = view.findViewById(R.id.et_fac_desc);
        EditText etSkills = view.findViewById(R.id.et_fac_skills);
        Button btnUpload = view.findViewById(R.id.btn_fac_upload);
        Button btnOptimize = view.findViewById(R.id.btn_optimize_desc);

        btnOptimize.setOnClickListener(v -> optimizeProjectListing(etTitle, etDesc, etSkills, btnOptimize));

        btnUpload.setOnClickListener(v -> {
            String title = etTitle.getText().toString();
            String desc = etDesc.getText().toString();
            String skillsStr = etSkills.getText().toString();
            
            String profName = "Dr. Faculty";
            String profId = SessionManager.getInstance(getContext()).getUid();
            if (getActivity() instanceof FacultyActivity) {
                profName = ((FacultyActivity) getActivity()).getFacultyName();
            }

            if (profId == null) {
                profId = "local_faculty_id"; // Fallback
            }

            if (!title.isEmpty() && !desc.isEmpty()) {
                String[] skillsArray = skillsStr.split(",");
                for (int i = 0; i < skillsArray.length; i++) {
                    skillsArray[i] = skillsArray[i].trim();
                }

                Project newProject = new Project(title, profName, profId, desc, skillsStr, "open", skillsArray);
                ProjectManager.getInstance(getContext()).addProject(newProject);
                
                Toast.makeText(getContext(), R.string.msg_project_published, Toast.LENGTH_SHORT).show();
                etTitle.setText("");
                etDesc.setText("");
                etSkills.setText("");
            } else {
                Toast.makeText(getContext(), R.string.msg_fill_all_fields, Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    private void optimizeProjectListing(EditText etTitle, EditText etDesc, EditText etSkills, Button btnOptimize) {
        String title = etTitle.getText().toString().trim();
        String desc = etDesc.getText().toString().trim();

        if (desc.isEmpty()) {
            Toast.makeText(getContext(), "Please enter a description to optimize", Toast.LENGTH_SHORT).show();
            return;
        }

        btnOptimize.setEnabled(false);
        btnOptimize.setText("AI Optimizing...");

        String prompt = "You are an assistant for university professors. Refine the following research project description to be more professional and appealing to students. Also, identify the key technical skills required.\n\n" +
                "Current Title: " + title + "\n" +
                "Current Description: " + desc + "\n\n" +
                "Respond ONLY with a JSON object in this format: {\"refined_description\": \"...\", \"suggested_skills\": \"skill1, skill2, skill3\"}";

        com.example.project.AIFallbackManager.callWithFallback(model, prompt, new com.example.project.AIFallbackManager.AICallback() {
            @Override
            public void onSuccess(String result) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        try {
                            JSONObject json = new JSONObject(result.substring(result.indexOf("{"), result.lastIndexOf("}") + 1));
                            etDesc.setText(json.getString("refined_description"));
                            etSkills.setText(json.getString("suggested_skills"));
                            btnOptimize.setText("Optimized!");
                            btnOptimize.setEnabled(true);
                        } catch (Exception e) {
                            btnOptimize.setText("AI: Refine & Suggest Skills");
                            btnOptimize.setEnabled(true);
                            Toast.makeText(getContext(), "Parsing Error", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onFailure(Throwable t) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        btnOptimize.setText("AI: Refine & Suggest Skills");
                        btnOptimize.setEnabled(true);
                        Toast.makeText(getContext(), "AI Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }
}
