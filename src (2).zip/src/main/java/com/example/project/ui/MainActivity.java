package com.example.project.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import com.example.project.workers.StaleApplicationWorker;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.example.project.DatabaseHelper;
import com.example.project.SessionManager;
import com.example.project.models.*;
import com.example.project.R;

public class MainActivity extends AppCompatActivity {

    private UserProfile currentProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        // Load initial fragment even before profile is fetched
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, ProjectDiscoveryFragment.newInstance(currentProfile))
                .commit();

        fetchUserProfile(bottomNav);

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int itemId = item.getItemId();

            if (itemId == R.id.navigation_research) {
                selectedFragment = ProjectDiscoveryFragment.newInstance(currentProfile);
            } else if (itemId == R.id.navigation_events) {
                selectedFragment = new EventFragment();
            } else if (itemId == R.id.navigation_chat) {
                selectedFragment = new ChatFragment();
            } else if (itemId == R.id.navigation_schedule) {
                if (currentProfile != null && currentProfile.isFaculty()) {
                    selectedFragment = MyProjectsFragment.newInstance(currentProfile);
                } else {
                    selectedFragment = FacultyInteractionFragment.newInstance(currentProfile);
                }
            } else if (itemId == R.id.navigation_profile) {
                selectedFragment = ProfileFragment.newInstance(currentProfile);
            }

            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, selectedFragment)
                        .commit();
                return true;
            }
            return false;
        });
    }

    private void fetchUserProfile(BottomNavigationView bottomNav) {
        String uid = SessionManager.getInstance(this).getUid();
        if (uid == null) {
            // Should not happen if LoginActivity is working correctly
            currentProfile = new UserProfile("mock_student_id", "Student", "student@example.com", "student");
            updateNavLabels(bottomNav);
            scheduleStaleAppWorker(currentProfile.getUid());
            return;
        }

        DatabaseHelper db = DatabaseHelper.getInstance(this);
        currentProfile = db.getUserProfile(uid);

        if (currentProfile == null) {
            // Create default profile if not exists
            currentProfile = new UserProfile(uid, "Student User", "student@example.com", "student");
            db.insertOrUpdateUser(currentProfile);
        }

        updateNavLabels(bottomNav);
        scheduleStaleAppWorker(currentProfile.getUid());

        // Refresh current fragment to pass the profile
        Fragment current = getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        if (current instanceof ProjectDiscoveryFragment) {
            ((ProjectDiscoveryFragment) current).updateProfile(currentProfile);
        }
    }

    private void scheduleStaleAppWorker(String userId) {
        Data data = new Data.Builder()
                .putString("userId", userId)
                .build();

        PeriodicWorkRequest staleAppRequest = new PeriodicWorkRequest.Builder(
                StaleApplicationWorker.class, 24, java.util.concurrent.TimeUnit.HOURS)
                .setInputData(data)
                .build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "stale_app_notification",
                ExistingPeriodicWorkPolicy.KEEP,
                staleAppRequest);
    }

    private void updateNavLabels(BottomNavigationView bottomNav) {
        if (currentProfile == null) return;
        if (currentProfile.isFaculty()) {
            bottomNav.getMenu().findItem(R.id.navigation_schedule).setTitle("My Projects");
        } else {
            bottomNav.getMenu().findItem(R.id.navigation_schedule).setTitle("Appointments");
        }
    }

    public void onProfileUpdated(UserProfile profile) {
        this.currentProfile = profile;
    }

    public void navigateToFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }
}
