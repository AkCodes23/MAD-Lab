package com.example.project.ui;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.DatabaseHelper;
import com.example.project.adapters.ScheduleAdapter;
import com.example.project.models.ScheduleItem;
import com.example.project.ScheduleManager;
import com.example.project.models.UserProfile;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.database.Cursor;

public class FacultyInteractionFragment extends Fragment {

    private RecyclerView rvSchedule;
    private ScheduleAdapter scheduleAdapter;
    private TextView emptyState;
    private UserProfile currentProfile;

    public static FacultyInteractionFragment newInstance(UserProfile profile) {
        FacultyInteractionFragment fragment = new FacultyInteractionFragment();
        fragment.currentProfile = profile;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_faculty_interaction, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvSchedule = view.findViewById(R.id.rv_my_schedule);
        emptyState = view.findViewById(R.id.tv_empty_schedule);

        rvSchedule.setLayoutManager(new LinearLayoutManager(getContext()));
        scheduleAdapter = new ScheduleAdapter(new ArrayList<>(), currentProfile.getRole());
        rvSchedule.setAdapter(scheduleAdapter);

        fetchSchedule();
    }

    private void fetchSchedule() {
        if (currentProfile == null) return;
        List<ScheduleItem> items = ScheduleManager.getInstance(getContext()).getScheduledItems();
        scheduleAdapter.updateData(items);
        emptyState.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void showBookAppointmentSheet() {
        // This method is now unused as per the new requirements
    }
}
