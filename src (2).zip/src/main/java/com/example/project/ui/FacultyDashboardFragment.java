package com.example.project.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.ProjectManager;
import com.example.project.R;
import com.example.project.DatabaseHelper;
import com.example.project.SessionManager;
import com.example.project.adapters.ProjectAdapter;
import com.example.project.models.Project;
import com.example.project.models.ProjectApplication;

import java.util.ArrayList;
import java.util.List;

public class FacultyDashboardFragment extends Fragment implements ProjectAdapter.OnProjectClickListener {

    private String facultyName;
    private ProjectAdapter adapter;

    public static FacultyDashboardFragment newInstance(String facultyName) {
        FacultyDashboardFragment fragment = new FacultyDashboardFragment();
        Bundle args = new Bundle();
        args.putString("FACULTY_NAME", facultyName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            facultyName = getArguments().getString("FACULTY_NAME");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_faculty_dashboard, container, false);

        TextView tvWelcome = view.findViewById(R.id.tv_fac_welcome);
        if (tvWelcome != null) {
            tvWelcome.setText("Welcome, " + facultyName);
        }

        RecyclerView recyclerView = view.findViewById(R.id.rv_faculty_manage);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        
        adapter = new ProjectAdapter(this);
        adapter.setFacultyMode(true);
        recyclerView.setAdapter(adapter);

        TextView emptyView = view.findViewById(R.id.tv_empty_view);
        emptyView.setText("No projects published yet.");

        fetchProjects(emptyView);

        view.findViewById(R.id.btn_add_slot).setOnClickListener(v -> showAddSlotDialog());

        view.findViewById(R.id.btn_fac_logout).setOnClickListener(v -> {
            SessionManager.getInstance(getActivity()).logout();
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            getActivity().finish();
        });

        return view;
    }

    private void fetchProjects(TextView emptyView) {
        String currentUid = SessionManager.getInstance(getContext()).getUid();
        if (currentUid == null) return;

        List<Project> projects = ProjectManager.getInstance(getContext()).getProjectsByFaculty(currentUid);
        if (projects.isEmpty()) {
            emptyView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.GONE);
        }
        adapter.updateData(projects);
    }

    private void showAddSlotDialog() {
        android.app.DatePickerDialog datePicker = new android.app.DatePickerDialog(getContext(), (view, year, month, dayOfMonth) -> {
            String selectedDate = String.format(java.util.Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, dayOfMonth);
            showTimePickerForSlot(selectedDate);
        }, java.util.Calendar.getInstance().get(java.util.Calendar.YEAR), 
           java.util.Calendar.getInstance().get(java.util.Calendar.MONTH), 
           java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_MONTH));
        datePicker.setTitle("Select Date for New Slot");
        datePicker.show();
    }

    private void showTimePickerForSlot(String date) {
        android.app.TimePickerDialog timePicker = new android.app.TimePickerDialog(getContext(), (view, hourOfDay, minute) -> {
            String selectedTime = String.format(java.util.Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
            saveSlot(date, selectedTime);
        }, 10, 0, true);
        timePicker.setTitle("Select Time for " + date);
        timePicker.show();
    }

    private void saveSlot(String date, String time) {
        String profId = SessionManager.getInstance(getContext()).getUid();
        DatabaseHelper.getInstance(getContext()).addFacultySlot(profId, date, time);
        android.widget.Toast.makeText(getContext(), "Slot added: " + date + " at " + time, android.widget.Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProjectClick(Project project) {
        // Navigate to show applications for this project
        getParentFragmentManager().beginTransaction()
                .replace(R.id.faculty_fragment_container, ProjectApplicationsFragment.newInstance(project.getId()))
                .addToBackStack(null)
                .commit();
    }
}
