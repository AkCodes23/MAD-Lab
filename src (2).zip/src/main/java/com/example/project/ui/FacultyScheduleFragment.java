package com.example.project.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.adapters.ScheduleAdapter;
import com.example.project.models.ScheduleItem;
import com.example.project.ScheduleManager;

import java.util.ArrayList;
import java.util.List;

public class FacultyScheduleFragment extends Fragment {

    private String facultyName;

    public static FacultyScheduleFragment newInstance(String facultyName) {
        FacultyScheduleFragment fragment = new FacultyScheduleFragment();
        Bundle args = new Bundle();
        args.putString("FACULTY_NAME", facultyName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            facultyName = getArguments().getString("FACULTY_NAME");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_schedule, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.schedule_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Filter schedule items to only show meetings with THIS professor
        List<ScheduleItem> allItems = ScheduleManager.getInstance(requireContext()).getScheduledItems();
        List<ScheduleItem> filteredItems = new ArrayList<>();
        
        for (ScheduleItem item : allItems) {
            // Show events (global) and meetings specific to this professor
            if ("Event".equals(item.getType()) || (item.getProfessorName() != null && item.getProfessorName().equals(facultyName))) {
                filteredItems.add(item);
            }
        }

        ScheduleAdapter adapter = new ScheduleAdapter(filteredItems, "Faculty");
        recyclerView.setAdapter(adapter);

        return view;
    }
}
