package com.example.project.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.adapters.SkillBreakdownAdapter;
import com.example.project.models.AlignmentResult;
import com.example.project.models.AnomalyFlag;
import com.example.project.views.RadarChartView;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;

public class SkillAlignmentFragment extends Fragment {

    private AlignmentResult result;
    private String mode; // "student" or "faculty"
    private String studentName;

    public static SkillAlignmentFragment forStudent(AlignmentResult result) {
        SkillAlignmentFragment fragment = new SkillAlignmentFragment();
        fragment.result = result;
        fragment.mode = "student";
        return fragment;
    }

    public static SkillAlignmentFragment forFaculty(AlignmentResult result, String studentName) {
        SkillAlignmentFragment fragment = new SkillAlignmentFragment();
        fragment.result = result;
        fragment.mode = "faculty";
        fragment.studentName = studentName;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_skill_alignment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView titleView = view.findViewById(R.id.tv_alignment_title);
        TextView scoreLabel = view.findViewById(R.id.overall_score_label);
        TextView scoreValue = view.findViewById(R.id.overall_score_value);
        TextView summaryView = view.findViewById(R.id.analysis_summary);
        RadarChartView radarChart = view.findViewById(R.id.radar_chart);
        RecyclerView recyclerView = view.findViewById(R.id.rv_skill_breakdown);
        LinearLayout feedbackContainer = view.findViewById(R.id.feedback_container);

        scoreValue.setText(String.valueOf(result.overallScore));

        if ("faculty".equals(mode) && studentName != null) {
            titleView.setText(getString(R.string.analysis_title_faculty, studentName));
            summaryView.setText(result.summaryForProfessor);
        } else {
            titleView.setText(getString(R.string.analysis_title_student));
            summaryView.setText(getString(R.string.analysis_default_summary));
        }
        
        if (result.isStrongFit()) {
            scoreLabel.setText(R.string.label_strong_fit);
            scoreLabel.setTextColor(Color.parseColor("#4CAF50"));
        } else if (result.isPartialFit()) {
            scoreLabel.setText(R.string.label_partial_fit);
            scoreLabel.setTextColor(Color.parseColor("#FFC107"));
        } else {
            scoreLabel.setText(R.string.label_weak_fit);
            scoreLabel.setTextColor(Color.parseColor("#F44336"));
        }

        radarChart.setData(result.categoryScores);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        SkillBreakdownAdapter adapter = new SkillBreakdownAdapter();
        recyclerView.setAdapter(adapter);
        adapter.updateData(result.skillBreakdown, "faculty".equals(mode));

        // Populate feedback/recommendations
        feedbackContainer.removeAllViews();
        List<String> messages = getString(R.string.label_faculty_role).equals(mode) ? 
                filterFacultyFeedback(result.feedbackForStudent) : result.feedbackForStudent;

        for (String msg : messages) {
            View card = getLayoutInflater().inflate(R.layout.item_feedback_card, feedbackContainer, false);
            TextView text = card.findViewById(R.id.feedback_text);
            text.setText(msg);
            feedbackContainer.addView(card);
        }

        // Anomaly card (faculty only)
        MaterialCardView anomalyCard = view.findViewById(R.id.anomaly_card);
        if (getString(R.string.label_faculty_role).equals(mode) && result.anomalyReport != null && result.anomalyReport.isSuspicious) {
            anomalyCard.setVisibility(View.VISIBLE);
            TextView anomalySummary = view.findViewById(R.id.anomaly_summary);
            LinearLayout flagsContainer = view.findViewById(R.id.anomaly_flags_container);
            
            anomalySummary.setText(result.anomalyReport.summary);
            flagsContainer.removeAllViews();
            
            for (AnomalyFlag flag : result.anomalyReport.flags) {
                View flagView = getLayoutInflater().inflate(R.layout.item_anomaly_flag, flagsContainer, false);
                TextView label = flagView.findViewById(R.id.flag_label);
                TextView detail = flagView.findViewById(R.id.flag_detail);
                label.setText(flag.message);
                detail.setText(flag.detail);
                flagsContainer.addView(flagView);
            }
        } else {
            anomalyCard.setVisibility(View.GONE);
        }
    }

    private List<String> filterFacultyFeedback(List<String> feedback) {
        List<String> filtered = new ArrayList<>();
        for (String msg : feedback) {
            if (msg.contains("Gap") || msg.contains("Growth") || msg.contains("Summary")) {
                filtered.add(msg);
            }
        }
        return filtered;
    }
}
