package com.example.project.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.project.R;
import com.example.project.ProjectManager;
import com.example.project.ApplicationStatusManager;
import com.example.project.DatabaseHelper;
import com.example.project.ml.SkillAnalysisEngine;
import com.example.project.models.AlignmentResult;
import com.example.project.models.Project;
import com.example.project.models.ProjectApplication;
import com.example.project.models.ProjectInterest;
import com.example.project.models.UserProfile;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.example.project.Config;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProjectDetailFragment extends Fragment {

    private static final String ARG_PROJECT_ID = "project_id";

    private String projectId;
    private UserProfile currentProfile;
    private Project project;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private GenerativeModelFutures model;
    
    private Button btnInterest;
    private Button btnApply;
    private Button btnConsult;
    private TextView applicationStatus;
    private String currentInterestId;
    
    private Uri selectedResumeUri;
    private TextView tvResumeName;

    private final ActivityResultLauncher<Intent> resumePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    selectedResumeUri = result.getData().getData();
                    if (tvResumeName != null) {
                        tvResumeName.setText(getFileName(selectedResumeUri));
                    }
                }
            }
    );

    public static ProjectDetailFragment newInstance(String projectId, UserProfile profile) {
        ProjectDetailFragment fragment = new ProjectDetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PROJECT_ID, projectId);
        fragment.setArguments(args);
        fragment.currentProfile = profile;
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString(ARG_PROJECT_ID);
        }
        
        if (currentProfile == null && getContext() != null) {
            String uid = com.example.project.SessionManager.getInstance(getContext()).getUid();
            if (uid != null) {
                currentProfile = DatabaseHelper.getInstance(getContext()).getUserProfile(uid);
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_project_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        btnInterest = view.findViewById(R.id.btn_interest);
        btnApply = view.findViewById(R.id.btn_apply);
        btnConsult = view.findViewById(R.id.btn_consult);
        applicationStatus = view.findViewById(R.id.application_status);
        
        initAI();
        fetchProjectDetails(view);
        checkInterestStatus();
        checkApplicationStatus();
    }

    private void initAI() {
        GenerativeModel gm = new GenerativeModel(Config.MODEL_NAME, Config.GEMINI_API_KEY);
        model = GenerativeModelFutures.from(gm);
    }

    private void fetchProjectDetails(View view) {
        project = ProjectManager.getInstance(getContext()).getProjectById(projectId);
        if (project != null) {
            bindData(view);
            if (currentProfile != null && currentProfile.isStudent() && currentProfile.hasBio()) {
                runAlignmentAnalysis();
            }
        }
    }

    private void checkInterestStatus() {
        if (currentProfile == null || projectId == null) return;
        boolean interested = DatabaseHelper.getInstance(getContext()).isInterested(projectId, currentProfile.getUid());
        if (interested) {
            currentInterestId = projectId + "_" + currentProfile.getUid();
            btnInterest.setText(R.string.status_remove_interest);
        } else {
            currentInterestId = null;
            btnInterest.setText(R.string.status_interested);
        }
    }

    private void checkApplicationStatus() {
        if (currentProfile == null) return;
        boolean applied = ApplicationStatusManager.getInstance(getContext()).isAlreadyApplied(projectId, currentProfile.getUid());
        if (applied) {
            btnApply.setEnabled(false);
            btnApply.setText(R.string.status_applied);
            applicationStatus.setVisibility(View.VISIBLE);
            applicationStatus.setText(getString(R.string.application_status_label, "PENDING"));
        }
    }

    private void bindData(View view) {
        TextView title = view.findViewById(R.id.detail_title);
        TextView professor = view.findViewById(R.id.detail_professor);
        TextView description = view.findViewById(R.id.detail_description);
        TextView requirements = view.findViewById(R.id.detail_requirements);
        ChipGroup chipGroup = view.findViewById(R.id.detail_skills);

        title.setText(project.getTitle());
        professor.setText(project.getProfessor());
        description.setText(project.getDescription());
        requirements.setText(project.getRequirements());

        chipGroup.removeAllViews();
        if (project.getSkills() != null) {
            for (String skill : project.getSkills()) {
                Chip chip = new Chip(getContext());
                chip.setText(skill);
                chip.setChipBackgroundColorResource(R.color.chip_background);
                chip.setTextColor(Color.WHITE);
                chip.setChipStrokeWidth(0);
                chipGroup.addView(chip);
            }
        }
        
        btnInterest.setOnClickListener(v -> toggleInterest());
        btnApply.setOnClickListener(v -> {
            if (!ApplicationStatusManager.getInstance(getContext()).isResumeAnalyzed()) {
                Toast.makeText(getContext(), R.string.msg_apply_resume_parse_first, Toast.LENGTH_LONG).show();
                return;
            }
            showApplyBottomSheet();
        });

        btnConsult.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), ConsultationActivity.class);
            intent.putExtra("project_id", projectId);
            intent.putExtra("professor_name", project.getProfessor());
            startActivity(intent);
        });
    }

    private void toggleInterest() {
        if (currentProfile == null) {
            Toast.makeText(getContext(), R.string.msg_interest_login, Toast.LENGTH_SHORT).show();
            return;
        }
        if (project == null) {
            Toast.makeText(getContext(), R.string.msg_project_not_loaded, Toast.LENGTH_SHORT).show();
            return;
        }
        DatabaseHelper db = DatabaseHelper.getInstance(getContext());
        if (currentInterestId == null) {
            ProjectInterest interest = new ProjectInterest(
                    UUID.randomUUID().toString(),
                    projectId,
                    project.getTitle(),
                    currentProfile.getUid(),
                    currentProfile.getName(),
                    currentProfile.getEmail()
            );
            db.toggleInterest(interest, true);
        } else {
            ProjectInterest interest = new ProjectInterest(
                    null,
                    projectId,
                    null,
                    currentProfile.getUid(),
                    null,
                    null
            );
            db.toggleInterest(interest, false);
        }
        checkInterestStatus();
    }

    private void showApplyBottomSheet() {
        if (getContext() == null || project == null || currentProfile == null) return;

        AlignmentResult alignment = SkillAnalysisEngine.getInstance()
                .analyzeAlignment(currentProfile.getBio(), project.getFullText());

        BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), R.style.DarkDialogTheme);
        View view = getLayoutInflater().inflate(R.layout.bottom_sheet_apply, null);
        dialog.setContentView(view);

        TextView tvScore = view.findViewById(R.id.tv_apply_score);
        TextView tvFit = view.findViewById(R.id.tv_apply_fit_label);
        tvScore.setText(String.valueOf(alignment.overallScore));

        if (alignment.isStrongFit()) {
            tvFit.setText(R.string.label_strong_fit);
            tvScore.setTextColor(Color.parseColor("#4CAF50"));
        } else if (alignment.isPartialFit()) {
            tvFit.setText(R.string.label_partial_fit);
            tvScore.setTextColor(Color.parseColor("#FFC107"));
        } else {
            tvFit.setText(R.string.label_weak_fit);
            tvScore.setTextColor(Color.parseColor("#F44336"));
        }

        EditText etMessage = view.findViewById(R.id.et_message);
        Button btnSelectResume = view.findViewById(R.id.btn_select_resume);
        tvResumeName = view.findViewById(R.id.tv_resume_name);
        Button btnSubmit = view.findViewById(R.id.btn_submit_application);
        ProgressBar progress = view.findViewById(R.id.progress_apply);
        Button btnTailor = view.findViewById(R.id.btn_tailor_resume);
        View cvTailorSuggestions = view.findViewById(R.id.cv_tailor_suggestions);
        TextView tvTailorSuggestions = view.findViewById(R.id.tv_tailor_suggestions);

        btnTailor.setOnClickListener(v -> {
            btnTailor.setEnabled(false);
            btnTailor.setText(R.string.btn_analyzing_ai);
            
            String prompt = "Compare this student's skills/background with the project requirements and provide 3-5 specific, actionable bullet points on how they can improve their resume or statement of interest for THIS specific project. Keep it concise.\n\n" +
                    "Student Bio/Resume: " + currentProfile.getBio() + "\n\n" +
                    "Project Title: " + project.getTitle() + "\n" +
                    "Project Requirements: " + project.getRequirements();

            com.example.project.AIFallbackManager.callWithFallback(model, prompt, new com.example.project.AIFallbackManager.AICallback() {
                @Override
                public void onSuccess(String result) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            tvTailorSuggestions.setText(result);
                            cvTailorSuggestions.setVisibility(View.VISIBLE);
                            btnTailor.setText(R.string.btn_ai_suggestions_ready);
                            btnTailor.setEnabled(true);
                        });
                    }
                }

                @Override
                public void onFailure(Throwable t) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            Toast.makeText(getContext(), getString(R.string.msg_tailor_error, t.getMessage()), Toast.LENGTH_SHORT).show();
                            btnTailor.setEnabled(true);
                            btnTailor.setText(R.string.btn_ai_improve_resume);
                        });
                    }
                }
            });
        });

        btnSelectResume.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("application/pdf");
            resumePickerLauncher.launch(intent);
        });

        btnSubmit.setOnClickListener(v -> {
            String message = etMessage.getText().toString().trim();
            if (message.isEmpty()) {
                etMessage.setError(getString(R.string.error_required));
                return;
            }

            btnSubmit.setEnabled(false);
            progress.setVisibility(View.VISIBLE);

            String resumePath = selectedResumeUri != null ? selectedResumeUri.toString() : null;
            submitFinalApplication(message, resumePath, dialog, progress);
        });

        dialog.show();
    }

    private void submitFinalApplication(String message, String resumeUrl, BottomSheetDialog dialog, ProgressBar progress) {
        ProjectApplication app = new ProjectApplication(
                UUID.randomUUID().toString(),
                projectId,
                currentProfile.getUid(),
                currentProfile.getName(),
                message,
                resumeUrl,
                "pending"
        );

        DatabaseHelper.getInstance(getContext()).submitApplication(app);
        dialog.dismiss();
        checkApplicationStatus();
        Toast.makeText(getContext(), R.string.msg_application_submitted, Toast.LENGTH_SHORT).show();
    }

    private String getFileName(Uri uri) {
        if (uri == null) return null;
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (android.database.Cursor cursor = requireContext().getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index != -1) {
                        result = cursor.getString(index);
                    }
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1) {
                    result = result.substring(cut + 1);
                }
            }
        }
        return result;
    }

    private void runAlignmentAnalysis() {
        executor.submit(() -> {
            AlignmentResult result = SkillAnalysisEngine.getInstance()
                    .analyzeAlignment(currentProfile.getBio(), project.getFullText());
            
            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> showAlignmentResult(result));
            }
        });
    }

    private void showAlignmentResult(AlignmentResult result) {
        if (!isAdded()) return;
        
        getChildFragmentManager().beginTransaction()
                .replace(R.id.container_alignment, SkillAlignmentFragment.forStudent(result))
                .commit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
