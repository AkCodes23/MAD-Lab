package com.example.project.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.project.R;
import com.example.project.models.ScheduleItem;
import com.example.project.ScheduleManager;

public class EventDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        String name = getIntent().getStringExtra("event_name");
        String conductor = getIntent().getStringExtra("event_conductor");
        String dateTime = getIntent().getStringExtra("event_datetime");
        String location = getIntent().getStringExtra("event_location");
        String category = getIntent().getStringExtra("event_category");
        String description = getIntent().getStringExtra("event_description");

        TextView tvName = findViewById(R.id.tv_detail_event_name);
        TextView tvConductor = findViewById(R.id.tv_detail_conductor);
        TextView tvDateTime = findViewById(R.id.tv_detail_datetime);
        TextView tvLocation = findViewById(R.id.tv_detail_location);
        TextView tvCategory = findViewById(R.id.tv_detail_category);
        TextView tvDescription = findViewById(R.id.tv_detail_description);
        Button btnJoin = findViewById(R.id.btn_detail_join);

        tvName.setText(name);
        tvConductor.setText(conductor);
        tvDateTime.setText(dateTime);
        tvLocation.setText(location);
        tvCategory.setText(category);
        tvDescription.setText(description);

        btnJoin.setOnClickListener(v -> {
            ScheduleManager.getInstance(this).addItem(new ScheduleItem(name, dateTime, "Event"));
            Toast.makeText(this, "Joined & Added to Schedule: " + name, Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
