package com.example.project.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.adapters.ResearchAdapter;
import com.example.project.models.Project;
import com.example.project.ProjectManager;

import java.util.List;

public class ResearchFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_research, container, false);
        
        RecyclerView recyclerView = view.findViewById(R.id.research_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        
        // Use the centralized manager to get projects, including those uploaded by faculty
        List<Project> projects = ProjectManager.getInstance(requireContext()).getProjects();
        
        ResearchAdapter adapter = new ResearchAdapter(projects);
        recyclerView.setAdapter(adapter);
        
        return view;
    }
}
