package com.example.project.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.example.project.R;
import com.example.project.DatabaseHelper;
import com.example.project.SessionManager;
import com.example.project.models.UserProfile;

public class FacultyActivity extends AppCompatActivity {

    private String facultyName;
    private UserProfile facultyProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty);

        facultyName = getIntent().getStringExtra("FACULTY_NAME");
        ensureFacultyProfile();

        BottomNavigationView bottomNav = findViewById(R.id.faculty_bottom_navigation);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.faculty_fragment_container, FacultyDashboardFragment.newInstance(facultyName))
                    .commit();
            bottomNav.setSelectedItemId(R.id.navigation_dashboard);
        }

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int itemId = item.getItemId();

            if (itemId == R.id.navigation_upload) {
                selectedFragment = new FacultyUploadFragment();
            } else if (itemId == R.id.navigation_dashboard) {
                selectedFragment = FacultyDashboardFragment.newInstance(facultyName);
            } else if (itemId == R.id.navigation_faculty_schedule) {
                selectedFragment = FacultyScheduleFragment.newInstance(facultyName);
            }

            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.faculty_fragment_container, selectedFragment)
                        .commit();
                return true;
            }
            return false;
        });
    }

    public String getFacultyName() {
        return facultyName;
    }

    private void ensureFacultyProfile() {
        String uid = SessionManager.getInstance(this).getUid();
        if (uid != null) {
            DatabaseHelper db = DatabaseHelper.getInstance(this);
            facultyProfile = db.getUserProfile(uid);
            if (facultyProfile == null) {
                String email = facultyName != null ? facultyName.toLowerCase().replace(" ", ".") + "@university.edu" : "faculty@university.edu";
                facultyProfile = new UserProfile(uid, facultyName != null ? facultyName : "Dr. Faculty", email, "faculty");
                db.insertOrUpdateUser(facultyProfile);
            }
        }
    }
}
