package com.example.project.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.project.R;
import com.example.project.DatabaseHelper;
import com.example.project.SessionManager;
import com.example.project.models.UserProfile;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LoginActivity extends AppCompatActivity {

    private final Map<String, String> studentCredentials = new HashMap<>();
    private final Map<String, String> facultyCredentials = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Simple key-value store for credentials
        studentCredentials.put("student", "student123");
        
        // Specific Faculty Logins
        facultyCredentials.put("Dr. Smith", "smith123");
        facultyCredentials.put("Dr. Brown", "brown123");
        facultyCredentials.put("Dr. Wilson", "wilson123");
        facultyCredentials.put("faculty", "faculty123"); // Generic one

        EditText etUsername = findViewById(R.id.et_username);
        EditText etPassword = findViewById(R.id.et_password);
        Button btnStudent = findViewById(R.id.btn_student_login);
        Button btnFaculty = findViewById(R.id.btn_faculty_login);

        btnStudent.setOnClickListener(v -> {
            String user = etUsername.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();

            if (studentCredentials.containsKey(user) && studentCredentials.get(user).equals(pass)) {
                // Local Session Management instead of Firebase
                String uid = "student_" + user;
                DatabaseHelper db = DatabaseHelper.getInstance(this);
                if (db.getUserProfile(uid) == null) {
                    db.insertOrUpdateUser(new UserProfile(uid, user, user + "@example.com", "student"));
                }
                SessionManager.getInstance(this).createLoginSession(uid, "student");
                
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Invalid Student Credentials", Toast.LENGTH_SHORT).show();
            }
        });

        btnFaculty.setOnClickListener(v -> {
            String user = etUsername.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();

            if (facultyCredentials.containsKey(user) && facultyCredentials.get(user).equals(pass)) {
                // Local Session Management instead of Firebase
                String uid = "faculty_" + user.replace(" ", "_").toLowerCase();
                DatabaseHelper db = DatabaseHelper.getInstance(this);
                if (db.getUserProfile(uid) == null) {
                    db.insertOrUpdateUser(new UserProfile(uid, user, user.toLowerCase().replace(" ", ".") + "@university.edu", "faculty"));
                }
                SessionManager.getInstance(this).createLoginSession(uid, "faculty");

                Intent intent = new Intent(this, FacultyActivity.class);
                intent.putExtra("FACULTY_NAME", user); // Pass the specific professor's name
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Invalid Faculty Credentials", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
