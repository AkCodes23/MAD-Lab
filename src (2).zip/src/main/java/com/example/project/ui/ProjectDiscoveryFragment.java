package com.example.project.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.project.Config;
import com.example.project.R;
import com.example.project.ProjectManager;
import com.example.project.adapters.ProjectAdapter;
import com.example.project.models.Project;
import com.example.project.models.UserProfile;
import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.android.material.textfield.TextInputLayout;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import android.provider.MediaStore;
import android.app.Activity;
import android.content.Intent;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProjectDiscoveryFragment extends Fragment implements ProjectAdapter.OnProjectClickListener {

    private RecyclerView recyclerView;
    private ProjectAdapter adapter;
    private SwipeRefreshLayout swipeRefresh;
    private TextView emptyState;
    private UserProfile currentProfile;
    private EditText etSearch;
    private TextInputLayout layoutSearch;
    private ProgressBar progressSearch;
    private GenerativeModelFutures model;
    private ExecutorService executor = Executors.newSingleThreadExecutor();

    public static ProjectDiscoveryFragment newInstance(UserProfile profile) {
        ProjectDiscoveryFragment fragment = new ProjectDiscoveryFragment();
        fragment.currentProfile = profile;
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Ensure profile is available
        if (currentProfile == null && getContext() != null) {
            String uid = com.example.project.SessionManager.getInstance(getContext()).getUid();
            if (uid != null) {
                currentProfile = com.example.project.DatabaseHelper.getInstance(getContext()).getUserProfile(uid);
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_project_discovery, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.rv_projects);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        emptyState = view.findViewById(R.id.tv_empty_state);
        etSearch = view.findViewById(R.id.et_search_ai);
        layoutSearch = view.findViewById(R.id.layout_search);
        progressSearch = view.findViewById(R.id.progress_search);

        initAI();
        
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new ProjectAdapter(this);
        recyclerView.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(this::fetchProjects);
        
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performAISearch(etSearch.getText().toString().trim());
                return true;
            }
            return false;
        });

        layoutSearch.setEndIconOnClickListener(v -> startOCRScanner());

        fetchProjects();
    }

    private final ActivityResultLauncher<Intent> cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    processImageForOCR(result.getData());
                }
            }
    );

    private void startOCRScanner() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraLauncher.launch(takePictureIntent);
    }

    private void processImageForOCR(Intent data) {
        Bundle extras = data.getExtras();
        android.graphics.Bitmap imageBitmap = (android.graphics.Bitmap) extras.get("data");
        if (imageBitmap == null) return;

        InputImage image = InputImage.fromBitmap(imageBitmap, 0);
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    String resultText = visionText.getText();
                    if (!resultText.isEmpty()) {
                        etSearch.setText(resultText);
                        performAISearch(resultText);
                        Toast.makeText(getContext(), "Scanned text applied to search", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "No text detected in image", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(getContext(), "OCR Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void initAI() {
        GenerativeModel gm = new GenerativeModel(Config.MODEL_NAME, Config.GEMINI_API_KEY);
        model = GenerativeModelFutures.from(gm);
    }

    private void performAISearch(String query) {
        if (query.isEmpty()) {
            fetchProjects();
            return;
        }

        progressSearch.setVisibility(View.VISIBLE);
        recyclerView.setAlpha(0.5f);

        String prompt = "Act as a search query processor for a research project database. " +
                "Convert the following natural language request into a JSON object with 'keywords' (list of strings) and 'technologies' (list of strings).\n\n" +
                "Request: " + query + "\n\n" +
                "Example Output: {\"keywords\": [\"environment\", \"data analysis\"], \"technologies\": [\"Python\", \"R\"]}";

        com.example.project.AIFallbackManager.callWithFallback(model, prompt, new com.example.project.AIFallbackManager.AICallback() {
            @Override
            public void onSuccess(String result) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> handleSearchResult(result));
                }
            }

            @Override
            public void onFailure(Throwable t) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        progressSearch.setVisibility(View.GONE);
                        recyclerView.setAlpha(1.0f);
                        Toast.makeText(getContext(), "Search Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }

    private void handleSearchResult(String jsonOutput) {
        if (!isAdded() || getActivity() == null) return;
        
        progressSearch.setVisibility(View.GONE);
        recyclerView.setAlpha(1.0f);
        
        try {
            if (jsonOutput == null || !jsonOutput.contains("{")) {
                fetchProjects();
                return;
            }

            int start = jsonOutput.indexOf("{");
            int end = jsonOutput.lastIndexOf("}") + 1;
            if (start < 0 || end <= start) {
                fetchProjects();
                return;
            }

            JSONObject json = new JSONObject(jsonOutput.substring(start, end));
            JSONArray keywordsJson = json.optJSONArray("keywords");
            JSONArray techsJson = json.optJSONArray("technologies");
            
            List<String> keywords = new ArrayList<>();
            if (keywordsJson != null) {
                for (int i = 0; i < keywordsJson.length(); i++) keywords.add(keywordsJson.getString(i).toLowerCase());
            }
            if (techsJson != null) {
                for (int i = 0; i < techsJson.length(); i++) keywords.add(techsJson.getString(i).toLowerCase());
            }

            List<Project> allProjects = ProjectManager.getInstance(getContext()).getProjects();
            List<Project> filtered = new ArrayList<>();

            for (Project p : allProjects) {
                boolean match = false;
                String text = (p.getTitle() + " " + p.getDescription() + " " + p.getStack()).toLowerCase();
                
                for (String k : keywords) {
                    if (text.contains(k)) {
                        match = true;
                        break;
                    }
                }
                if (match) filtered.add(p);
            }

            adapter.updateData(filtered);
            emptyState.setVisibility(filtered.isEmpty() ? View.VISIBLE : View.GONE);
            emptyState.setText("No results for: " + etSearch.getText().toString());

        } catch (Exception e) {
            Log.e("Search", "JSON Error", e);
            fetchProjects();
        }
    }

    public void updateProfile(UserProfile profile) {
        this.currentProfile = profile;
        if (isAdded()) {
            fetchProjects();
        }
    }

    private void fetchProjects() {
        swipeRefresh.setRefreshing(true);
        List<Project> projects = ProjectManager.getInstance(getContext()).getProjects();
        
        // AI Recommendations Logic (Simulated for this MVP)
        if (currentProfile != null && currentProfile.getSkills() != null) {
            String userSkills = String.join(", ", currentProfile.getSkills()).toLowerCase();
            for (Project p : projects) {
                boolean match = false;
                if (p.getSkills() != null) {
                    for (String skill : p.getSkills()) {
                        if (userSkills.contains(skill.toLowerCase())) {
                            match = true;
                            break;
                        }
                    }
                }
                p.setRecommended(match);
            }
            
            // Sort to show recommended at the top
            projects.sort((p1, p2) -> Boolean.compare(p2.isRecommended(), p1.isRecommended()));
        }

        adapter.updateData(projects);
        emptyState.setVisibility(projects.isEmpty() ? View.VISIBLE : View.GONE);
        swipeRefresh.setRefreshing(false);
    }

    @Override
    public void onProjectClick(Project project) {
        // Navigate to ProjectDetailFragment
        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, ProjectDetailFragment.newInstance(project.getId(), currentProfile))
                .addToBackStack(null)
                .commit();
    }
}
