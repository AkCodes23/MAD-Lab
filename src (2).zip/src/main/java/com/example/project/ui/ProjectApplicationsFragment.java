package com.example.project.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.DatabaseHelper;
import com.example.project.adapters.FacultyManageAdapter;
import com.example.project.models.ProjectApplication;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProjectApplicationsFragment extends Fragment {

    private String projectId;
    private FacultyManageAdapter adapter;

    public static ProjectApplicationsFragment newInstance(String projectId) {
        ProjectApplicationsFragment fragment = new ProjectApplicationsFragment();
        Bundle args = new Bundle();
        args.putString("PROJECT_ID", projectId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            projectId = getArguments().getString("PROJECT_ID");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_faculty_dashboard, container, false);

        TextView tvWelcome = view.findViewById(R.id.tv_fac_welcome);
        if (tvWelcome != null) {
            tvWelcome.setText("Candidates");
        }

        RecyclerView recyclerView = view.findViewById(R.id.rv_faculty_manage);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        
        adapter = new FacultyManageAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        TextView emptyView = view.findViewById(R.id.tv_empty_view);
        emptyView.setText("No applications for this project yet.");

        fetchApplications(emptyView);

        return view;
    }

    private void fetchApplications(TextView emptyView) {
        if (projectId == null) return;
        List<ProjectApplication> apps = DatabaseHelper.getInstance(getContext()).getApplicationsForProjects(Collections.singletonList(projectId));
        
        // Sorting logic: Higher AI match score first (if applicable)
        // Note: Score is generated in onBindViewHolder of the adapter, 
        // but for a truly "Ranked" view, we'd pre-calculate or sort by status first.
        
        // Priority: Interview Scheduled > To Discuss > Applied > Rejected
        apps.sort((a1, a2) -> {
            int p1 = getStatusPriority(a1.status);
            int p2 = getStatusPriority(a2.status);
            return Integer.compare(p2, p1);
        });

        if (apps.isEmpty()) {
            emptyView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.GONE);
        }
        adapter.updateData(apps);
    }

    private int getStatusPriority(String status) {
        if (status == null) return 0;
        switch (status.toLowerCase()) {
            case "interview scheduled": return 5;
            case "accepted": return 4;
            case "to discuss": return 3;
            case "applied": return 2;
            case "reviewed": return 1;
            case "rejected": return -1;
            default: return 0;
        }
    }
}
