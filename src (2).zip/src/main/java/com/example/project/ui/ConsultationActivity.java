package com.example.project.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.project.R;
import com.example.project.models.ScheduleItem;
import com.example.project.ScheduleManager;

import com.example.project.DatabaseHelper;
import com.example.project.SessionManager;
import java.util.UUID;
import java.util.Locale;

public class ConsultationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultation);

        String profName = getIntent().getStringExtra("prof_name");
        String profId = getIntent().getStringExtra("prof_id"); // Need to pass this
        String profDept = "Computer Science & Engineering"; // Mock data
        String profContact = profName != null ? profName.toLowerCase(Locale.ROOT).replace("dr. ", "").replace(" ", ".") + "@university.edu" : "unknown@university.edu";

        TextView tvName = findViewById(R.id.tv_prof_name);
        TextView tvDept = findViewById(R.id.tv_prof_dept);
        TextView tvContact = findViewById(R.id.tv_prof_contact);
        RadioGroup rgSlots = findViewById(R.id.rg_time_slots);
        Button btnBook = findViewById(R.id.btn_book_consultation);

        tvName.setText(profName);
        tvDept.setText("Department: " + profDept);
        tvContact.setText("Contact: " + profContact);

        btnBook.setOnClickListener(v -> {
            int selectedId = rgSlots.getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton selectedButton = findViewById(selectedId);
                String time = selectedButton.getText().toString();
                
                String studentId = SessionManager.getInstance(this).getUid();
                String studentName = "Student"; // Would be better from profile

                // 1. Add to Global Schedule for legacy UI compatibility
                ScheduleManager.getInstance(this).addItem(new ScheduleItem("Meeting with " + profName, time, "Meeting", profName));
                
                // 2. Persistent storage in appointments table
                DatabaseHelper.getInstance(this).addAppointment(
                        UUID.randomUUID().toString(),
                        profId != null ? profId : "mock_prof_id",
                        studentId,
                        studentName,
                        "2023-10-27", // Mock date
                        time,
                        "Confirmed",
                        System.currentTimeMillis()
                );
                
                Toast.makeText(this, "Consultation booked & added to Schedule", Toast.LENGTH_LONG).show();
                finish();
            } else {
                Toast.makeText(this, "Please select a time slot", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
