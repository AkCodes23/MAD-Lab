package com.example.project;

import android.content.Context;
import com.example.project.models.ScheduleItem;
import java.util.ArrayList;
import java.util.List;

public class ScheduleManager {
    private static ScheduleManager instance;
    private DatabaseHelper dbHelper;

    private ScheduleManager(Context context) {
        dbHelper = DatabaseHelper.getInstance(context);
    }

    public static synchronized ScheduleManager getInstance(Context context) {
        if (instance == null) {
            instance = new ScheduleManager(context);
        }
        return instance;
    }

    public void addItem(ScheduleItem item) {
        dbHelper.addScheduleItem(item);
    }

    public List<ScheduleItem> getScheduledItems() {
        return dbHelper.getScheduleItems();
    }

    public boolean isAlreadyScheduled(String title, String type) {
        return dbHelper.isAlreadyScheduled(title, type);
    }
}
