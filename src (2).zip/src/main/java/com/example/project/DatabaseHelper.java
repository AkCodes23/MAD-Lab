package com.example.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.project.models.*;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "research_connect.db";
    private static final int DATABASE_VERSION = 2;

    // Table Names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_PROJECTS = "projects";
    private static final String TABLE_APPLICATIONS = "applications";
    private static final String TABLE_INTERESTS = "interests";
    private static final String TABLE_APPOINTMENTS = "appointments";
    private static final String TABLE_SCHEDULE = "schedule";
    private static final String TABLE_FACULTY_SLOTS = "faculty_slots";

    // Common column names
    private static final String KEY_ID = "id";

    // Faculty Slots Columns
    private static final String KEY_SLOT_PROF_ID = "professorId";
    private static final String KEY_SLOT_DATE = "date";
    private static final String KEY_SLOT_TIME = "time";
    private static final String KEY_SLOT_IS_AVAILABLE = "isAvailable";

    // Schedule Table Columns
    private static final String KEY_SCHED_TITLE = "title";
    private static final String KEY_SCHED_DATETIME = "dateTime";
    private static final String KEY_SCHED_TYPE = "type";
    private static final String KEY_SCHED_PROF = "professorName";

    // Users Table Columns
    private static final String KEY_USER_UID = "uid";
    private static final String KEY_USER_NAME = "name";
    private static final String KEY_USER_EMAIL = "email";
    private static final String KEY_USER_ROLE = "role";
    private static final String KEY_USER_BIO = "bio";
    private static final String KEY_USER_OFFICE_LOC = "officeLocation";
    private static final String KEY_USER_OFFICE_HOURS = "officeHours";

    // Projects Table Columns
    private static final String KEY_PROJ_TITLE = "title";
    private static final String KEY_PROJ_PROF = "professor";
    private static final String KEY_PROJ_PROF_ID = "professorId";
    private static final String KEY_PROJ_DESC = "description";
    private static final String KEY_PROJ_REQ = "requirements";
    private static final String KEY_PROJ_STATUS = "status";

    // Applications Table Columns
    private static final String KEY_APP_PROJ_ID = "projectId";
    private static final String KEY_APP_STUDENT_ID = "studentId";
    private static final String KEY_APP_STUDENT_NAME = "studentName";
    private static final String KEY_APP_MESSAGE = "message";
    private static final String KEY_APP_RESUME_URL = "resumeUrl";
    private static final String KEY_APP_STATUS = "status";
    private static final String KEY_APP_TIMESTAMP = "timestamp";

    // Interests Table Columns
    private static final String KEY_INT_PROJ_ID = "projectId";
    private static final String KEY_INT_PROJ_TITLE = "projectTitle";
    private static final String KEY_INT_STUDENT_ID = "studentId";
    private static final String KEY_INT_STUDENT_NAME = "studentName";
    private static final String KEY_INT_STUDENT_EMAIL = "studentEmail";

    // Appointments Table Columns
    private static final String KEY_APT_PROF_ID = "professorId";
    private static final String KEY_APT_STUDENT_ID = "studentId";
    private static final String KEY_APT_STUDENT_NAME = "studentName";
    private static final String KEY_APT_DATE = "date";
    private static final String KEY_APT_TIME = "time";
    private static final String KEY_APT_STATUS = "status";
    private static final String KEY_APT_TIMESTAMP = "timestamp";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + KEY_USER_UID + " TEXT PRIMARY KEY,"
                + KEY_USER_NAME + " TEXT,"
                + KEY_USER_EMAIL + " TEXT,"
                + KEY_USER_ROLE + " TEXT,"
                + KEY_USER_BIO + " TEXT,"
                + KEY_USER_OFFICE_LOC + " TEXT,"
                + KEY_USER_OFFICE_HOURS + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        // Create Projects Table
        String CREATE_PROJECTS_TABLE = "CREATE TABLE " + TABLE_PROJECTS + "("
                + KEY_ID + " TEXT PRIMARY KEY,"
                + KEY_PROJ_TITLE + " TEXT,"
                + KEY_PROJ_PROF + " TEXT,"
                + KEY_PROJ_PROF_ID + " TEXT,"
                + KEY_PROJ_DESC + " TEXT,"
                + KEY_PROJ_REQ + " TEXT,"
                + KEY_PROJ_STATUS + " TEXT" + ")";
        db.execSQL(CREATE_PROJECTS_TABLE);

        // Create Applications Table
        String CREATE_APPLICATIONS_TABLE = "CREATE TABLE " + TABLE_APPLICATIONS + "("
                + KEY_ID + " TEXT PRIMARY KEY,"
                + KEY_APP_PROJ_ID + " TEXT,"
                + KEY_APP_STUDENT_ID + " TEXT,"
                + KEY_APP_STUDENT_NAME + " TEXT,"
                + KEY_APP_MESSAGE + " TEXT,"
                + KEY_APP_RESUME_URL + " TEXT,"
                + KEY_APP_STATUS + " TEXT,"
                + KEY_APP_TIMESTAMP + " INTEGER" + ")";
        db.execSQL(CREATE_APPLICATIONS_TABLE);

        // Create Interests Table
        String CREATE_INTERESTS_TABLE = "CREATE TABLE " + TABLE_INTERESTS + "("
                + KEY_ID + " TEXT PRIMARY KEY,"
                + KEY_INT_PROJ_ID + " TEXT,"
                + KEY_INT_PROJ_TITLE + " TEXT,"
                + KEY_INT_STUDENT_ID + " TEXT,"
                + KEY_INT_STUDENT_NAME + " TEXT,"
                + KEY_INT_STUDENT_EMAIL + " TEXT" + ")";
        db.execSQL(CREATE_INTERESTS_TABLE);

        // Create Appointments Table
        String CREATE_APPOINTMENTS_TABLE = "CREATE TABLE " + TABLE_APPOINTMENTS + "("
                + KEY_ID + " TEXT PRIMARY KEY,"
                + KEY_APT_PROF_ID + " TEXT,"
                + KEY_APT_STUDENT_ID + " TEXT,"
                + KEY_APT_STUDENT_NAME + " TEXT,"
                + KEY_APT_DATE + " TEXT,"
                + KEY_APT_TIME + " TEXT,"
                + KEY_APT_STATUS + " TEXT,"
                + KEY_APT_TIMESTAMP + " INTEGER" + ")";
        db.execSQL(CREATE_APPOINTMENTS_TABLE);

        // Create Schedule Table
        String CREATE_SCHEDULE_TABLE = "CREATE TABLE " + TABLE_SCHEDULE + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_SCHED_TITLE + " TEXT,"
                + KEY_SCHED_DATETIME + " TEXT,"
                + KEY_SCHED_TYPE + " TEXT,"
                + KEY_SCHED_PROF + " TEXT" + ")";
        db.execSQL(CREATE_SCHEDULE_TABLE);

        // Create Faculty Slots Table
        String CREATE_SLOTS_TABLE = "CREATE TABLE " + TABLE_FACULTY_SLOTS + "("
                + KEY_ID + " TEXT PRIMARY KEY,"
                + KEY_SLOT_PROF_ID + " TEXT,"
                + KEY_SLOT_DATE + " TEXT,"
                + KEY_SLOT_TIME + " TEXT,"
                + KEY_SLOT_IS_AVAILABLE + " INTEGER DEFAULT 1" + ")";
        db.execSQL(CREATE_SLOTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROJECTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_APPLICATIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INTERESTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_APPOINTMENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEDULE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FACULTY_SLOTS);
        onCreate(db);
    }

    // --- Faculty Slots Operations ---
    public void addFacultySlot(String profId, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ID, java.util.UUID.randomUUID().toString());
        values.put(KEY_SLOT_PROF_ID, profId);
        values.put(KEY_SLOT_DATE, date);
        values.put(KEY_SLOT_TIME, time);
        values.put(KEY_SLOT_IS_AVAILABLE, 1);
        db.insert(TABLE_FACULTY_SLOTS, null, values);
    }

    public List<String> getAvailableSlots(String profId, String date) {
        List<String> slots = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_FACULTY_SLOTS, new String[]{KEY_SLOT_TIME},
                KEY_SLOT_PROF_ID + "=? AND " + KEY_SLOT_DATE + "=? AND " + KEY_SLOT_IS_AVAILABLE + "=1",
                new String[]{profId, date}, null, null, KEY_SLOT_TIME + " ASC");
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                slots.add(cursor.getString(0));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return slots;
    }

    public List<String> getAllAvailableSlots(String profId) {
        List<String> slots = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_FACULTY_SLOTS, new String[]{KEY_SLOT_DATE, KEY_SLOT_TIME},
                KEY_SLOT_PROF_ID + "=? AND " + KEY_SLOT_IS_AVAILABLE + "=1",
                new String[]{profId}, null, null, KEY_SLOT_DATE + " ASC, " + KEY_SLOT_TIME + " ASC");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                slots.add(cursor.getString(0) + " " + cursor.getString(1));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return slots;
    }

    public void bookSlot(String profId, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_SLOT_IS_AVAILABLE, 0);
        db.update(TABLE_FACULTY_SLOTS, values, 
                KEY_SLOT_PROF_ID + "=? AND " + KEY_SLOT_DATE + "=? AND " + KEY_SLOT_TIME + "=?",
                new String[]{profId, date, time});
    }

    // --- User Profile Operations ---
    public void insertOrUpdateUser(UserProfile profile) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_USER_UID, profile.getUid());
        values.put(KEY_USER_NAME, profile.getName());
        values.put(KEY_USER_EMAIL, profile.getEmail());
        values.put(KEY_USER_ROLE, profile.getRole());
        values.put(KEY_USER_BIO, profile.getBio());
        values.put(KEY_USER_OFFICE_LOC, profile.getOfficeLocation());
        values.put(KEY_USER_OFFICE_HOURS, profile.getOfficeHours());
        db.replace(TABLE_USERS, null, values);
    }

    public UserProfile getUserProfile(String uid) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, KEY_USER_UID + "=?", new String[]{uid}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            UserProfile profile = new UserProfile(
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_UID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_EMAIL)),
                    cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_ROLE))
            );
            profile.setBio(cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_BIO)));
            profile.setOfficeLocation(cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_OFFICE_LOC)));
            profile.setOfficeHours(cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_OFFICE_HOURS)));
            cursor.close();
            return profile;
        }
        return null;
    }

    public List<UserProfile> getFacultyUsers() {
        List<UserProfile> faculty = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, KEY_USER_ROLE + "=?", new String[]{"faculty"}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                UserProfile profile = new UserProfile(
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_UID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_EMAIL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_ROLE))
                );
                profile.setBio(cursor.getString(cursor.getColumnIndexOrThrow(KEY_USER_BIO)));
                faculty.add(profile);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return faculty;
    }

    // --- Project Operations ---
    public void addProject(Project project) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ID, project.getId());
        values.put(KEY_PROJ_TITLE, project.getTitle());
        values.put(KEY_PROJ_PROF, project.getProfessor());
        values.put(KEY_PROJ_PROF_ID, project.getProfessorId());
        values.put(KEY_PROJ_DESC, project.getDescription());
        values.put(KEY_PROJ_REQ, project.getRequirements());
        values.put(KEY_PROJ_STATUS, project.getStatus());
        db.replace(TABLE_PROJECTS, null, values);
    }

    public List<Project> getOpenProjects() {
        List<Project> projects = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PROJECTS, null, KEY_PROJ_STATUS + "=? OR " + KEY_PROJ_STATUS + "=?", new String[]{"open", "ongoing"}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                Project p = new Project();
                p.setId(cursor.getString(cursor.getColumnIndexOrThrow(KEY_ID)));
                p.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_TITLE)));
                p.setProfessor(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_PROF)));
                p.setProfessorId(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_PROF_ID)));
                p.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_DESC)));
                p.setRequirements(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_REQ)));
                p.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_STATUS)));
                projects.add(p);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return projects;
    }

    public List<Project> getProjectsByFaculty(String facultyId) {
        List<Project> projects = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PROJECTS, null, KEY_PROJ_PROF_ID + "=?", new String[]{facultyId}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                Project p = new Project();
                p.setId(cursor.getString(cursor.getColumnIndexOrThrow(KEY_ID)));
                p.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_TITLE)));
                p.setProfessor(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_PROF)));
                p.setProfessorId(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_PROF_ID)));
                p.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_DESC)));
                p.setRequirements(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_REQ)));
                p.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_STATUS)));
                projects.add(p);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return projects;
    }

    public Project getProjectById(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_PROJECTS, null, KEY_ID + "=?", new String[]{id}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            Project p = new Project();
            p.setId(cursor.getString(cursor.getColumnIndexOrThrow(KEY_ID)));
            p.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_TITLE)));
            p.setProfessor(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_PROF)));
            p.setProfessorId(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_PROF_ID)));
            p.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_DESC)));
            p.setRequirements(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_REQ)));
            p.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PROJ_STATUS)));
            cursor.close();
            return p;
        }
        return null;
    }

    // --- Application Operations ---
    public void submitApplication(ProjectApplication app) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ID, app.id != null ? app.id : java.util.UUID.randomUUID().toString());
        values.put(KEY_APP_PROJ_ID, app.projectId);
        values.put(KEY_APP_STUDENT_ID, app.studentId);
        values.put(KEY_APP_STUDENT_NAME, app.studentName);
        values.put(KEY_APP_MESSAGE, app.message);
        values.put(KEY_APP_RESUME_URL, app.resumeUrl);
        values.put(KEY_APP_STATUS, app.status);
        values.put(KEY_APP_TIMESTAMP, app.timestamp > 0 ? app.timestamp : System.currentTimeMillis());
        db.replace(TABLE_APPLICATIONS, null, values);
    }

    public boolean hasApplied(String projectId, String studentId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_APPLICATIONS, null, KEY_APP_PROJ_ID + "=? AND " + KEY_APP_STUDENT_ID + "=?",
                new String[]{projectId, studentId}, null, null, null);
        boolean exists = cursor != null && cursor.getCount() > 0;
        if (cursor != null) cursor.close();
        return exists;
    }

    public void updateApplicationStatus(String applicationId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_APP_STATUS, status);
        db.update(TABLE_APPLICATIONS, values, KEY_ID + "=?", new String[]{applicationId});
    }

    public void deleteApplication(String applicationId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_APPLICATIONS, KEY_ID + "=?", new String[]{applicationId});
    }

    public List<ProjectApplication> getStudentApplications(String studentId) {
        List<ProjectApplication> applications = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_APPLICATIONS, null, KEY_APP_STUDENT_ID + "=?", new String[]{studentId}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                ProjectApplication app = new ProjectApplication(
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_PROJ_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_STUDENT_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_STUDENT_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_MESSAGE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_RESUME_URL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_STATUS))
                );
                app.timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(KEY_APP_TIMESTAMP));
                applications.add(app);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return applications;
    }

    public List<ProjectApplication> getApplicationsForProjects(List<String> projectIds) {
        List<ProjectApplication> applications = new ArrayList<>();
        if (projectIds == null || projectIds.isEmpty()) return applications;
        
        SQLiteDatabase db = this.getReadableDatabase();
        StringBuilder selection = new StringBuilder(KEY_APP_PROJ_ID + " IN (");
        for (int i = 0; i < projectIds.size(); i++) {
            selection.append("?");
            if (i < projectIds.size() - 1) selection.append(",");
        }
        selection.append(")");
        
        Cursor cursor = db.query(TABLE_APPLICATIONS, null, selection.toString(), 
                projectIds.toArray(new String[0]), null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                ProjectApplication app = new ProjectApplication(
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_PROJ_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_STUDENT_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_STUDENT_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_MESSAGE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_RESUME_URL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_APP_STATUS))
                );
                app.timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(KEY_APP_TIMESTAMP));
                applications.add(app);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return applications;
    }

    // --- Interest Operations ---
    public void toggleInterest(ProjectInterest interest, boolean add) {
        SQLiteDatabase db = this.getWritableDatabase();
        if (add) {
            ContentValues values = new ContentValues();
            values.put(KEY_ID, interest.getId());
            values.put(KEY_INT_PROJ_ID, interest.getProjectId());
            values.put(KEY_INT_PROJ_TITLE, interest.getProjectTitle());
            values.put(KEY_INT_STUDENT_ID, interest.getStudentId());
            values.put(KEY_INT_STUDENT_NAME, interest.getStudentName());
            values.put(KEY_INT_STUDENT_EMAIL, interest.getStudentEmail());
            db.replace(TABLE_INTERESTS, null, values);
        } else {
            db.delete(TABLE_INTERESTS, KEY_INT_PROJ_ID + "=? AND " + KEY_INT_STUDENT_ID + "=?", 
                    new String[]{interest.getProjectId(), interest.getStudentId()});
        }
    }

    public boolean isInterested(String projectId, String studentId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INTERESTS, null, KEY_INT_PROJ_ID + "=? AND " + KEY_INT_STUDENT_ID + "=?",
                new String[]{projectId, studentId}, null, null, null);
        boolean exists = cursor != null && cursor.getCount() > 0;
        if (cursor != null) cursor.close();
        return exists;
    }

    public List<ProjectInterest> getInterestsForProject(String projectId) {
        List<ProjectInterest> interests = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INTERESTS, null, KEY_INT_PROJ_ID + "=?", new String[]{projectId}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                ProjectInterest interest = new ProjectInterest(
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_INT_PROJ_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_INT_PROJ_TITLE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_INT_STUDENT_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_INT_STUDENT_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_INT_STUDENT_EMAIL))
                );
                interests.add(interest);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return interests;
    }

    // --- Appointment Operations ---
    public void addAppointment(String id, String profId, String studentId, String studentName, String date, String time, String status, long timestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ID, id);
        values.put(KEY_APT_PROF_ID, profId);
        values.put(KEY_APT_STUDENT_ID, studentId);
        values.put(KEY_APT_STUDENT_NAME, studentName);
        values.put(KEY_APT_DATE, date);
        values.put(KEY_APT_TIME, time);
        values.put(KEY_APT_STATUS, status);
        values.put(KEY_APT_TIMESTAMP, timestamp);
        db.replace(TABLE_APPOINTMENTS, null, values);
    }

    public void updateAppointmentStatus(String id, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_APT_STATUS, status);
        db.update(TABLE_APPOINTMENTS, values, KEY_ID + "=?", new String[]{id});
    }

    public Cursor getAppointmentsCursor(String field, String userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String column = field.equals("professorId") ? KEY_APT_PROF_ID : KEY_APT_STUDENT_ID;
        return db.query(TABLE_APPOINTMENTS, null, column + "=?", new String[]{userId}, null, null, KEY_APT_TIMESTAMP + " DESC");
    }

    // --- Schedule Operations ---
    public void addScheduleItem(ScheduleItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_SCHED_TITLE, item.getTitle());
        values.put(KEY_SCHED_DATETIME, item.getDateTime());
        values.put(KEY_SCHED_TYPE, item.getType());
        values.put(KEY_SCHED_PROF, item.getProfessorName());
        db.insert(TABLE_SCHEDULE, null, values);
    }

    public List<ScheduleItem> getScheduleItems() {
        List<ScheduleItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SCHEDULE, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                ScheduleItem item = new ScheduleItem(
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_SCHED_TITLE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_SCHED_DATETIME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_SCHED_TYPE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(KEY_SCHED_PROF))
                );
                items.add(item);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return items;
    }

    public boolean isAlreadyScheduled(String title, String type) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SCHEDULE, null, KEY_SCHED_TITLE + "=? AND " + KEY_SCHED_TYPE + "=?",
                new String[]{title, type}, null, null, null);
        boolean exists = cursor != null && cursor.getCount() > 0;
        if (cursor != null) cursor.close();
        return exists;
    }
}
