package com.example.project;

import android.util.Log;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.ai.client.generativeai.GenerativeModel;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class AIFallbackManager {
    private static final String TAG = "AIFallbackManager";
    private static final Executor executor = Executors.newSingleThreadExecutor();

    public interface AICallback {
        void onSuccess(String result);
        void onFailure(Throwable t);
    }

    /**
     * Calls Gemini and automatically rotates through all available API keys on failure.
     */
    public static void callWithFallback(GenerativeModelFutures model, String prompt, AICallback callback) {
        if (callback == null) return;
        if (prompt == null || prompt.isEmpty()) {
            callback.onFailure(new Exception("Empty prompt"));
            return;
        }

        callGeminiWithRetries(prompt, callback, 0);
    }

    private static void callGeminiWithRetries(String prompt, AICallback callback, int retryCount) {
        if (retryCount >= Config.getKeyCount()) {
            callback.onFailure(new Exception("All Gemini API keys exhausted/failed."));
            return;
        }

        String currentKey = Config.GEMINI_API_KEY;
        Log.d(TAG, "Attempting Gemini call with key index: " + Config.getCurrentKeyIndex());

        // Create a new model instance for the specific key
        GenerativeModel gm = new GenerativeModel(Config.MODEL_NAME, currentKey);
        GenerativeModelFutures modelFutures = GenerativeModelFutures.from(gm);

        Content content = new Content.Builder().addText(prompt).build();
        ListenableFuture<GenerateContentResponse> response = modelFutures.generateContent(content);

        Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
            @Override
            public void onSuccess(GenerateContentResponse result) {
                callback.onSuccess(result.getText());
            }

            @Override
            public void onFailure(Throwable t) {
                Log.w(TAG, "Gemini API failed with key index " + Config.getCurrentKeyIndex() + ": " + t.getMessage());
                Config.rotateKey();
                // Recursive retry with the next key
                callGeminiWithRetries(prompt, callback, retryCount + 1);
            }
        }, executor);
    }
}
