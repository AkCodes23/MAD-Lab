package com.example.project.models;

public class SkillAlignment {
    public final String skill;
    public final String category;
    public final int studentWeight;
    public final int projectWeight;
    public final float matchScore;
    public final boolean isCritical;
    public final int gap;

    public SkillAlignment(String skill, String category, int studentWeight, int projectWeight, float matchScore, boolean isCritical) {
        this.skill = skill;
        this.category = category;
        this.studentWeight = studentWeight;
        this.projectWeight = projectWeight;
        this.matchScore = matchScore;
        this.isCritical = isCritical;
        this.gap = Math.max(0, projectWeight - studentWeight);
    }

    public int getMatchPercent() {
        return Math.round(matchScore * 100);
    }
}
