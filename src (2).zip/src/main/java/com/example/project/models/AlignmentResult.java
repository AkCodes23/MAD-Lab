package com.example.project.models;

import java.util.List;

public class AlignmentResult {
    public int overallScore;
    public List<CategoryScore> categoryScores;
    public List<SkillAlignment> skillBreakdown;
    public List<String> missingCriticalSkills;
    public List<String> strongSuits;
    public String dataQuality;
    public List<String> feedbackForStudent;
    public String summaryForProfessor;
    public AnomalyReport anomalyReport;

    public boolean isStrongFit() { return overallScore >= 75; }
    public boolean isPartialFit() { return overallScore >= 50 && overallScore < 75; }
    public boolean isWeakFit() { return overallScore < 50; }
}
