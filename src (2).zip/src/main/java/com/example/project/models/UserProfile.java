package com.example.project.models;

public class UserProfile {
    private String uid;
    private String name;
    private String email;
    private String role; // "student" or "faculty"
    private String bio;
    private String officeLocation;
    private String officeHours;
    private java.util.List<String> skills;

    public UserProfile() {}

    public java.util.List<String> getSkills() {
        if (skills == null) {
            skills = new java.util.ArrayList<>();
            // Simple logic to extract potential skills from bio if skills list is empty
            if (bio != null) {
                String[] commonSkills = {"Java", "Python", "C++", "ML", "AI", "Data Science", "React", "Node", "Android", "SQL"};
                for (String s : commonSkills) {
                    if (bio.toLowerCase().contains(s.toLowerCase())) skills.add(s);
                }
            }
        }
        return skills;
    }

    public void setSkills(java.util.List<String> skills) { this.skills = skills; }

    public UserProfile(String uid, String name, String email, String role) {
        this.uid = uid;
        this.name = name;
        this.email = email;
        this.role = role;
    }

    public String getUid() { return uid; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getRole() { return role; }
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public boolean isStudent() { return "student".equals(role); }
    public boolean isFaculty() { return "faculty".equals(role); }

    public boolean hasBio() {
        return bio != null && bio.trim().length() >= 20;
    }

    public String getOfficeLocation() { return officeLocation; }
    public void setOfficeLocation(String officeLocation) { this.officeLocation = officeLocation; }
    public String getOfficeHours() { return officeHours; }
    public void setOfficeHours(String officeHours) { this.officeHours = officeHours; }
}
