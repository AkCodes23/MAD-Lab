package com.example.project.models;

import java.util.Arrays;
import java.util.List;

public class Project {
    private String id;
    private String title;
    private String professor;
    private String professorId;
    private String description;
    private String requirements;
    private String status; // "open", "closed"
    private List<String> skills;
    private boolean isRecommended; // New: To identify AI-recommended projects

    public Project() {}

    public boolean isRecommended() { return isRecommended; }
    public void setRecommended(boolean recommended) { isRecommended = recommended; }

    public Project(String title, String professor, String status, String requirements) {
        this.id = java.util.UUID.randomUUID().toString();
        this.title = title;
        this.professor = professor;
        this.status = status;
        this.requirements = requirements;
        this.skills = java.util.Arrays.asList(requirements.split(",\\s*"));
    }

    public Project(String title, String professor, String description, String status, String[] skills) {
        this.id = java.util.UUID.randomUUID().toString();
        this.title = title;
        this.professor = professor;
        this.description = description;
        this.status = status;
        this.skills = java.util.Arrays.asList(skills);
    }

    public Project(String title, String professor, String professorId, String description, String requirements, String status, String... skills) {
        this.id = java.util.UUID.randomUUID().toString();
        this.title = title;
        this.professor = professor;
        this.professorId = professorId;
        this.description = description;
        this.requirements = requirements;
        this.status = status;
        this.skills = java.util.Arrays.asList(skills);
    }

    public Project(String id, String title, String professor, String professorId, String description, String requirements, String status, List<String> skills) {
        this.id = id;
        this.title = title;
        this.professor = professor;
        this.professorId = professorId;
        this.description = description;
        this.requirements = requirements;
        this.status = status;
        this.skills = skills;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getProfessor() { return professor; }
    public void setProfessor(String professor) { this.professor = professor; }
    public String getProfessorId() { return professorId; }
    public void setProfessorId(String professorId) { this.professorId = professorId; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getRequirements() { return requirements; }
    public void setRequirements(String requirements) { this.requirements = requirements; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public List<String> getSkills() { return skills; }
    public void setSkills(List<String> skills) { this.skills = skills; }

    public String getStack() {
        if (skills == null || skills.isEmpty()) return "";
        return String.join(", ", skills);
    }

    public String getFullText() {
        return (description != null ? description : "") + " " + (requirements != null ? requirements : "");
    }
}
