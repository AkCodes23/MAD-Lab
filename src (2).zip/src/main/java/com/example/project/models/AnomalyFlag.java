package com.example.project.models;

public class AnomalyFlag {
    public enum Code {
        ALL_SKILLS_MAX,
        SUSPICIOUSLY_HIGH_AVG,
        TOO_MANY_SKILLS,
        UNKNOWN_SKILLS,
        TARGETED_INFLATION,
        NO_SOURCE_DIVERSITY,
        IMPOSSIBLE_COMBINATION
    }

    public final Code code;
    public final String message;
    public final String detail;

    public AnomalyFlag(Code code, String message, String detail) {
        this.code = code;
        this.message = message;
        this.detail = detail;
    }

    public String getLabel() {
        return message;
    }
}
