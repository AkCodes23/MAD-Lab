package com.example.project.models;

public class ScheduleItem {
    private String title;
    private String dateTime;
    private String type; // "Event" or "Meeting"
    private String professorName;

    public ScheduleItem(String title, String dateTime, String type) {
        this.title = title;
        this.dateTime = dateTime;
        this.type = type;
    }

    public ScheduleItem(String title, String dateTime, String type, String professorName) {
        this.title = title;
        this.dateTime = dateTime;
        this.type = type;
        this.professorName = professorName;
    }

    public String getTitle() { return title; }
    public String getDateTime() { return dateTime; }
    public String getType() { return type; }
    public String getProfessorName() { return professorName; }
}