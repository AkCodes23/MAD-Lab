package com.example.project.models;

public class CategoryScore {
    public final String label;
    public final float studentScore;
    public final float projectScore;
    public final float coverage;

    public CategoryScore(String label, float studentScore, float projectScore, float coverage) {
        this.label = label;
        this.studentScore = studentScore;
        this.projectScore = projectScore;
        this.coverage = coverage;
    }
}
