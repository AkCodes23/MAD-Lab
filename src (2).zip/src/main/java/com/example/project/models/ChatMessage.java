package com.example.project.models;

public class ChatMessage {
    private String text;
    private boolean isUser;
    private android.graphics.Bitmap image;

    public ChatMessage(String text, boolean isUser) {
        this.text = text;
        this.isUser = isUser;
    }

    public ChatMessage(String text, boolean isUser, android.graphics.Bitmap image) {
        this.text = text;
        this.isUser = isUser;
        this.image = image;
    }

    public String getText() { return text; }
    public boolean isUser() { return isUser; }
    public android.graphics.Bitmap getImage() { return image; }
    public boolean hasImage() { return image != null; }
}