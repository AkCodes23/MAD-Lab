package com.example.project.models;

import java.util.ArrayList;
import java.util.List;

public class Event {
    private String name;
    private String date;
    private String time;
    private String location;
    private String category;
    private String professorName;
    private String description;

    public Event(String name, String date, String time, String location, String category, String professorName, String description) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.location = location;
        this.category = category;
        this.professorName = professorName;
        this.description = description;
    }

    public String getName() { return name; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getLocation() { return location; }
    public String getCategory() { return category; }
    public String getProfessorName() { return professorName; }
    public String getDescription() { return description; }

    public static List<Event> getMockEvents() {
        List<Event> events = new ArrayList<>();
        events.add(new Event("University Hackathon", "Oct 25, 2023", "10:00 AM", "Main Hall", "Competition", "Dr. Smith", 
                "Join us for a 24-hour coding challenge! Solve real-world problems, win exciting prizes, and network with industry leaders. Perfect for building your portfolio."));
        
        events.add(new Event("AI Guest Lecture", "Oct 30, 2023", "02:00 PM", "Auditorium A", "Lecture", "Dr. Wilson", 
                "Explore the future of Generative AI. Dr. Wilson will discuss the latest breakthroughs in LLMs and how they are transforming the tech landscape."));
        
        events.add(new Event("Career Fair 2023", "Nov 05, 2023", "09:00 AM", "Student Center", "Networking", "Dr. Brown", 
                "Connect with top recruiters from global tech giants. Bring your resume, practice your elevator pitch, and find your dream internship or job."));
        return events;
    }
}