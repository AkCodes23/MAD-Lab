package com.example.project.models;

import java.util.List;

public class AnomalyReport {
    public enum Severity {
        NONE, LOW, MEDIUM, HIGH
    }

    public final boolean isSuspicious;
    public final Severity severity;
    public final List<AnomalyFlag> flags;
    public final String summary;

    public AnomalyReport(boolean isSuspicious, Severity severity, List<AnomalyFlag> flags, String summary) {
        this.isSuspicious = isSuspicious;
        this.severity = severity;
        this.flags = flags;
        this.summary = summary;
    }

    public boolean isClean() {
        return severity == Severity.NONE;
    }
}
