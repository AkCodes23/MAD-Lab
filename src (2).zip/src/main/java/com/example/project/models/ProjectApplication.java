package com.example.project.models;

public class ProjectApplication {
    public String id;
    public String projectId;
    public String studentId;
    public String studentName;
    public String message;
    public String resumeUrl;
    public String status; // "pending", "accepted", "rejected"
    public long timestamp;

    public ProjectApplication() {}

    public ProjectApplication(String id, String projectId, String studentId, String studentName, String message, String resumeUrl, String status) {
        this.id = id;
        this.projectId = projectId;
        this.studentId = studentId;
        this.studentName = studentName;
        this.message = message;
        this.resumeUrl = resumeUrl;
        this.status = status;
        this.timestamp = System.currentTimeMillis();
    }
}
