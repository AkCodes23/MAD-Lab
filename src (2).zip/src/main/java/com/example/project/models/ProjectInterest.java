package com.example.project.models;

public class ProjectInterest {
    public String id;
    public String projectId;
    public String projectTitle;
    public String studentId;
    public String studentName;
    public String studentEmail;

    public ProjectInterest() {}

    public ProjectInterest(String id, String projectId, String projectTitle, String studentId, String studentName, String studentEmail) {
        this.id = id;
        this.projectId = projectId;
        this.projectTitle = projectTitle;
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
    }

    public String getId() { return id; }
    public String getProjectId() { return projectId; }
    public String getProjectTitle() { return projectTitle; }
    public String getStudentId() { return studentId; }
    public String getStudentName() { return studentName; }
    public String getStudentEmail() { return studentEmail; }
}
