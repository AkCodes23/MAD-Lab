package com.example.project.workers;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.project.ApplicationStatusManager;
import com.example.project.DatabaseHelper;
import com.example.project.R;
import com.example.project.models.Project;
import com.example.project.models.ProjectApplication;

import java.util.List;

public class StaleApplicationWorker extends Worker {

    private static final String CHANNEL_ID = "stale_applications";
    private static final int NOTIFICATION_ID = 1001;

    public StaleApplicationWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();
        String userId = getInputData().getString("userId");
        if (userId == null) return Result.failure();

        List<ProjectApplication> applications = ApplicationStatusManager.getInstance(context).getApplications(userId);
        int staleCount = 0;
        long sevenDaysAgo = System.currentTimeMillis() - (7 * 24 * 60 * 60 * 1000L);

        for (ProjectApplication app : applications) {
            if ("pending".equalsIgnoreCase(app.status) && app.timestamp < sevenDaysAgo) {
                staleCount++;
            }
        }

        if (staleCount > 0) {
            sendNotification(staleCount);
        }

        return Result.success();
    }

    private void sendNotification(int count) {
        Context context = getApplicationContext();
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Application Reminders", NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Research Application Update")
                .setContentText("You have " + count + " pending application(s) older than 7 days. Consider following up with the professors.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }
}
