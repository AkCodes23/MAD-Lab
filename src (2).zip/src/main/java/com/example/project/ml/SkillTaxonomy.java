package com.example.project.ml;

import com.example.project.models.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SkillTaxonomy {

    // ── Inner class: one skill entry ─────────────────────────────────────────
    public static class SkillEntry {
        public final String name;          // canonical display name
        public final String category;      // radar chart axis
        public final List<String> aliases; // lowercase strings to search for
        public final int defaultWeight;    // 1–10, used when no modifier is nearby

        public SkillEntry(String name, String category, int defaultWeight, String... aliases) {
            this.name          = name;
            this.category      = category;
            this.defaultWeight = defaultWeight;
            this.aliases       = Arrays.asList(aliases);
        }
    }

    // Singleton: built once at class load, never modified after that
    private static final List<SkillEntry> TAXONOMY = new ArrayList<>();

    // Proficiency context words — equivalent to PROFICIENCY_HIGH/MEDIUM/LOW in .ts
    public static final List<String> PROFICIENCY_HIGH = Arrays.asList(
            "expert", "advanced", "strong", "extensive", "deep", "excellent",
            "highly proficient", "senior", "specializ", "mastery", "master",
            "years of", "multiple years", "3+ years", "4+ years", "5+ years",
            "extensive experience", "in-depth", "lead", "primary", "core"
    );
    public static final List<String> PROFICIENCY_MEDIUM = Arrays.asList(
            "proficient", "good", "comfortable", "solid", "working knowledge",
            "experience with", "experienced in", "knowledge of", "skilled",
            "intermediate", "competent", "confident", "hands-on", "practical",
            "used", "worked with", "applied", "implemented", "developed"
    );
    public static final List<String> PROFICIENCY_LOW = Arrays.asList(
            "familiar", "basic", "beginner", "introductory", "learning",
            "exposure", "understanding of", "some experience", "elementary",
            "awareness", "novice", "entry-level", "started", "exploring",
            "limited", "brief"
    );
    public static final List<String> REQUIREMENT_CRITICAL = Arrays.asList(
            "required", "must have", "mandatory", "essential", "necessary",
            "must know", "must be proficient", "strong background in",
            "expertise in", "strong", "solid understanding of"
    );
    public static final List<String> REQUIREMENT_PREFERRED = Arrays.asList(
            "preferred", "nice to have", "bonus", "optional", "plus",
            "advantage", "desirable", "beneficial", "ideally", "familiarity with",
            "exposure to", "basic understanding"
    );
    public static final List<String> NEGATION_WORDS = Arrays.asList(
            "no ", "not ", "without ", "lack ", "limited ", "don't ", "cannot "
    );

    // Skill-specific improvement recommendations (mirrors SKILL_RECOMMENDATIONS in .ts)
    public static final Map<String, String> RECOMMENDATIONS;

    static {
        // ── Programming Languages ────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("Python",           "Programming", 5,
                "python", "python3", "python 3", "py"));
        TAXONOMY.add(new SkillEntry("JavaScript",       "Programming", 5,
                "javascript", "js", "node.js", "nodejs", "node js", "es6", "ecmascript"));
        TAXONOMY.add(new SkillEntry("TypeScript",       "Programming", 5,
                "typescript", "ts"));
        TAXONOMY.add(new SkillEntry("Java",             "Programming", 5,
                "java", "java se", "java ee"));
        TAXONOMY.add(new SkillEntry("C++",              "Programming", 5,
                "c++", "cpp", "c plus plus"));
        TAXONOMY.add(new SkillEntry("R",                "Programming", 5,
                " r ", "r language", "r programming", "rlang", "tidyverse", "ggplot"));
        TAXONOMY.add(new SkillEntry("MATLAB",           "Programming", 5,
                "matlab", "mat-lab", "simulink"));
        TAXONOMY.add(new SkillEntry("Scala",            "Programming", 5,
                "scala", "akka", "spark scala"));
        TAXONOMY.add(new SkillEntry("Go",               "Programming", 5,
                "golang", " go "));
        TAXONOMY.add(new SkillEntry("Rust",             "Programming", 5,
                "rust", "rust-lang", "rustlang"));
        TAXONOMY.add(new SkillEntry("SQL",              "Programming", 5,
                "sql", "mysql", "postgresql", "postgres", "sqlite", "tsql", "t-sql",
                "plsql", "pl/sql", "database queries", "relational databases"));
        TAXONOMY.add(new SkillEntry("Bash / Shell",     "Programming", 4,
                "bash", "shell scripting", "shell script", "command line", "cli",
                "unix", "linux scripting", "zsh"));

        // ── ML Frameworks ────────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("TensorFlow",       "ML Frameworks", 6,
                "tensorflow", " tf ", "tf2", "tensorflow 2", "keras"));
        TAXONOMY.add(new SkillEntry("PyTorch",          "ML Frameworks", 6,
                "pytorch", "torch", "py-torch"));
        TAXONOMY.add(new SkillEntry("Scikit-learn",     "ML Frameworks", 5,
                "scikit", "sklearn", "scikit-learn", "scikit learn"));
        TAXONOMY.add(new SkillEntry("Hugging Face",     "ML Frameworks", 6,
                "huggingface", "hugging face", "transformers library", "hf transformers"));
        TAXONOMY.add(new SkillEntry("XGBoost / LightGBM","ML Frameworks", 5,
                "xgboost", "xgb", "lightgbm", "lgbm", "gradient boosting", "catboost"));
        TAXONOMY.add(new SkillEntry("JAX",              "ML Frameworks", 7,
                "jax", "flax", "optax"));
        TAXONOMY.add(new SkillEntry("spaCy / NLTK",    "ML Frameworks", 5,
                "spacy", "nltk", "gensim", "textblob"));
        TAXONOMY.add(new SkillEntry("OpenCV",           "ML Frameworks", 5,
                "opencv", "open cv", "cv2"));

        // ── Data Science ─────────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("NumPy / Pandas",   "Data Science", 5,
                "numpy", " np ", "pandas", " pd ", "dataframe", "data frames"));
        TAXONOMY.add(new SkillEntry("Data Visualization","Data Science", 4,
                "matplotlib", "pyplot", "seaborn", "plotly", "bokeh",
                "data visualization", "data viz", "visualization", "tableau",
                "d3.js", "charts"));
        TAXONOMY.add(new SkillEntry("Data Analysis",    "Data Science", 5,
                "data analysis", "data analytics", "exploratory data analysis",
                "eda", "data wrangling", "data cleaning", "feature engineering",
                "data preprocessing"));
        TAXONOMY.add(new SkillEntry("Statistics",       "Data Science", 6,
                "statistics", "statistical analysis", "statistical modeling",
                "probability", "stochastic", "bayesian", "hypothesis testing",
                "regression analysis", "statistical inference"));
        TAXONOMY.add(new SkillEntry("Big Data",         "Data Science", 6,
                "big data", "apache spark", "spark", "hadoop", "pyspark",
                "kafka", "data pipelines", "etl", "data engineering"));

        // ── ML Concepts ──────────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("Machine Learning", "ML Concepts", 6,
                "machine learning", " ml ", "supervised learning", "unsupervised learning",
                "semi-supervised", "classification", "regression", "clustering",
                "random forest", "svm", "support vector machine"));
        TAXONOMY.add(new SkillEntry("Deep Learning",    "ML Concepts", 7,
                "deep learning", " dl ", "neural network", "neural networks",
                "cnn", "convolutional neural", "rnn", "lstm", "gru",
                "attention mechanism", "backpropagation"));
        TAXONOMY.add(new SkillEntry("Natural Language Processing", "ML Concepts", 7,
                "nlp", "natural language processing", "text mining", "text analysis",
                "sentiment analysis", "text classification", "named entity recognition",
                "ner", "information extraction", "question answering",
                "summarization", "language model"));
        TAXONOMY.add(new SkillEntry("Computer Vision", "ML Concepts", 7,
                "computer vision", " cv ", "image recognition", "image classification",
                "image processing", "object detection", "segmentation",
                "image segmentation", "yolo", "resnet"));
        TAXONOMY.add(new SkillEntry("Reinforcement Learning", "ML Concepts", 8,
                "reinforcement learning", " rl ", "q-learning", "dqn",
                "policy gradient", "openai gym", "gymnasium"));
        TAXONOMY.add(new SkillEntry("Large Language Models", "ML Concepts", 7,
                "llm", "llms", "large language model", "gpt", "bert",
                "transformer", "transformers", "generative ai", "rag",
                "retrieval augmented", "fine-tuning", "fine tuning",
                "prompt engineering"));
        TAXONOMY.add(new SkillEntry("MLOps",            "ML Concepts", 7,
                "mlops", "ml ops", "model deployment", "model serving",
                "model monitoring", "mlflow", "weights & biases", "wandb",
                "experiment tracking", "model registry"));

        // ── Mathematics ──────────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("Linear Algebra",   "Mathematics", 7,
                "linear algebra", "matrix", "matrices", "eigenvector",
                "eigenvalue", "svd", "singular value decomposition", "vector space"));
        TAXONOMY.add(new SkillEntry("Calculus",         "Mathematics", 6,
                "calculus", "differential calculus", "integral calculus",
                "differentiation", "partial derivatives", "gradient",
                "multivariable calculus"));
        TAXONOMY.add(new SkillEntry("Optimization",     "Mathematics", 7,
                "optimization", "gradient descent", "sgd", "adam optimizer",
                "convex optimization", "mathematical optimization", "loss function"));
        TAXONOMY.add(new SkillEntry("Discrete Mathematics", "Mathematics", 5,
                "discrete math", "discrete mathematics", "graph theory",
                "combinatorics", "algorithms", "data structures"));

        // ── Web Dev ──────────────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("React / Frontend", "Web Dev", 4,
                "react", "reactjs", "react.js", "vue", "angular",
                "frontend", "front-end", "html", "css"));
        TAXONOMY.add(new SkillEntry("REST API / Backend","Web Dev", 5,
                "rest", "restful", "rest api", "fastapi", "flask", "django",
                "express", "backend", "back-end", "api development", "web api"));
        TAXONOMY.add(new SkillEntry("Firebase",         "Web Dev", 4,
                "firebase", "firestore", "realtime database"));

        // ── Blockchain ────────────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("Blockchain",       "Blockchain", 7,
                "blockchain", "smart contract", "ethereum", "solidity", "web3",
                "dapps", "bitcoin", "cryptography"));

        // ── Cybersec ──────────────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("Cybersecurity",    "Cybersec", 7,
                "cybersecurity", "cyber security", "penetration testing", "pentesting",
                "ethical hacking", "network security", "infosec", "information security"));

        // ── Android ──────────────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("Android Dev",      "Android", 6,
                "android", "kotlin", "java android", "jetpack compose", "mobile development"));

        // ── AI/ML ────────────────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("Machine Learning", "AI/ML", 6,
                "machine learning", " ml ", "supervised learning", "unsupervised learning"));
        TAXONOMY.add(new SkillEntry("Deep Learning",    "AI/ML", 7,
                "deep learning", " dl ", "neural network", "cnn", "rnn"));
        TAXONOMY.add(new SkillEntry("Natural Language Processing", "AI/ML", 7,
                "nlp", "natural language processing"));

        // ── Embedded Systems ──────────────────────────────────────────────────
        TAXONOMY.add(new SkillEntry("Embedded C",       "Embedded Systems", 6,
                "embedded c", "microcontroller", "stm32", "avr", "arduino", "rtos", "free-rtos"));
        TAXONOMY.add(new SkillEntry("IoT",               "Embedded Systems", 6,
                "iot", "internet of things", "raspberry pi", "esp32", "mqtt", "sensors"));
        TAXONOMY.add(new SkillEntry("Verilog / VHDL",   "Embedded Systems", 7,
                "verilog", "vhdl", "fpga", "hdl", "digital design", "asic"));

        // ── Recommendations map ───────────────────────────────────────────────
        Map<String, String> recs = new HashMap<>();
        recs.put("Python",
                "Build a data pipeline or automation script using Pandas and NumPy to demonstrate applied proficiency.");
        recs.put("Machine Learning",
                "Complete an end-to-end ML project (e.g., a Kaggle competition) to demonstrate practical model-building skills.");
        recs.put("Deep Learning",
                "Implement a neural network from scratch with PyTorch, or reproduce a published paper's architecture.");
        recs.put("Natural Language Processing",
                "Build a text classifier or summarization tool using Hugging Face Transformers.");
        recs.put("Computer Vision",
                "Create an image classification or object detection project using OpenCV and a pre-trained ResNet model.");
        recs.put("TensorFlow",
                "Complete the official TensorFlow Developer Certificate program or build a project using TF's Keras API.");
        recs.put("PyTorch",
                "Work through the PyTorch tutorials on pytorch.org and build a custom training loop from scratch.");
        recs.put("Docker",
                "Containerize an existing personal project and push it to Docker Hub.");
        recs.put("Kubernetes",
                "Follow the Kubernetes interactive tutorial and deploy a multi-container app on Minikube.");
        recs.put("Statistics",
                "Strengthen statistical modeling through a Bayesian inference or regression analysis project.");
        recs.put("Linear Algebra",
                "Review matrix decomposition methods (SVD, PCA) through a hands-on NumPy tutorial or MIT OpenCourseWare.");
        recs.put("Large Language Models",
                "Experiment with LLM fine-tuning using Hugging Face PEFT/LoRA or build a RAG pipeline.");
        recs.put("MLOps",
                "Set up experiment tracking with MLflow or Weights & Biases for one of your existing projects.");
        recs.put("Research",
                "Conduct a structured literature review on a topic related to this project and write a 2-page summary.");
        RECOMMENDATIONS = Collections.unmodifiableMap(recs);
    }

    // ── Public accessors ─────────────────────────────────────────────────────

    public static List<SkillEntry> getAll() {
        return Collections.unmodifiableList(TAXONOMY);
    }

    public static String getRecommendation(String skillName) {
        return RECOMMENDATIONS.getOrDefault(skillName,
                "Explore courses or hands-on projects focused on " + skillName + " to strengthen this area.");
    }
}
