package com.example.project.ml;

import com.example.project.models.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedHashMap;

public class SkillAnalysisEngine {

    // ── Singleton ─────────────────────────────────────────────────────────────
    private static SkillAnalysisEngine instance;
    public static SkillAnalysisEngine getInstance() {
        if (instance == null) instance = new SkillAnalysisEngine();
        return instance;
    }
    private SkillAnalysisEngine() {}

    // ═════════════════════════════════════════════════════════════════════════
    // PUBLIC ENTRY POINT 1: Bio text path (no LLM)
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Main entry point for the bio-text analysis path.
     * Called from ProjectDetailFragment when the student opens a project page.
     *
     * @param studentBio   Raw text from the student's profile bio field
     * @param projectText  project.description + " " + project.requirements
     * @return             Complete AlignmentResult (anomalyReport is null here)
     */
    public AlignmentResult analyzeAlignment(String studentBio, String projectText) {
        Map<String, Integer> studentVector = extractSkillVector(studentBio);
        ExtractionResult projectResult     = extractProjectVector(projectText);

        return buildResult(studentVector, projectResult, null);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // PUBLIC ENTRY POINT 2: Resume / LLM path
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Entry point for the Cloud LLM resume pipeline.
     * Called after ResumeValidator has validated and converted the LLM output.
     *
     * @param studentSkillVector  Output of ResumeValidator.convertToSkillVector()
     * @param projectText         project.description + " " + project.requirements
     * @param anomalyReport       Output of ResumeValidator.detectAnomalies()
     * @return                    AlignmentResult with anomalyReport attached
     */
    public AlignmentResult analyzeFromResume(Map<String, Integer> studentSkillVector,
                                             String projectText,
                                             AnomalyReport anomalyReport) {
        ExtractionResult projectResult = extractProjectVector(projectText);
        return buildResult(studentSkillVector, projectResult, anomalyReport);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // PUBLIC ENTRY POINT 3: Get project skill names (for anomaly detection)
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Returns the canonical names of skills detected in a project's text.
     * Used by ResumeValidator.detectAnomalies() to check for targeted inflation.
     */
    public List<String> extractProjectSkillNames(String projectText) {
        ExtractionResult result = extractProjectVector(projectText);
        return new ArrayList<>(result.vector.keySet());
    }

    // ═════════════════════════════════════════════════════════════════════════
    // PHASE 1: SKILL EXTRACTION
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Extracts a SkillVector from free-form text (a student's bio).
     * Returns a map: canonical skill name → weight (1–10).
     *
     * Algorithm:
     *   1. Normalise text to lowercase
     *   2. For each taxonomy entry, search for each alias
     *   3. For each match, scan a ±60-char window for proficiency signals
     *   4. Skip negated matches ("no experience with Python")
     *   5. If a skill matches via multiple aliases, keep the highest weight
     */
    public Map<String, Integer> extractSkillVector(String text) {
        if (text == null || text.trim().isEmpty()) return new HashMap<>();

        String normalized = text.toLowerCase();
        Map<String, Integer> vector = new HashMap<>();

        for (SkillTaxonomy.SkillEntry entry : SkillTaxonomy.getAll()) {
            int bestWeight = -1;

            for (String alias : entry.aliases) {
                int idx = normalized.indexOf(alias);
                if (idx == -1) continue;
                if (isNegated(normalized, idx)) continue;

                Integer contextWeight = detectProficiencyContext(normalized, idx);
                int weight = (contextWeight != null) ? contextWeight : entry.defaultWeight;

                if (weight > bestWeight) bestWeight = weight;
            }

            if (bestWeight != -1) {
                vector.put(entry.name, bestWeight);
            }
        }
        return vector;
    }

    // Container for the project vector extraction result
    public static class ExtractionResult {
        public final Map<String, Integer> vector;
        public final Set<String> criticalSkills; // skills marked "required"
        ExtractionResult(Map<String, Integer> vector, Set<String> criticalSkills) {
            this.vector        = vector;
            this.criticalSkills = criticalSkills;
        }
    }

    /**
     * Extracts a SkillVector from project text (description + requirements).
     * Also tracks which skills are marked as "required" vs "preferred".
     */
    public ExtractionResult extractProjectVector(String text) {
        if (text == null || text.trim().isEmpty()) {
            return new ExtractionResult(new HashMap<>(), new HashSet<>());
        }

        String normalized = text.toLowerCase();
        Map<String, Integer> vector = new HashMap<>();
        Set<String> criticalSkills  = new HashSet<>();

        for (SkillTaxonomy.SkillEntry entry : SkillTaxonomy.getAll()) {
            int bestWeight = -1;
            boolean foundCritical = false;

            for (String alias : entry.aliases) {
                int idx = normalized.indexOf(alias);
                if (idx == -1) continue;
                if (isNegated(normalized, idx)) continue;

                boolean critical = detectCriticalityContext(normalized, idx);
                if (critical) foundCritical = true;

                Integer contextWeight = detectProficiencyContext(normalized, idx);
                // Critical skills without explicit weight default to 8
                int weight = (contextWeight != null) ? contextWeight : (critical ? 8 : entry.defaultWeight);

                if (weight > bestWeight) bestWeight = weight;
            }

            if (bestWeight != -1) {
                vector.put(entry.name, bestWeight);
                if (foundCritical) criticalSkills.add(entry.name);
            }
        }
        return new ExtractionResult(vector, criticalSkills);
    }

    // ── Proficiency context detection ─────────────────────────────────────────

    /**
     * Scans a ±60-character window around a match index.
     * Returns 9 (high), 6 (medium), 3 (low), or null (use default).
     */
    private Integer detectProficiencyContext(String text, int matchIndex) {
        int start = Math.max(0, matchIndex - 60);
        int end   = Math.min(text.length(), matchIndex + 60);
        String window = text.substring(start, end);

        for (String phrase : SkillTaxonomy.PROFICIENCY_HIGH)   { if (window.contains(phrase)) return 9; }
        for (String phrase : SkillTaxonomy.PROFICIENCY_MEDIUM) { if (window.contains(phrase)) return 6; }
        for (String phrase : SkillTaxonomy.PROFICIENCY_LOW)    { if (window.contains(phrase)) return 3; }
        return null;
    }

    /**
     * Detects whether a skill is "required" (critical) vs "preferred" in project text.
     * Scans an 80-character window around the match.
     */
    private boolean detectCriticalityContext(String text, int matchIndex) {
        int start = Math.max(0, matchIndex - 80);
        int end   = Math.min(text.length(), matchIndex + 80);
        String window = text.substring(start, end);

        // Preferred signals override critical — check preferred first
        for (String phrase : SkillTaxonomy.REQUIREMENT_PREFERRED) { if (window.contains(phrase)) return false; }
        for (String phrase : SkillTaxonomy.REQUIREMENT_CRITICAL)  { if (window.contains(phrase)) return true;  }
        return false; // default: treat as preferred
    }

    /**
     * Returns true if the skill appears to be negated.
     * e.g. "no experience with Python", "not familiar with Docker".
     */
    private boolean isNegated(String text, int matchIndex) {
        int start = Math.max(0, matchIndex - 30);
        String snippet = text.substring(start, matchIndex);
        for (String neg : SkillTaxonomy.NEGATION_WORDS) {
            if (snippet.contains(neg)) return true;
        }
        return false;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // PHASE 2: WEIGHTED OVERLAP SCORING
    // ═════════════════════════════════════════════════════════════════════════

    private static class ScoringResult {
        float rawScore;
        List<SkillAlignment> breakdown;
        List<String> missingCritical;
        ScoringResult(float rawScore, List<SkillAlignment> breakdown, List<String> missingCritical) {
            this.rawScore        = rawScore;
            this.breakdown       = breakdown;
            this.missingCritical = missingCritical;
        }
    }

    /**
     * Cosine-inspired Weighted Overlap Score.
     * Identical algorithm to computeWeightedOverlap() in skillAnalysis.ts.
     *
     * For each project-required skill:
     *   - If student has it:     score += min(student, project) / project
     *   - If student lacks it:   apply penalty (larger for critical skills)
     */
    private ScoringResult computeWeightedOverlap(Map<String, Integer> studentVector,
                                                 Map<String, Integer> projectVector,
                                                 Set<String> criticalSkills) {
        List<SkillAlignment> breakdown   = new ArrayList<>();
        List<String> missingCritical     = new ArrayList<>();

        // Union of all skills mentioned by either party
        Set<String> allSkills = new HashSet<>();
        allSkills.addAll(studentVector.keySet());
        allSkills.addAll(projectVector.keySet());

        float weightedScoreSum = 0f;
        float weightSum        = 0f;
        float penaltySum       = 0f;

        for (String skill : allSkills) {
            int studentW = studentVector.containsKey(skill) ? studentVector.get(skill) : 0;
            int projectW = projectVector.containsKey(skill) ? projectVector.get(skill) : 0;
            String category  = getCategoryFor(skill);
            boolean critical = criticalSkills.contains(skill);

            if (projectW == 0) {
                // Student has an extra skill the project doesn't need — small bonus
                breakdown.add(new SkillAlignment(skill, category, studentW, 0, 1.0f, false));
                continue;
            }

            if (studentW == 0) {
                // Student is missing a required skill — penalty applied
                float penaltyWeight = critical ? projectW * 1.5f : projectW;
                penaltySum += penaltyWeight;
                weightSum  += projectW;
                if (critical) missingCritical.add(skill);
                breakdown.add(new SkillAlignment(skill, category, 0, projectW, 0f, critical));
                continue;
            }

            // Both have the skill: compute match ratio
            float matchScore   = Math.min(studentW, projectW) / (float) projectW;
            float contribution = matchScore * projectW;
            weightedScoreSum  += contribution;
            weightSum         += projectW;
            breakdown.add(new SkillAlignment(skill, category, studentW, projectW, matchScore, critical));
        }

        if (weightSum == 0f) return new ScoringResult(0f, breakdown, missingCritical);

        float baseScore    = weightedScoreSum / weightSum;
        float penaltyRatio = Math.min(penaltySum / (weightSum * 2f), 0.6f);
        float rawScore     = baseScore * (1f - penaltyRatio);

        return new ScoringResult(rawScore, breakdown, missingCritical);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // PHASE 3: CATEGORY AGGREGATION (for radar chart)
    // ═════════════════════════════════════════════════════════════════════════

    private List<CategoryScore> buildCategoryScores(List<SkillAlignment> breakdown) {
        // Group by category
        Map<String, List<SkillAlignment>> byCategory = new LinkedHashMap<>();
        for (SkillAlignment s : breakdown) {
            if (!byCategory.containsKey(s.category)) byCategory.put(s.category, new ArrayList<>());
            byCategory.get(s.category).add(s);
        }

        List<CategoryScore> result = new ArrayList<>();
        for (Map.Entry<String, List<SkillAlignment>> entry : byCategory.entrySet()) {
            List<SkillAlignment> items = entry.getValue();
            float avgStudent  = average(items, true);
            float avgProject  = average(items, false);
            float avgCoverage = 0f;
            for (SkillAlignment s : items) avgCoverage += s.matchScore;
            avgCoverage /= items.size();
            result.add(new CategoryScore(entry.getKey(), avgStudent, avgProject, avgCoverage));
        }

        return result;
    }

    private float average(List<SkillAlignment> items, boolean useStudent) {
        if (items.isEmpty()) return 0f;
        float sum = 0f;
        for (SkillAlignment s : items) sum += useStudent ? s.studentWeight : s.projectWeight;
        return sum / items.size();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // PHASE 4: FEEDBACK GENERATION
    // ═════════════════════════════════════════════════════════════════════════

    private List<String> generateStudentFeedback(List<SkillAlignment> breakdown, int overallScore) {
        List<String> messages = new ArrayList<>();

        // Strengths first
        List<SkillAlignment> strengths = new ArrayList<>();
        for (SkillAlignment s : breakdown) {
            if (s.matchScore >= 0.8f && s.projectWeight > 0) strengths.add(s);
        }
        Collections.sort(strengths, (a, b) -> Float.compare(b.matchScore, a.matchScore));
        if (strengths.size() > 3) strengths = strengths.subList(0, 3);

        if (!strengths.isEmpty()) {
            StringBuilder sb = new StringBuilder("Your strongest areas of alignment are: ");
            for (int i = 0; i < strengths.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(strengths.get(i).skill);
            }
            sb.append(". These are well-matched to what this project needs.");
            messages.add(sb.toString());
        }

        // Gap messages
        List<SkillAlignment> gaps = new ArrayList<>();
        for (SkillAlignment s : breakdown) {
            if (s.gap > 2 || (s.projectWeight > 0 && s.studentWeight == 0)) gaps.add(s);
        }
        Collections.sort(gaps, (a, b) -> Integer.compare(b.projectWeight, a.projectWeight));
        if (gaps.size() > 4) gaps = gaps.subList(0, 4);

        for (SkillAlignment gap : gaps) {
            String levelDesc = (gap.studentWeight == 0)
                    ? "no detected background"
                    : "a proficiency of " + gap.studentWeight + "/10";

            String urgency = gap.isCritical ? "Critical Gap" : "Growth Area";
            String rec     = SkillTaxonomy.getRecommendation(gap.skill);

            messages.add(urgency + " — " + gap.skill + ": You have " + levelDesc
                    + ", but this project requires " + gap.projectWeight + "/10. " + rec);
        }

        // Closing line
        if (overallScore >= 70) {
            messages.add("Overall, you're a strong candidate. Focus on the gaps above to make your application stand out.");
        } else if (overallScore >= 45) {
            messages.add("You have a solid foundation but closing the skill gaps above would significantly improve your fit.");
        } else {
            messages.add("There are meaningful gaps to address, but with focused preparation you can become competitive for projects like this.");
        }

        return messages;
    }

    private String generateProfessorSummary(List<SkillAlignment> breakdown,
                                            List<CategoryScore> categoryScores,
                                            int overallScore,
                                            List<String> missingCritical) {
        String verdict;
        if (overallScore >= 80)      verdict = "an excellent match for this project";
        else if (overallScore >= 65) verdict = "a strong candidate worth reviewing";
        else if (overallScore >= 45) verdict = "a partial match with notable gaps";
        else                         verdict = "currently underprepared for this project's requirements";

        List<CategoryScore> sorted = new ArrayList<>(categoryScores);
        Collections.sort(sorted, (a, b) -> Float.compare(b.coverage, a.coverage));

        List<String> strong = new ArrayList<>();
        List<String> weak   = new ArrayList<>();
        for (CategoryScore c : sorted) {
            if (c.coverage >= 0.75f) strong.add(c.label);
            if (c.coverage  < 0.40f) weak.add(c.label);
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Overall Fit: ").append(overallScore).append("/100 — This candidate is ").append(verdict).append(". ");

        if (!strong.isEmpty()) {
            int pct = Math.round(sorted.get(0).coverage * 100);
            sb.append("High alignment in ").append(join(strong)).append(" (~").append(pct).append("% covered). ");
        }
        if (!weak.isEmpty()) {
            sb.append("Limited experience in ").append(join(weak)).append(". ");
        }
        if (!missingCritical.isEmpty()) {
            sb.append("Missing critical skills: ").append(join(missingCritical)).append(".");
        }
        return sb.toString().trim();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // INTERNAL: Build the final AlignmentResult
    // ═════════════════════════════════════════════════════════════════════════

    private AlignmentResult buildResult(Map<String, Integer> studentVector,
                                        ExtractionResult projectResult,
                                        AnomalyReport anomalyReport) {
        ScoringResult scoring = computeWeightedOverlap(
                studentVector, projectResult.vector, projectResult.criticalSkills);

        int overallScore = Math.min(100, Math.round(scoring.rawScore * 100));

        List<CategoryScore> categoryScores = buildCategoryScores(scoring.breakdown);

        // Strong suits: project-relevant skills where student scores >= 85%
        List<String> strongSuits = new ArrayList<>();
        for (SkillAlignment s : scoring.breakdown) {
            if (s.matchScore >= 0.85f && s.projectWeight > 0) strongSuits.add(s.skill);
        }

        // Only project-relevant skills go in the final breakdown list
        List<SkillAlignment> filteredBreakdown = new ArrayList<>();
        for (SkillAlignment s : scoring.breakdown) {
            if (s.projectWeight > 0) filteredBreakdown.add(s);
        }

        // Sort by project importance (most critical skills first)
        Collections.sort(filteredBreakdown,
                (a, b) -> Integer.compare(b.projectWeight, a.projectWeight));

        List<String> feedbackForStudent   = generateStudentFeedback(filteredBreakdown, overallScore);
        String summaryForProfessor        = generateProfessorSummary(
                filteredBreakdown, categoryScores, overallScore, scoring.missingCritical);

        String dataQuality = assessDataQuality(studentVector, projectResult.vector, anomalyReport != null);

        AlignmentResult result = new AlignmentResult();
        result.overallScore        = overallScore;
        result.categoryScores      = categoryScores;
        result.skillBreakdown      = filteredBreakdown;
        result.missingCriticalSkills = scoring.missingCritical;
        result.strongSuits         = strongSuits;
        result.dataQuality         = dataQuality;
        result.feedbackForStudent  = feedbackForStudent;
        result.summaryForProfessor = summaryForProfessor;
        result.anomalyReport       = anomalyReport; // null for bio-text path
        return result;
    }

    private String assessDataQuality(Map<String, Integer> sv,
                                     Map<String, Integer> pv,
                                     boolean fromResume) {
        // Resume-parsed data is always at least 'good' quality if it passed validation
        if (fromResume && sv.size() >= 4) return "good";
        if (sv.size() >= 4 && pv.size() >= 3) return "good";
        if (sv.size() >= 2 || pv.size() >= 2) return "partial";
        return "poor";
    }

    private String getCategoryFor(String skillName) {
        for (SkillTaxonomy.SkillEntry e : SkillTaxonomy.getAll()) {
            if (e.name.equals(skillName)) return e.category;
        }
        return "Other";
    }

    private String join(List<String> list) {
        if (list.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(i == list.size() - 1 ? " & " : ", ");
            sb.append(list.get(i));
        }
        return sb.toString();
    }
}
