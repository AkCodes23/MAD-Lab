package com.example.project.ml;

import com.example.project.models.AnomalyFlag;
import com.example.project.models.AnomalyReport;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class ResumeValidator {

    // ── Custom exception for schema validation failures ───────────────────────
    public static class ValidationException extends Exception {
        public final Object rawInput; // preserved for debug logging
        public ValidationException(String message, Object rawInput) {
            super(message);
            this.rawInput = rawInput;
        }
    }

    // ── Inner class: one validated skill from the LLM output ─────────────────
    public static class LLMSkillEntry {
        public final String name;
        public final int level;    // 1–10
        public final String source; // "Work Experience", "Skills Section", etc.

        LLMSkillEntry(String name, int level, String source) {
            this.name   = name;
            this.level  = level;
            this.source = source;
        }
    }

    // ── Validated payload — output of Job 1, input to Jobs 2 and 3 ──────────
    public static class ParsedResumeData {
        public final List<LLMSkillEntry> skills;
        ParsedResumeData(List<LLMSkillEntry> skills) {
            this.skills = skills;
        }
    }

    // HTML/script injection pattern — checked against every string field
    private static final Pattern DANGEROUS_PATTERN =
            Pattern.compile("<\\s*script|<\\s*img|<\\s*iframe|javascript:", Pattern.CASE_INSENSITIVE);

    // ─────────────────────────────────────────────────────────────────────────
    // JOB 1: SCHEMA VALIDATION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Validates the raw string from the Cloud LLM API.
     * Throws ValidationException (not RuntimeException) on any failure so the
     * caller can catch it and show a friendly error — never a crash.
     *
     * Checks (in order):
     *   1. Strip markdown fences
     *   2. Valid JSON
     *   3. Is a plain object (not array / null / primitive)
     *   4. Has a "skills" array
     *   5. Skill count within 2–35 (plausible human range)
     *   6. Each skill has correct field types
     *   7. level is an integer in 1–10
     *   8. No HTML/script tags in any string field (XSS + injection guard)
     */
    public ParsedResumeData validateLLMSchema(String rawLLMOutput) throws ValidationException {

        // ── Step 1: Strip markdown code fences ────────────────────────────────
        // Many LLMs wrap JSON in ```json ... ``` even when told not to.
        String cleaned = rawLLMOutput
                .replaceAll("(?i)^```(?:json)?\\s*", "")
                .replaceAll("\\s*```$", "")
                .trim();

        // ── Step 2: Parse JSON ─────────────────────────────────────────────────
        JSONObject obj;
        try {
            obj = new JSONObject(cleaned);
        } catch (JSONException e) {
            throw new ValidationException(
                    "The resume parser returned invalid JSON. " +
                            "This may indicate a parsing failure or an injection attempt.",
                    rawLLMOutput
            );
        }

        // ── Step 3: Must have a "skills" array ────────────────────────────────
        JSONArray rawSkills;
        try {
            rawSkills = obj.getJSONArray("skills");
        } catch (JSONException e) {
            throw new ValidationException(
                    "The resume parser output is missing the required \"skills\" array. " +
                            "Check that the LLM prompt specifies the correct output schema.",
                    obj
            );
        }

        // ── Step 4: Plausible skill count ──────────────────────────────────────
        final int MIN_SKILLS = 2;
        final int MAX_SKILLS = 35;

        if (rawSkills.length() < MIN_SKILLS) {
            throw new ValidationException(
                    "The resume parser found only " + rawSkills.length() + " skill(s). " +
                            "The resume may be too sparse or the parser may have failed.",
                    rawSkills
            );
        }
        if (rawSkills.length() > MAX_SKILLS) {
            throw new ValidationException(
                    "The resume parser returned " + rawSkills.length() + " skills, " +
                            "exceeding the maximum of " + MAX_SKILLS + ". " +
                            "This may indicate hallucination or an injection attempt.",
                    rawSkills
            );
        }

        // ── Step 5: Validate each individual skill entry ──────────────────────
        List<LLMSkillEntry> validatedSkills = new ArrayList<>();

        for (int i = 0; i < rawSkills.length(); i++) {
            JSONObject skill;
            try {
                skill = rawSkills.getJSONObject(i);
            } catch (JSONException e) {
                throw new ValidationException("Skill at index " + i + " is not a valid object.", rawSkills);
            }

            // 'name' must be a non-empty string
            String name;
            try {
                name = skill.getString("name").trim();
                if (name.isEmpty()) throw new ValidationException(
                        "Skill at index " + i + " has an empty name.", skill);
            } catch (JSONException e) {
                throw new ValidationException(
                        "Skill at index " + i + " is missing the \"name\" field.", skill);
            }

            // 'level' must be an integer in 1–10
            int level;
            try {
                level = skill.getInt("level");
            } catch (JSONException e) {
                throw new ValidationException(
                        "Skill \"" + name + "\" has a non-integer level.", skill);
            }
            if (level < 1 || level > 10) {
                throw new ValidationException(
                        "Skill \"" + name + "\" has level " + level + " which is outside the valid range 1–10.", skill);
            }

            // 'source' must be a string (can be empty)
            String source;
            try {
                source = skill.getString("source").trim();
            } catch (JSONException e) {
                throw new ValidationException(
                        "Skill \"" + name + "\" is missing the \"source\" field.", skill);
            }

            // ── XSS / injection guard ──────────────────────────────────────
            // A real LLM parsing a real resume should never produce HTML tags.
            // If any field contains them, something has gone badly wrong.
            String combined = name + " " + source;
            if (DANGEROUS_PATTERN.matcher(combined).find()) {
                throw new ValidationException(
                        "Skill \"" + name + "\" contains potentially dangerous content. " +
                                "The resume may contain an injection payload.",
                        skill
                );
            }

            validatedSkills.add(new LLMSkillEntry(name, level, source));
        }

        return new ParsedResumeData(validatedSkills);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // JOB 2: ANOMALY DETECTION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Runs 7 statistical anomaly checks on validated skill data.
     * NEVER throws — always returns an AnomalyReport.
     * The pipeline continues regardless; the report is attached to AlignmentResult
     * and surfaced as a warning to the professor (students never see it).
     *
     * @param data           Validated ParsedResumeData from validateLLMSchema()
     * @param projectSkills  Canonical skill names required by the project
     *                       (pass null to skip targeted inflation check)
     */
    public AnomalyReport detectAnomalies(ParsedResumeData data, List<String> projectSkills) {
        List<AnomalyFlag> flags = new ArrayList<>();
        List<LLMSkillEntry> skills = data.skills;

        // Collect levels for math operations
        int[] levels = new int[skills.size()];
        for (int i = 0; i < skills.size(); i++) levels[i] = skills.get(i).level;

        // ── Check 1: All skills at maximum level ──────────────────────────────
        // Real expertise is uneven. If >85% of skills are 9–10, data is suspect.
        int highCount = 0;
        for (int l : levels) if (l >= 9) highCount++;
        float highRatio = (float) highCount / levels.length;
        if (highRatio > 0.85f) {
            flags.add(new AnomalyFlag(
                    AnomalyFlag.Code.ALL_SKILLS_MAX,
                    Math.round(highRatio * 100) + "% of listed skills are at level 9–10, " +
                            "which is statistically unusual for a real resume.",
                    highCount + " of " + levels.length + " skills rated 9 or 10"
            ));
        }

        // ── Check 2: Suspiciously high average ────────────────────────────────
        float avgLevel = 0f;
        for (int l : levels) avgLevel += l;
        avgLevel /= levels.length;
        if (avgLevel > 8.0f) {
            flags.add(new AnomalyFlag(
                    AnomalyFlag.Code.SUSPICIOUSLY_HIGH_AVG,
                    String.format("Average skill level is %.1f/10, significantly above typical student profiles.", avgLevel),
                    String.format("Average: %.1f, expected range for students: 4.5–7.0", avgLevel)
            ));
        }

        // ── Check 3: Too many skills ──────────────────────────────────────────
        // Schema validator rejects >35, but 20–35 is still a yellow flag.
        if (skills.size() > 20) {
            flags.add(new AnomalyFlag(
                    AnomalyFlag.Code.TOO_MANY_SKILLS,
                    skills.size() + " skills were extracted, which is higher than typical (5–18).",
                    skills.size() + " skills detected"
            ));
        }

        // ── Check 4: Unknown skills (not in our taxonomy) ────────────────────
        // Collect all known aliases for quick lookup
        List<String> allAliases = new ArrayList<>();
        for (SkillTaxonomy.SkillEntry e : SkillTaxonomy.getAll()) {
            for (String alias : e.aliases) allAliases.add(alias.toLowerCase().trim());
        }

        List<String> unknownNames = new ArrayList<>();
        for (LLMSkillEntry s : skills) {
            String nameLower = s.name.toLowerCase();
            boolean recognized = false;
            for (String alias : allAliases) {
                if (alias.contains(nameLower) || nameLower.contains(alias)) {
                    recognized = true;
                    break;
                }
            }
            if (!recognized) unknownNames.add(s.name);
        }

        float unknownRatio = (float) unknownNames.size() / skills.size();
        if (unknownRatio > 0.4f && unknownNames.size() >= 3) {
            String sample = join(unknownNames.subList(0, Math.min(5, unknownNames.size())));
            flags.add(new AnomalyFlag(
                    AnomalyFlag.Code.UNKNOWN_SKILLS,
                    unknownNames.size() + " skills are not recognized in the taxonomy. " +
                            "This may indicate LLM hallucination.",
                    "Unrecognized: " + sample + (unknownNames.size() > 5 ? "..." : "")
            ));
        }

        // ── Check 5: Targeted inflation (requires project context) ────────────
        // If project-relevant skills are specifically inflated vs other skills,
        // the resume may have been crafted to game this exact project.
        if (projectSkills != null && !projectSkills.isEmpty()) {
            List<Integer> projectRelatedLevels = new ArrayList<>();
            List<Integer> otherLevels          = new ArrayList<>();

            for (LLMSkillEntry s : skills) {
                boolean relatedToProject = false;
                for (String ps : projectSkills) {
                    if (ps.toLowerCase().contains(s.name.toLowerCase()) ||
                            s.name.toLowerCase().contains(ps.toLowerCase())) {
                        relatedToProject = true;
                        break;
                    }
                }
                if (relatedToProject) projectRelatedLevels.add(s.level);
                else                  otherLevels.add(s.level);
            }

            if (projectRelatedLevels.size() >= 2 && otherLevels.size() >= 2) {
                float avgProject = average(projectRelatedLevels);
                float avgOther   = average(otherLevels);

                if (avgProject - avgOther > 2.0f && avgProject > 7.5f) {
                    flags.add(new AnomalyFlag(
                            AnomalyFlag.Code.TARGETED_INFLATION,
                            String.format("Project-relevant skills average %.1f/10, which is %.1f points higher " +
                                            "than other skills. This asymmetry may indicate targeted resume inflation.",
                                    avgProject, avgProject - avgOther),
                            String.format("Project-relevant avg: %.1f, other skills avg: %.1f",
                                    avgProject, avgOther)
                    ));
                }
            }
        }

        // ── Check 6: No source diversity ──────────────────────────────────────
        // A real resume mentions skills from multiple sections.
        Map<String, Integer> sourceCounts = new HashMap<>();
        for (LLMSkillEntry s : skills) {
            String src = s.source.trim().toLowerCase();
            if (src.isEmpty()) src = "unknown";
            sourceCounts.put(src, sourceCounts.getOrDefault(src, 0) + 1);
        }

        int maxCount = 0;
        String dominantSource = "unknown";
        for (Map.Entry<String, Integer> e : sourceCounts.entrySet()) {
            if (e.getValue() > maxCount) { maxCount = e.getValue(); dominantSource = e.getKey(); }
        }

        float dominantRatio = (float) maxCount / skills.size();
        if (dominantRatio > 0.9f && skills.size() >= 5) {
            flags.add(new AnomalyFlag(
                    AnomalyFlag.Code.NO_SOURCE_DIVERSITY,
                    Math.round(dominantRatio * 100) + "% of skills are from the same section (\"" +
                            dominantSource + "\"), which is atypical for a well-rounded resume.",
                    maxCount + " of " + skills.size() + " skills from: \"" + dominantSource + "\""
            ));
        }

        // ── Check 7: Impossible skill combinations ────────────────────────────
        // Certain expert-level combinations are extremely rare for a student.
        String[][] implausiblePairs = {
                {"Kubernetes",             "React / Frontend"},
                {"Reinforcement Learning", "Rust"},
                {"Large Language Models",  "C++"}
        };

        List<String> expertNames = new ArrayList<>();
        for (LLMSkillEntry s : skills) if (s.level >= 9) expertNames.add(s.name.toLowerCase());

        for (String[] pair : implausiblePairs) {
            boolean hasA = false, hasB = false;
            for (String n : expertNames) {
                if (n.contains(pair[0].toLowerCase()) || pair[0].toLowerCase().contains(n)) hasA = true;
                if (n.contains(pair[1].toLowerCase()) || pair[1].toLowerCase().contains(n)) hasB = true;
            }
            if (hasA && hasB) {
                flags.add(new AnomalyFlag(
                        AnomalyFlag.Code.IMPOSSIBLE_COMBINATION,
                        "Expert-level proficiency (9–10) in both \"" + pair[0] + "\" and \"" +
                                pair[1] + "\" simultaneously is extremely rare and warrants verification.",
                        "Both \"" + pair[0] + "\" and \"" + pair[1] + "\" rated 9 or 10"
                ));
            }
        }

        // ── Compute overall severity ──────────────────────────────────────────
        boolean hasHigh = false, hasMedium = false;
        for (AnomalyFlag f : flags) {
            if (f.code == AnomalyFlag.Code.ALL_SKILLS_MAX      ||
                    f.code == AnomalyFlag.Code.TARGETED_INFLATION   ||
                    f.code == AnomalyFlag.Code.IMPOSSIBLE_COMBINATION) { hasHigh = true; }
            if (f.code == AnomalyFlag.Code.SUSPICIOUSLY_HIGH_AVG ||
                    f.code == AnomalyFlag.Code.UNKNOWN_SKILLS)          { hasMedium = true; }
        }

        AnomalyReport.Severity severity;
        if (hasHigh)         severity = AnomalyReport.Severity.HIGH;
        else if (hasMedium)  severity = AnomalyReport.Severity.MEDIUM;
        else if (!flags.isEmpty()) severity = AnomalyReport.Severity.LOW;
        else                 severity = AnomalyReport.Severity.NONE;

        boolean isSuspicious = (severity == AnomalyReport.Severity.MEDIUM ||
                severity == AnomalyReport.Severity.HIGH);

        String summary;
        if (flags.isEmpty()) {
            summary = "No statistical anomalies detected in this resume profile.";
        } else if (severity == AnomalyReport.Severity.LOW) {
            summary = flags.size() + " minor anomaly detected. The profile appears generally legitimate.";
        } else if (severity == AnomalyReport.Severity.MEDIUM) {
            summary = flags.size() + " anomaly flag(s) — medium severity. " +
                    "Manual verification of stated skill levels is recommended.";
        } else {
            summary = flags.size() + " high-severity flag(s) detected. " +
                    "This profile shows strong indicators of inflation or prompt injection. " +
                    "Treat stated skill levels with caution.";
        }

        return new AnomalyReport(isSuspicious, severity, flags, summary);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // JOB 3: CONVERT TO SKILL VECTOR
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Converts validated LLM skill entries into a SkillVector
     * (Map<String, Integer>) that SkillAnalysisEngine.analyzeFromResume() accepts.
     *
     * Applies source credibility adjustments:
     *   "Work Experience" / "Internship" → no adjustment (most credible)
     *   "Projects"                       → -1 (slightly less than direct experience)
     *   "Skills Section"                 → -1 (self-reported, weakest signal)
     *   "Education" / "Coursework"       → -1 (exposure, not applied skill)
     *
     * If the same skill appears in multiple sections, the highest adjusted
     * level wins — we credit the best evidence we have.
     */
    public Map<String, Integer> convertToSkillVector(ParsedResumeData data) {
        Map<String, Integer> vector = new HashMap<>();

        for (LLMSkillEntry skill : data.skills) {
            String srcLower = skill.source.toLowerCase();

            // Determine the credibility adjustment for this source
            int adjustment = 0;
            if (srcLower.contains("skills") || srcLower.contains("skills section")) {
                adjustment = -1; // skills sections are self-reported
            } else if (srcLower.contains("education") || srcLower.contains("coursework")) {
                adjustment = -1; // educational exposure is weaker than applied work
            } else if (srcLower.contains("project")) {
                adjustment = 0;  // project experience is credible (no penalty)
            }
            // work experience and internship: 0 adjustment (default)

            // Clamp to valid range 1–10
            int adjustedLevel = Math.max(1, Math.min(10, skill.level + adjustment));

            // Keep the highest level if the skill appears in multiple sections
            Integer existing = vector.get(skill.name);
            if (existing == null || adjustedLevel > existing) {
                vector.put(skill.name, adjustedLevel);
            }
        }

        return vector;
    }

    // ── Utility ───────────────────────────────────────────────────────────────

    private float average(List<Integer> list) {
        if (list.isEmpty()) return 0f;
        int sum = 0;
        for (int v : list) sum += v;
        return (float) sum / list.size();
    }

    private String join(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(list.get(i));
        }
        return sb.toString();
    }
}
