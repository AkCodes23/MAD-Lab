package com.example.project;

import android.content.Context;
import com.example.project.models.ProjectApplication;
import java.util.ArrayList;
import java.util.List;

public class ApplicationStatusManager {
    private static ApplicationStatusManager instance;
    private DatabaseHelper dbHelper;

    private ApplicationStatusManager(Context context) {
        dbHelper = DatabaseHelper.getInstance(context);
    }

    public static synchronized ApplicationStatusManager getInstance(Context context) {
        if (instance == null) {
            instance = new ApplicationStatusManager(context);
        }
        return instance;
    }

    public void addApplication(ProjectApplication app) {
        dbHelper.submitApplication(app);
    }

    private boolean isResumeAnalyzed = false;

    public boolean isResumeAnalyzed() {
        return isResumeAnalyzed;
    }

    public void setResumeAnalyzed(boolean resumeAnalyzed) {
        isResumeAnalyzed = resumeAnalyzed;
    }

    public List<ProjectApplication> getApplications(String studentId) {
        return dbHelper.getStudentApplications(studentId);
    }

    public boolean isAlreadyApplied(String projectId, String studentId) {
        return dbHelper.hasApplied(projectId, studentId);
    }
}
