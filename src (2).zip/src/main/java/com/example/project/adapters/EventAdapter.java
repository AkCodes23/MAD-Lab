package com.example.project.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.ui.EventDetailActivity;
import com.example.project.models.Event;
import com.example.project.models.ScheduleItem;
import com.example.project.ScheduleManager;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    private List<Event> events;

    public EventAdapter(List<Event> events) {
        this.events = events;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Event event = events.get(position);
        holder.name.setText(event.getName());
        holder.date.setText(event.getDate());
        holder.timeLocation.setText(event.getTime() + " | " + event.getLocation());
        holder.category.setText(event.getCategory());
        
        holder.joinButton.setOnClickListener(v -> {
            ScheduleManager sm = ScheduleManager.getInstance(v.getContext());
            if (sm.isAlreadyScheduled(event.getName(), "Event")) {
                new AlertDialog.Builder(v.getContext())
                        .setTitle("Already Registered")
                        .setMessage("You have already joined this event.")
                        .setPositiveButton("OK", null)
                        .show();
            } else {
                sm.addItem(new ScheduleItem(event.getName(), event.getDate() + " - " + event.getTime(), "Event"));
                Toast.makeText(v.getContext(), "Joined & Added to Schedule: " + event.getName(), Toast.LENGTH_SHORT).show();
            }
        });

        holder.viewButton.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), EventDetailActivity.class);
            intent.putExtra("event_name", event.getName());
            intent.putExtra("event_conductor", event.getProfessorName());
            intent.putExtra("event_datetime", event.getDate() + " at " + event.getTime());
            intent.putExtra("event_location", event.getLocation());
            intent.putExtra("event_category", event.getCategory());
            intent.putExtra("event_description", event.getDescription());
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, date, timeLocation, category;
        Button joinButton, viewButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.event_name);
            date = itemView.findViewById(R.id.event_date);
            timeLocation = itemView.findViewById(R.id.event_time_location);
            category = itemView.findViewById(R.id.event_category);
            joinButton = itemView.findViewById(R.id.btn_join_event);
            viewButton = itemView.findViewById(R.id.btn_view_event);
        }
    }
}
