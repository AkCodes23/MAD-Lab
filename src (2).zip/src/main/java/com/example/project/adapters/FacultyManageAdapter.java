package com.example.project.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.Config;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.mlkit.nl.smartreply.SmartReply;
import com.google.mlkit.nl.smartreply.SmartReplyGenerator;
import com.google.mlkit.nl.smartreply.TextMessage;
import com.example.project.DatabaseHelper;
import com.example.project.R;
import com.example.project.ui.FacultyActivity;
import com.example.project.ui.MainActivity;
import com.example.project.ui.SkillAlignmentFragment;
import com.example.project.ml.ResumeParserService;
import com.example.project.ml.SkillAnalysisEngine;
import com.example.project.models.AlignmentResult;
import com.example.project.models.Project;
import com.example.project.models.ProjectApplication;
import com.example.project.models.UserProfile;
import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONObject;

import android.net.Uri;
import android.widget.Button;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class FacultyManageAdapter extends RecyclerView.Adapter<FacultyManageAdapter.ViewHolder> {

    private List<ProjectApplication> applications;
    private final GenerativeModelFutures model;
    private final Executor executor = Executors.newSingleThreadExecutor();

    public FacultyManageAdapter(List<ProjectApplication> applications) {
        this.applications = applications;
        GenerativeModel gm = new GenerativeModel(Config.MODEL_NAME, Config.GEMINI_API_KEY);
        this.model = GenerativeModelFutures.from(gm);
    }

    public void updateData(List<ProjectApplication> newApps) {
        this.applications = newApps;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_faculty_manage, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ProjectApplication app = applications.get(position);
        
        // Fetch project title from DatabaseHelper
        DatabaseHelper db = DatabaseHelper.getInstance(holder.itemView.getContext());
        Project project = db.getProjectById(app.projectId);
        if (project != null) {
            holder.title.setText(project.getTitle());
        } else {
            holder.title.setText("Unknown Project");
        }

        holder.subtitle.setText("From Student: " + app.studentName);
        
        // Auto-run AI Screening for each application
        autoScreenApplication(holder, app, project);

        if (app.message != null && !app.message.isEmpty()) {
            holder.message.setVisibility(View.VISIBLE);
            holder.message.setText("\"" + app.message + "\"");
        } else {
            holder.message.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(v -> {
            // Fetch student profile to get their bio (skills)
            UserProfile student = db.getUserProfile(app.studentId);
            if (student != null && project != null) {
                if (app.resumeUrl != null && !app.resumeUrl.isEmpty()) {
                    // Use Gemini Resume Parser if resume is available
                    ResumeParserService parser = new ResumeParserService(v.getContext());
                    v.setEnabled(false); // Prevent multiple clicks
                    
                    new Thread(() -> {
                        ResumeParserService.ParseResult parseResult = parser.analyzeResume(Uri.parse(app.resumeUrl), project.getFullText());
                        
                        holder.itemView.post(() -> {
                            v.setEnabled(true);
                            if (parseResult.success) {
                                navigateToAlignment(v, parseResult.result, student.getName());
                            } else {
                                // Fallback to bio analysis if resume parsing fails
                                AlignmentResult result = SkillAnalysisEngine.getInstance()
                                        .analyzeAlignment(student.getBio(), project.getFullText());
                                navigateToAlignment(v, result, student.getName());
                            }
                        });
                    }).start();
                } else {
                    // Fallback to basic bio analysis
                    AlignmentResult result = SkillAnalysisEngine.getInstance()
                            .analyzeAlignment(student.getBio(), project.getFullText());
                    navigateToAlignment(v, result, student.getName());
                }
            } else {
                Toast.makeText(v.getContext(), "Could not load student profile", Toast.LENGTH_SHORT).show();
            }
        });

        // Set the spinner to match the current status
        String[] options = holder.itemView.getContext().getResources().getStringArray(R.array.fac_status_options);
        for (int i = 0; i < options.length; i++) {
            if (options[i].equalsIgnoreCase(app.status)) {
                holder.statusSpinner.setSelection(i);
                break;
            }
        }

        holder.statusSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            private boolean isInitial = true;
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (isInitial) {
                    isInitial = false;
                    return;
                }
                String newStatus = parent.getItemAtPosition(pos).toString();
                if (!newStatus.equalsIgnoreCase(app.status)) {
                    app.status = newStatus;
                    db.updateApplicationStatus(app.id, newStatus);
                    Toast.makeText(holder.itemView.getContext(), "Status updated to " + newStatus, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        holder.btnAiFeedback.setOnClickListener(v -> generateAiFeedback(holder, app, project));
        
        generateSmartReplies(holder, app);
    }

    private void generateSmartReplies(ViewHolder holder, ProjectApplication app) {
        if (app.message == null || app.message.isEmpty()) {
            holder.cgSmartReplies.setVisibility(View.GONE);
            return;
        }

        List<TextMessage> chatHistory = new ArrayList<>();
        // In a real app, you'd add the full conversation. For now, we use the application message.
        chatHistory.add(TextMessage.createForRemoteUser(app.message, System.currentTimeMillis(), app.studentId));

        SmartReplyGenerator smartReply = SmartReply.getClient();
        smartReply.suggestReplies(chatHistory)
                .addOnSuccessListener(result -> {
                    holder.cgSmartReplies.removeAllViews();
                    if (result.getStatus() == com.google.mlkit.nl.smartreply.SmartReplySuggestionResult.STATUS_SUCCESS) {
                        holder.cgSmartReplies.setVisibility(View.VISIBLE);
                        for (com.google.mlkit.nl.smartreply.SmartReplySuggestion suggestion : result.getSuggestions()) {
                            Chip chip = new Chip(holder.itemView.getContext());
                            chip.setText(suggestion.getText());
                            chip.setOnClickListener(v -> {
                                // Simulate sending reply or opening feedback dialog with this text
                                Toast.makeText(holder.itemView.getContext(), "Reply: " + suggestion.getText(), Toast.LENGTH_SHORT).show();
                            });
                            holder.cgSmartReplies.addView(chip);
                        }
                    } else {
                        holder.cgSmartReplies.setVisibility(View.GONE);
                    }
                })
                .addOnFailureListener(e -> holder.cgSmartReplies.setVisibility(View.GONE));
    }

    private void autoScreenApplication(ViewHolder holder, ProjectApplication app, Project project) {
        if (project == null) return;
        
        // Use a simple prompt for quick screening
        String prompt = "Review this student application for the research project '" + project.getTitle() + "'.\n" +
                "Project description: " + project.getDescription() + "\n" +
                "Student message: " + app.message + "\n\n" +
                "Respond in EXACTLY this JSON format: {\"score\": 85, \"summary\": \"Brief 1-sentence summary of why they fit\"}";

        com.example.project.AIFallbackManager.callWithFallback(model, prompt, new com.example.project.AIFallbackManager.AICallback() {
            @Override
            public void onSuccess(String result) {
                holder.itemView.post(() -> {
                    try {
                        JSONObject json = new JSONObject(result.substring(result.indexOf("{"), result.lastIndexOf("}") + 1));
                        int score = json.getInt("score");
                        String summary = json.getString("summary");

                        holder.aiScreenLayout.setVisibility(View.VISIBLE);
                        holder.aiScore.setText(score + "%");
                        holder.aiSummary.setText(summary);
                        
                        // Color coding
                        if (score >= 80) holder.aiScore.setTextColor(android.graphics.Color.parseColor("#4CAF50"));
                        else if (score >= 60) holder.aiScore.setTextColor(android.graphics.Color.parseColor("#FFC107"));
                        else holder.aiScore.setTextColor(android.graphics.Color.parseColor("#F44336"));

                    } catch (Exception e) {
                        holder.aiScreenLayout.setVisibility(View.GONE);
                    }
                });
            }

            @Override
            public void onFailure(Throwable t) {
                holder.itemView.post(() -> holder.aiScreenLayout.setVisibility(View.GONE));
            }
        });
    }

    private void generateAiFeedback(ViewHolder holder, ProjectApplication app, Project project) {
        if (project == null) return;

        holder.btnAiFeedback.setEnabled(false);
        holder.btnAiFeedback.setText("Generating...");

        String prompt = "You are a university professor reviewing research applications. " +
                "The student '" + app.studentName + "' applied for your project '" + project.getTitle() + "'.\n" +
                "Project Context: " + project.getDescription() + "\n" +
                "Student's Message: " + app.message + "\n\n" +
                "Generate a short, constructive piece of feedback (2-3 sentences) for this student. " +
                "If the status is 'Rejected', provide encouraging advice on what skills they could improve based on the project requirements. " +
                "If 'Accepted' or 'To Discuss', highlight what part of their application or background stood out. " +
                "Current application status is: " + app.status;

        com.example.project.AIFallbackManager.callWithFallback(model, prompt, new com.example.project.AIFallbackManager.AICallback() {
            @Override
            public void onSuccess(String result) {
                holder.itemView.post(() -> {
                    holder.btnAiFeedback.setEnabled(true);
                    holder.btnAiFeedback.setText("AI Feedback");
                    new MaterialAlertDialogBuilder(holder.itemView.getContext())
                            .setTitle("AI-Drafted Feedback")
                            .setMessage(result)
                            .setPositiveButton("Use as Draft", (d, w) -> {
                                // Potentially auto-fill a message field or send via email
                                Toast.makeText(holder.itemView.getContext(), "Feedback copied to dashboard draft", Toast.LENGTH_SHORT).show();
                            })
                            .setNegativeButton("Close", null)
                            .show();
                });
            }

            @Override
            public void onFailure(Throwable t) {
                holder.itemView.post(() -> {
                    holder.btnAiFeedback.setEnabled(true);
                    holder.btnAiFeedback.setText("AI Feedback");
                    Toast.makeText(holder.itemView.getContext(), "AI Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void navigateToAlignment(View v, AlignmentResult result, String studentName) {
        if (v.getContext() instanceof MainActivity) {
            ((MainActivity) v.getContext()).navigateToFragment(
                    SkillAlignmentFragment.forFaculty(result, studentName)
            );
        } else if (v.getContext() instanceof FacultyActivity) {
            ((FacultyActivity) v.getContext()).getSupportFragmentManager().beginTransaction()
                    .replace(R.id.faculty_fragment_container, SkillAlignmentFragment.forFaculty(result, studentName))
                    .addToBackStack(null)
                    .commit();
        }
    }

    @Override
    public int getItemCount() {
        return applications.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, subtitle, message;
        Spinner statusSpinner;
        Button btnAiFeedback;
        View aiScreenLayout;
        TextView aiScore, aiSummary;
        ChipGroup cgSmartReplies;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tv_fac_item_title);
            subtitle = itemView.findViewById(R.id.tv_fac_item_subtitle);
            message = itemView.findViewById(R.id.tv_fac_item_message);
            statusSpinner = itemView.findViewById(R.id.spinner_fac_status);
            btnAiFeedback = itemView.findViewById(R.id.btn_ai_feedback);
            aiScreenLayout = itemView.findViewById(R.id.layout_ai_screen);
            aiScore = itemView.findViewById(R.id.tv_ai_score);
            aiSummary = itemView.findViewById(R.id.tv_ai_summary);
            cgSmartReplies = itemView.findViewById(R.id.cg_smart_replies);
        }
    }
}
