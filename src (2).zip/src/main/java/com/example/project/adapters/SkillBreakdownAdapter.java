package com.example.project.adapters;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.models.SkillAlignment;

import java.util.ArrayList;
import java.util.List;

public class SkillBreakdownAdapter extends RecyclerView.Adapter<SkillBreakdownAdapter.ViewHolder> {

    private List<SkillAlignment> skills = new ArrayList<>();
    private boolean isFacultyMode = false;

    public void updateData(List<SkillAlignment> newSkills, boolean isFacultyMode) {
        this.skills = newSkills;
        this.isFacultyMode = isFacultyMode;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_skill_alignment, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SkillAlignment skill = skills.get(position);
        holder.name.setText(skill.skill);
        holder.category.setText(skill.category);
        holder.progress.setProgress(skill.getMatchPercent());
        
        if (isFacultyMode) {
            holder.weightText.setVisibility(View.VISIBLE);
            holder.weightText.setText(skill.studentWeight + " / " + skill.projectWeight);
        } else {
            holder.weightText.setVisibility(View.GONE);
        }
        
        if (skill.isCritical) {
            holder.criticalBadge.setVisibility(View.VISIBLE);
        } else {
            holder.criticalBadge.setVisibility(View.GONE);
        }

        // Color coding based on match percentage
        int matchPercent = skill.getMatchPercent();
        int color;
        if (matchPercent >= 80) {
            color = Color.parseColor("#2E7D32"); // Green
        } else if (matchPercent >= 50) {
            color = Color.parseColor("#F9A825"); // Amber
        } else {
            color = Color.parseColor("#C62828"); // Red
        }
        
        holder.progress.getProgressDrawable().setColorFilter(color, PorterDuff.Mode.SRC_IN);
    }

    @Override
    public int getItemCount() {
        return skills.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, category, weightText, criticalBadge;
        ProgressBar progress;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.skill_name);
            category = itemView.findViewById(R.id.skill_category);
            weightText = itemView.findViewById(R.id.weight_text);
            criticalBadge = itemView.findViewById(R.id.critical_badge);
            progress = itemView.findViewById(R.id.skill_progress);
        }
    }
}
