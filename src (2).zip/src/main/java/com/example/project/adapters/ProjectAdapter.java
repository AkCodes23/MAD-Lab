package com.example.project.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.models.Project;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.ViewHolder> {

    private List<Project> projects = new ArrayList<>();
    private boolean facultyMode = false;
    private OnProjectClickListener listener;

    public interface OnProjectClickListener {
        void onProjectClick(Project project);
    }

    public ProjectAdapter(OnProjectClickListener listener) {
        this.listener = listener;
    }

    public void setFacultyMode(boolean facultyMode) {
        this.facultyMode = facultyMode;
    }

    public void updateData(List<Project> newProjects) {
        this.projects = newProjects;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_research, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Project project = projects.get(position);
        holder.title.setText(project.getTitle());
        holder.professor.setText(project.getProfessor());
        holder.status.setText(project.getStatus());

        // Visual Recommendation Highlighting
        if (project.isRecommended()) {
            holder.recommendedBadge.setVisibility(View.VISIBLE);
            holder.card.setStrokeColor(holder.itemView.getContext().getResources().getColor(R.color.recommendation_border));
            holder.card.setStrokeWidth(4);
        } else {
            holder.recommendedBadge.setVisibility(View.GONE);
            holder.card.setStrokeColor(0xFF2C2C2C); // Normal border
            holder.card.setStrokeWidth(3);
        }
        
        holder.chipGroup.removeAllViews();
        List<String> skills = project.getSkills();
        if (skills != null) {
            for (String skill : skills) {
                Chip chip = new Chip(holder.itemView.getContext());
                chip.setText(skill);
                chip.setChipBackgroundColorResource(R.color.chip_background);
                chip.setTextColor(android.graphics.Color.WHITE);
                chip.setChipStrokeWidth(0);
                chip.setClickable(false);
                holder.chipGroup.addView(chip);
            }
        }

        if (facultyMode) {
            holder.applyButton.setText("View Interested Students");
        } else {
            holder.applyButton.setText("View Details");
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onProjectClick(project);
            }
        });

        holder.applyButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onProjectClick(project);
            }
        });
    }

    @Override
    public int getItemCount() {
        return projects.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, professor, status, recommendedBadge;
        ChipGroup chipGroup;
        Button applyButton;
        com.google.android.material.card.MaterialCardView card;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.project_title);
            professor = itemView.findViewById(R.id.professor_name);
            status = itemView.findViewById(R.id.status);
            recommendedBadge = itemView.findViewById(R.id.tv_recommended_badge);
            chipGroup = itemView.findViewById(R.id.cg_skills);
            applyButton = itemView.findViewById(R.id.btn_apply);
            card = (com.google.android.material.card.MaterialCardView) itemView;
        }
    }
}
