package com.example.project.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.Config;
import com.example.project.DatabaseHelper;
import com.example.project.R;
import com.example.project.models.ProjectApplication;
import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ApplicationAdapter extends RecyclerView.Adapter<ApplicationAdapter.ViewHolder> {

    private List<ProjectApplication> applications;
    private final GenerativeModelFutures model;
    private final Executor executor = Executors.newSingleThreadExecutor();

    public ApplicationAdapter(List<ProjectApplication> applications) {
        this.applications = applications;
        GenerativeModel gm = new GenerativeModel(Config.MODEL_NAME, Config.GEMINI_API_KEY);
        this.model = GenerativeModelFutures.from(gm);
    }

    public void updateData(List<ProjectApplication> applications) {
        this.applications = applications;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_application_status, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ProjectApplication app = applications.get(position);
        
        DatabaseHelper db = DatabaseHelper.getInstance(holder.itemView.getContext());
        com.example.project.models.Project project = db.getProjectById(app.projectId);
        
        holder.title.setText(project != null ? project.getTitle() : "Project ID: " + app.projectId);
        holder.professor.setText(project != null ? "Prof: " + project.getProfessor() : "Loading...");
        holder.status.setText(app.status);
        
        // Updated Status Colors
        String status = app.status != null ? app.status : "";
        if (status.equalsIgnoreCase("Accepted") || status.equalsIgnoreCase("Approved")) {
            holder.status.setBackgroundColor(Color.parseColor("#4CAF50")); // Material Green
        } else if (status.equalsIgnoreCase("Rejected")) {
            holder.status.setBackgroundColor(Color.parseColor("#F44336")); // Material Red
        } else if (status.equalsIgnoreCase("Under Review")) {
            holder.status.setBackgroundColor(Color.parseColor("#2196F3")); // Material Blue
        } else if (status.equalsIgnoreCase("To Discuss")) {
            holder.status.setBackgroundColor(Color.parseColor("#FF9800")); // Material Orange
        } else {
            holder.status.setBackgroundColor(Color.parseColor("#9E9E9E")); // Material Gray
        }

        if ("Accepted".equalsIgnoreCase(status) || "To Discuss".equalsIgnoreCase(status)) {
            holder.btnTalkingPoints.setVisibility(View.VISIBLE);
            holder.btnTalkingPoints.setOnClickListener(v -> generateTalkingPoints(holder, app, project));
        } else {
            holder.btnTalkingPoints.setVisibility(View.GONE);
        }

        holder.btnDelete.setOnClickListener(v -> {
            db.deleteApplication(app.id);
            applications.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, applications.size());
        });
    }

    private void generateTalkingPoints(ViewHolder holder, ProjectApplication app, com.example.project.models.Project project) {
        if (project == null) return;

        holder.btnTalkingPoints.setEnabled(false);
        
        String prompt = "The student '" + app.studentName + "' has been invited to discuss or has been accepted for the project: '" + project.getTitle() + "'.\n" +
                "Project Description: " + project.getDescription() + "\n" +
                "Student's Application Message: " + app.message + "\n\n" +
                "Generate 3-4 personalized 'talking points' or questions the student should bring up during their consultation with the professor to show their interest and competence. Keep it professional and specific to the project.";

        com.example.project.AIFallbackManager.callWithFallback(model, prompt, new com.example.project.AIFallbackManager.AICallback() {
            @Override
            public void onSuccess(String result) {
                holder.itemView.post(() -> {
                    holder.btnTalkingPoints.setEnabled(true);
                    new MaterialAlertDialogBuilder(holder.itemView.getContext())
                            .setTitle("Interview Talking Points")
                            .setMessage(result)
                            .setPositiveButton("Got it", null)
                            .show();
                });
            }

            @Override
            public void onFailure(Throwable t) {
                holder.itemView.post(() -> {
                    holder.btnTalkingPoints.setEnabled(true);
                    Toast.makeText(holder.itemView.getContext(), "AI Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return applications.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, professor, status;
        ImageButton btnDelete, btnTalkingPoints;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tv_app_project_title);
            professor = itemView.findViewById(R.id.tv_app_professor);
            status = itemView.findViewById(R.id.tv_app_status);
            btnDelete = itemView.findViewById(R.id.btn_delete_app);
            btnTalkingPoints = itemView.findViewById(R.id.btn_talking_points);
        }
    }
}
