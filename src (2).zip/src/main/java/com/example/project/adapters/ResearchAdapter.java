package com.example.project.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.ui.ConsultationActivity;
import com.example.project.ApplicationStatusManager;
import com.example.project.SessionManager;
import com.example.project.models.Project;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.List;

public class ResearchAdapter extends RecyclerView.Adapter<ResearchAdapter.ViewHolder> {

    private List<Project> projects;

    public ResearchAdapter(List<Project> projects) {
        this.projects = projects;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_research, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Project project = projects.get(position);
        holder.title.setText(project.getTitle());
        holder.professor.setText(project.getProfessor());
        holder.status.setText(project.getStatus());
        
        holder.chipGroup.removeAllViews();
        for (String skill : project.getSkills()) {
            Chip chip = new Chip(holder.itemView.getContext());
            chip.setText(skill);
            chip.setChipBackgroundColorResource(R.color.chip_background);
            chip.setTextColor(android.graphics.Color.WHITE);
            chip.setChipStrokeWidth(0);
            chip.setClickable(false);
            holder.chipGroup.addView(chip);
        }
        
        holder.applyButton.setOnClickListener(v -> {
            if (!ApplicationStatusManager.getInstance(v.getContext()).isResumeAnalyzed()) {
                new AlertDialog.Builder(v.getContext())
                        .setTitle(R.string.msg_resume_analysis_required)
                        .setMessage(R.string.msg_resume_analysis_prompt)
                        .setPositiveButton(R.string.btn_go_to_profile, (dialog, which) -> {
                            // This would ideally navigate to profile, but for now we just show the message
                        })
                        .setNegativeButton(R.string.btn_cancel, null)
                        .show();
            } else if (ApplicationStatusManager.getInstance(v.getContext()).isAlreadyApplied(project.getId(), SessionManager.getInstance(v.getContext()).getUid())) {
                new AlertDialog.Builder(v.getContext())
                        .setTitle(R.string.title_already_applied)
                        .setMessage(R.string.msg_already_applied)
                        .setPositiveButton(R.string.btn_ok, null)
                        .show();
            } else {
                String uid = SessionManager.getInstance(v.getContext()).getUid();
                // We don't have userName in SessionManager, but we can get it from DatabaseHelper or use a default
                com.example.project.models.UserProfile profile = com.example.project.DatabaseHelper.getInstance(v.getContext()).getUserProfile(uid);
                String name = profile != null ? profile.getName() : v.getContext().getString(R.string.label_student);

                com.example.project.models.ProjectApplication app = new com.example.project.models.ProjectApplication(
                    java.util.UUID.randomUUID().toString(),
                    project.getId(),
                    uid,
                    name,
                    "I am interested in this project.",
                    "internal_resume",
                    "pending"
                );
                com.example.project.DatabaseHelper.getInstance(v.getContext()).submitApplication(app);
                Toast.makeText(v.getContext(), v.getContext().getString(R.string.msg_applied_success, project.getTitle()), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return projects.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, professor, status;
        ChipGroup chipGroup;
        Button applyButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.project_title);
            professor = itemView.findViewById(R.id.professor_name);
            status = itemView.findViewById(R.id.status);
            chipGroup = itemView.findViewById(R.id.cg_skills);
            applyButton = itemView.findViewById(R.id.btn_apply);
        }
    }
}
