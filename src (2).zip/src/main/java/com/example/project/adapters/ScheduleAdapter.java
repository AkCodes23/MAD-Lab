package com.example.project.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.models.ScheduleItem;

import java.util.List;

public class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ViewHolder> {

    private List<ScheduleItem> items;
    private String currentRole; // "Student" or "Faculty"

    public ScheduleAdapter(List<ScheduleItem> items, String currentRole) {
        this.items = items;
        this.currentRole = currentRole;
    }

    public void updateData(List<ScheduleItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_schedule, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ScheduleItem item = items.get(position);
        
        // Dynamic Title Resolution
        if ("Meeting".equals(item.getType())) {
            if ("Faculty".equals(currentRole)) {
                holder.title.setText("Meeting with Student: John Doe");
            } else {
                holder.title.setText("Meeting with Prof. XYZ"); // Simplified
            }
        } else {
            holder.title.setText(item.getTitle());
        }

        holder.dateTime.setText(item.getDateTime());
        holder.type.setText(item.getType());
        
        if ("Meeting".equals(item.getType())) {
            holder.type.setBackgroundResource(android.R.color.holo_purple);
        } else {
            holder.type.setBackgroundResource(android.R.color.holo_orange_light);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, dateTime, type;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tv_schedule_title);
            dateTime = itemView.findViewById(R.id.tv_schedule_datetime);
            type = itemView.findViewById(R.id.tv_schedule_type);
        }
    }
}
