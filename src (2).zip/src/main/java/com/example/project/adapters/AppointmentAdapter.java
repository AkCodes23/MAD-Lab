package com.example.project.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AppointmentAdapter extends RecyclerView.Adapter<AppointmentAdapter.ViewHolder> {

    private List<Map<String, Object>> appointments = new ArrayList<>();
    private boolean isFaculty;

    public AppointmentAdapter(boolean isFaculty) {
        this.isFaculty = isFaculty;
    }

    public void updateData(List<Map<String, Object>> newAppointments) {
        this.appointments = newAppointments;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_appointment, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Map<String, Object> appointment = appointments.get(position);
        String docId = (String) appointment.get("id");
        String studentName = (String) appointment.get("studentName");
        String facultyName = (String) appointment.get("facultyName");
        String date = (String) appointment.get("date");
        String message = (String) appointment.get("message");
        String status = (String) appointment.get("status");

        holder.name.setText(isFaculty ? studentName : facultyName);
        holder.date.setText(date);
        holder.message.setText(message);
        holder.status.setText(status.toUpperCase());

        // Status color coding
        if ("approved".equalsIgnoreCase(status)) {
            holder.status.setBackgroundColor(Color.parseColor("#2E7D32")); // Green
        } else if ("rejected".equalsIgnoreCase(status)) {
            holder.status.setBackgroundColor(Color.parseColor("#C62828")); // Red
        } else {
            holder.status.setBackgroundColor(Color.parseColor("#F9A825")); // Orange (Pending)
        }

        if (isFaculty && "pending".equalsIgnoreCase(status)) {
            holder.actions.setVisibility(View.VISIBLE);
            holder.btnApprove.setOnClickListener(v -> updateStatus(docId, "approved", appointment));
            holder.btnReject.setOnClickListener(v -> updateStatus(docId, "rejected", appointment));
        } else {
            holder.actions.setVisibility(View.GONE);
        }
    }

    private void updateStatus(String docId, String newStatus, Map<String, Object> appointment) {
        if (docId == null) return;
        DatabaseHelper.getInstance(null).updateAppointmentStatus(docId, newStatus);
        appointment.put("status", newStatus);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return appointments.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, date, message, status;
        LinearLayout actions;
        Button btnApprove, btnReject;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.attendee_name);
            date = itemView.findViewById(R.id.appointment_date);
            message = itemView.findViewById(R.id.appointment_message);
            status = itemView.findViewById(R.id.appointment_status);
            actions = itemView.findViewById(R.id.faculty_actions);
            btnApprove = itemView.findViewById(R.id.btn_approve);
            btnReject = itemView.findViewById(R.id.btn_reject);
        }
    }
}
