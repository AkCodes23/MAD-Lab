package com.example.project;

import java.util.Arrays;
import java.util.List;

public class Config {
    // List of Gemini API keys for rotation
    public static final List<String> GEMINI_API_KEYS = Arrays.asList(
        "AIzaSyBSZLkE0qWo11uYsw--7AhzwFhmOgYAFbk"
    );

    private static int currentKeyIndex = 0;
    public static String GEMINI_API_KEY = GEMINI_API_KEYS.get(0);

    // Using gemini-2.0-flash-exp
    public static final String MODEL_NAME = "gemini-2.5-flash";

    public static void rotateKey() {
        if (GEMINI_API_KEYS.isEmpty()) return;
        currentKeyIndex = (currentKeyIndex + 1) % GEMINI_API_KEYS.size();
        GEMINI_API_KEY = GEMINI_API_KEYS.get(currentKeyIndex);
    }
    
    public static int getCurrentKeyIndex() {
        return currentKeyIndex;
    }
    
    public static int getKeyCount() {
        return GEMINI_API_KEYS.size();
    }
}
