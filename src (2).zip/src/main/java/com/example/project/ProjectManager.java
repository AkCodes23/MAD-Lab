package com.example.project;

import com.example.project.models.Project;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import com.example.project.models.Project;
import java.util.ArrayList;
import java.util.List;

public class ProjectManager {
    private static ProjectManager instance;
    private DatabaseHelper dbHelper;

    private ProjectManager(Context context) {
        dbHelper = DatabaseHelper.getInstance(context);
    }

    public static synchronized ProjectManager getInstance(Context context) {
        if (instance == null) {
            instance = new ProjectManager(context);
        }
        return instance;
    }

    public List<Project> getProjects() {
        return dbHelper.getOpenProjects();
    }

    public List<Project> getProjectsByFaculty(String facultyId) {
        return dbHelper.getProjectsByFaculty(facultyId);
    }

    public Project getProjectById(String id) {
        return dbHelper.getProjectById(id);
    }

    public void addProject(Project project) {
        dbHelper.addProject(project);
    }
}
